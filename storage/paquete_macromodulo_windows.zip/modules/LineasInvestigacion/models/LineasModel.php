<?php
// modules/LineasInvestigacion/models/LineasModel.php

require_once CORE_PATH . 'Database/QueryBuilder.php';

/**
 * LineasModel
 * Gestiona todas las operaciones de BD sobre lineas_investigacion
 * y sus relaciones con dimensiones, proyectos e investigaciones ofertadas.
 */
class LineasModel extends QueryBuilder {

    /**
     * Obtiene todas las líneas con estadísticas agregadas:
     * total de dimensiones, proyectos clasificados e investigaciones ofertadas.
     */
    public function getTodasConEstadisticas(bool $soloActivos = false): array {
        $sql = "
            SELECT
                li.id,
                li.nombre,
                li.descripcion,
                li.activo,
                li.id_carrera,
                c.nombre  AS carrera_nombre,
                COUNT(DISTINCT dim.id)       AS total_dimensiones,
                COUNT(DISTINCT rc.id_recurso) AS total_proyectos,
                COUNT(DISTINCT io.id)         AS total_investigaciones
            FROM lineas_investigacion li
            LEFT JOIN carreras               c   ON c.id   = li.id_carrera
            LEFT JOIN dimensiones_operativas dim ON dim.id_linea = li.id
            LEFT JOIN recurso_clasificaciones rc  ON rc.id_linea_investigacion = li.id
            LEFT JOIN investigaciones_ofertadas io ON io.id_linea = li.id
            " . ($soloActivos ? "WHERE li.activo = true" : "") . "
            GROUP BY li.id, li.nombre, li.descripcion, li.activo, li.id_carrera, c.nombre
            ORDER BY li.id ASC
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Obtiene una línea por su ID, con datos de la carrera asociada.
     */
    public function getLineaConCarrera(int $id): ?array {
        $sql = "
            SELECT li.*, c.nombre AS carrera_nombre
            FROM lineas_investigacion li
            LEFT JOIN carreras c ON c.id = li.id_carrera
            WHERE li.id = ?
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);
        $result = $stmt->fetch();
        return $result ?: null;
    }

    /**
     * Obtiene los proyectos (recursos tipo 1) clasificados en una línea,
     * con datos de autor, dimensión operativa y detalle del proyecto.
     */
    public function getProyectosPorLinea(int $id_linea, int $limit = 0, int $offset = 0): array {
        $sql = "
            SELECT
                r.id,
                r.titulo,
                r.anio_publicacion,
                r.archivo_pdf,
                dp.resumen,
                dp.nivel_academico,
                dp.palabras_clave,
                dp.fecha_defensa,
                dim.nombre AS dimension_nombre,
                STRING_AGG(DISTINCT a.nombre_completo, ', ') AS autores
            FROM recurso_clasificaciones rc
            INNER JOIN recursos r          ON r.id   = rc.id_recurso
            LEFT  JOIN detalles_proyectos dp ON dp.id_recurso = r.id
            LEFT  JOIN dimensiones_operativas dim ON dim.id   = rc.id_dimension_operativa
            LEFT  JOIN recurso_autores ra  ON ra.id_recurso   = r.id
            LEFT  JOIN autores a           ON a.id            = ra.id_autor
            WHERE rc.id_linea_investigacion = ? AND dp.activo = true
            GROUP BY r.id, r.titulo, r.anio_publicacion, r.archivo_pdf, dp.resumen,
                     dp.nivel_academico, dp.palabras_clave, dp.fecha_defensa, dim.nombre
            ORDER BY dp.fecha_defensa DESC
        ";
        
        if ($limit > 0) {
            $sql .= " LIMIT " . (int)$limit . " OFFSET " . (int)$offset;
        }

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id_linea]);
        return $stmt->fetchAll();
    }
    
    public function countProyectosPorLinea(int $id_linea): int {
        $sql = "SELECT COUNT(DISTINCT r.id) 
                FROM recurso_clasificaciones rc
                INNER JOIN recursos r ON r.id = rc.id_recurso
                LEFT JOIN detalles_proyectos dp ON dp.id_recurso = r.id
                WHERE rc.id_linea_investigacion = ? AND dp.activo = true";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id_linea]);
        return (int) $stmt->fetchColumn();
    }

    /**
     * Obtiene las investigaciones ofertadas (activas/abiertas) para una línea,
     * con nombre del profesor y dimensión operativa.
     */
    public function getInvestigacionesPorLinea(int $id_linea): array {
        $sql = "
            SELECT DISTINCT
                io.*,
                dim.nombre  AS dimension_nombre,
                u.nombre_completo AS nombre_profesor
            FROM investigaciones_ofertadas io
            LEFT JOIN dimensiones_operativas dim ON dim.id = io.id_dimension
            LEFT JOIN usuarios              u   ON u.id   = io.id_profesor
            WHERE io.id_linea = ?
               OR EXISTS (
                   SELECT 1 FROM public.investigaciones_lineas il
                   WHERE il.id_investigacion = io.id AND il.id_linea = ?
               )
            ORDER BY io.fecha_creacion DESC
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id_linea, $id_linea]);
        return $stmt->fetchAll();
    }

    /**
     * Retorna los profesores afiliados a una línea (por perfil, dimensiones o investigaciones a cargo)
     * y sus proyectos (investigaciones ofertadas) en dicha línea.
     */
    public function getProfesoresAfiliadosPorLinea(int $id_linea): array {
        try {
            $this->db->exec("ALTER TABLE public.usuarios ADD COLUMN IF NOT EXISTS foto_perfil TEXT");
            $this->db->exec("ALTER TABLE public.usuarios ADD COLUMN IF NOT EXISTS orcid VARCHAR(150)");
            $this->db->exec("ALTER TABLE public.usuarios ADD COLUMN IF NOT EXISTS sitio_web VARCHAR(255)");
            $this->db->exec("ALTER TABLE public.usuarios ADD COLUMN IF NOT EXISTS grado_academico VARCHAR(255)");
        } catch (\Throwable $e) {}

        $sql = "
            SELECT DISTINCT
                u.id,
                u.id AS id_profesor,
                u.nombre_completo AS nombre_profesor,
                u.email,
                u.foto_perfil,
                u.orcid,
                u.sitio_web,
                u.grado_academico
            FROM public.usuarios u
            WHERE u.activo = true
              AND (
                  EXISTS (
                      SELECT 1 FROM public.profesor_linea pl
                      WHERE pl.id_usuario = u.id AND pl.id_linea = ?
                  )
                  OR EXISTS (
                      SELECT 1 FROM public.profesor_dimension pd
                      WHERE pd.id_usuario = u.id AND pd.id_linea = ?
                  )
                  OR EXISTS (
                      SELECT 1 FROM public.investigaciones_ofertadas io
                      LEFT JOIN public.investigaciones_lineas il ON il.id_investigacion = io.id
                      WHERE io.id_profesor = u.id AND (io.id_linea = ? OR il.id_linea = ?)
                  )
              )
            ORDER BY u.nombre_completo ASC
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id_linea, $id_linea, $id_linea, $id_linea]);
        $profesores = $stmt->fetchAll();

        $stmtDim = null;
        try {
            $stmtDim = $this->db->prepare("
                SELECT DISTINCT d.id, d.nombre
                FROM public.dimensiones_operativas d
                WHERE d.id_linea = ? AND d.activo = true
                  AND (
                      EXISTS (
                          SELECT 1 FROM public.profesor_dimension pd
                          WHERE pd.id_dimension = d.id AND pd.id_usuario = ? AND pd.id_linea = ?
                      )
                      OR EXISTS (
                          SELECT 1 FROM public.investigaciones_ofertadas io
                          LEFT JOIN public.investigaciones_dimensiones idim ON idim.id_investigacion = io.id
                          WHERE io.id_profesor = ? AND (io.id_dimension = d.id OR idim.id_dimension = d.id)
                      )
                  )
                ORDER BY d.nombre ASC
            ");
        } catch (\Throwable $e) {}

        $stmtIo = $this->db->prepare("
            SELECT DISTINCT io.id, io.titulo, io.estado, io.cupos_disponibles, io.fecha_creacion
            FROM public.investigaciones_ofertadas io
            LEFT JOIN public.investigaciones_lineas il ON il.id_investigacion = io.id
            WHERE io.id_profesor = ? AND (io.id_linea = ? OR il.id_linea = ?)
            ORDER BY io.fecha_creacion DESC
        ");

        // Para cada profesor, buscamos sus dimensiones operativas y proyectos en esta línea
        foreach ($profesores as &$prof) {
            $profId = (int)$prof['id'];
            $prof['dimensiones'] = [];
            if ($stmtDim) {
                try {
                    $stmtDim->execute([$id_linea, $profId, $id_linea, $profId]);
                    $prof['dimensiones'] = $stmtDim->fetchAll();
                } catch (\Throwable $e) {
                    $prof['dimensiones'] = [];
                }
            }

            $stmtIo->execute([$profId, $id_linea, $id_linea]);
            $prof['ofertas'] = $stmtIo->fetchAll();
        }
        return $profesores;
    }

    /**
     * Retorna todas las líneas en formato simple (para selectores de formulario).
     */
    public function getTodas(): array {
        return $this->tabla('lineas_investigacion')
                    ->orderBy('nombre', 'ASC')
                    ->get();
    }

    /**
     * Inserta una nueva línea de investigación.
     * @return int|false ID generado o false en fallo
     */

    public function existeNombre(string $nombre, int $id_carrera, ?int $exclude_id = null): bool {
        $sql = "SELECT COUNT(*) FROM lineas_investigacion WHERE LOWER(nombre) = LOWER(?) AND id_carrera = ?";
        $params = [$nombre, $id_carrera];
        if ($exclude_id !== null) {
            $sql .= " AND id != ?";
            $params[] = $exclude_id;
        }
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn() > 0;
    }

    public function tieneDependencias(int $id_linea): array {
        $sql1 = "SELECT COUNT(*) FROM recurso_clasificaciones WHERE id_linea_investigacion = ?";
        $stmt1 = $this->db->prepare($sql1);
        $stmt1->execute([$id_linea]);
        $proyectos = (int)$stmt1->fetchColumn();

        $sql2 = "SELECT COUNT(*) FROM investigaciones_ofertadas WHERE id_linea = ?";
        $stmt2 = $this->db->prepare($sql2);
        $stmt2->execute([$id_linea]);
        $ofertas = (int)$stmt2->fetchColumn();

        return ['proyectos' => $proyectos, 'ofertas' => $ofertas];
    }

    public function crear(array $datos) {
        return $this->tabla('lineas_investigacion')->insert($datos);
    }

    /**
     * Actualiza una línea de investigación por ID.
     */
    public function actualizar(int $id, array $datos): bool {
        return $this->tabla('lineas_investigacion')
                    ->where('id', '=', $id)
                    ->update($datos);
    }

    /**
     * Elimina una línea de investigación por ID.
     */
    
    public function tieneRecursosAsociados(int $id): bool {
        $sql = "SELECT COUNT(*) FROM recurso_clasificaciones WHERE id_linea_investigacion = ?";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([$id]);
        if ($stmt->fetchColumn() > 0) return true;
        
        $sql2 = "SELECT COUNT(*) FROM investigaciones_ofertadas WHERE id_linea = ?";
        $stmt2 = $this->db->prepare($sql2);
        $stmt2->execute([$id]);
        return $stmt2->fetchColumn() > 0;
    }

    public function eliminar(int $id): bool {
        return $this->tabla('lineas_investigacion')
                    ->where('id', '=', $id)
                    ->delete();
    }
    public function getOfertasRecientes(int $limit = 5): array {
        $sql = "
            SELECT 
                io.id, io.titulo, io.estado, io.cupos_disponibles,
                u.nombre_completo AS profesor,
                li.nombre AS linea_nombre
            FROM investigaciones_ofertadas io
            LEFT JOIN usuarios u ON u.id = io.id_profesor
            LEFT JOIN lineas_investigacion li ON li.id = io.id_linea
            WHERE io.estado = 'Abierta'
            ORDER BY io.fecha_creacion DESC
            LIMIT $limit
        ";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    public function toggleActivo(int $id, bool $estado): bool {
        $sql = "UPDATE lineas_investigacion SET activo = ? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$estado ? 1 : 0, $id]);
    }
    
    public function toggleActivoDimension(int $id, bool $estado): bool {
        $sql = "UPDATE dimensiones_operativas SET activo = ? WHERE id = ?";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([$estado ? 1 : 0, $id]);
    }
}