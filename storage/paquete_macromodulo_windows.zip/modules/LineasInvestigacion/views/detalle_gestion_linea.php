<?php
// modules/LineasInvestigacion/views/detalle_gestion_linea.php
$isSuper = ($_SESSION['nivel_privilegio'] ?? 999) === 0;
?>



    <!-- BREADCRUMBS -->
    <div style="margin-bottom: 1rem; font-size: 0.85rem; font-weight: 600;">
        <a href="index.php?ruta=dashboard" style="color: var(--color-secundario); text-decoration: none; transition: color 0.2s;"><i class="ph-bold ph-squares-four"></i> Dashboard</a>
        <span style="color: var(--color-borde); margin: 0 0.5rem;">/</span>
        <a href="index.php?ruta=gestionar-lineas" style="color: var(--color-secundario); text-decoration: none; transition: color 0.2s;">Gestión de Líneas</a>
        <span style="color: var(--color-borde); margin: 0 0.5rem;">/</span>
        <span style="color: var(--texto-silenciado);">Detalle de la Línea</span>
    </div>
    <div class="li-gestor-wrapper">

    <!-- ENCABEZADO -->
    <div class="ag-header-banner">
        <canvas id="li-nodes-canvas" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; pointer-events: none; z-index: 0; opacity: 0.6;"></canvas>
        <div style="display: flex; gap: 1.8rem; align-items: flex-start; position: relative; z-index: 1;">
            <div style="width: 72px; height: 72px; border-radius: 16px; background: rgba(255,255,255, 0.1); border: 1px solid rgba(255,255,255, 0.2); display: flex; align-items: center; justify-content: center; font-size: 2.2rem; color: #ffffff; flex-shrink: 0; backdrop-filter: blur(4px);">
                <i class="ph-bold ph-graph"></i>
            </div>
            <div style="flex: 1;">
                <div class="ag-header-subtitle">
                    GESTOR DEDICADO DE LÍNEA • PNF EN <?= htmlspecialchars(mb_convert_case($linea['carrera_nombre'] ?? 'Sin Asignar', MB_CASE_UPPER, 'UTF-8')) ?>
                </div>
                <h1 class="ag-header-title">
                    <?= htmlspecialchars(mb_convert_case($linea['nombre'], MB_CASE_TITLE, 'UTF-8')) ?>
                </h1>
                <p class="ag-header-desc">
                    <?= htmlspecialchars(mb_convert_encoding($linea['descripcion'], 'UTF-8', 'CP850')) ?>
                </p>
                
                <div style="display: flex; align-items: center; gap: 12px; margin-top: 1.5rem;">
                    <button type="button" onclick="abrirModalEditarLinea(<?= htmlspecialchars(json_encode($linea)) ?>)" style="background: rgba(255,255,255,0.15); color: #ffffff; border: 1px solid rgba(255,255,255,0.3); padding: 10px 20px; border-radius: 8px; font-weight: 700; font-size: 0.9rem; cursor: pointer; transition: 0.2s; display: inline-flex; align-items: center; gap: 6px;" onmouseover="this.style.background='rgba(255,255,255,0.25)'" onmouseout="this.style.background='rgba(255,255,255,0.15)'">
                        <i class="ph-bold ph-pencil-simple"></i> Editar Línea
                    </button>
                    <a href="index.php?ruta=gestionar-lineas" style="background: rgba(255,255,255,0.1); color: #ffffff; border: 1px solid rgba(255,255,255,0.2); padding: 10px 20px; border-radius: 8px; font-weight: 700; font-size: 0.9rem; text-decoration: none; transition: 0.2s; display: inline-flex; align-items: center; gap: 6px;" onmouseover="this.style.background=\'rgba(255,255,255,0.2)\'" onmouseout="this.style.background=\'rgba(255,255,255,0.1)\'">
                        <i class="ph-bold ph-arrow-left"></i> Volver a Líneas
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- ALERTAS -->
    <?php if (!empty($mensaje)): ?>
    <div class="li-alert <?= htmlspecialchars($tipo_mensaje) ?>">
        <i class="ph-bold <?= $tipo_mensaje === 'exito' ? 'ph-check-circle' : 'ph-warning-circle' ?>"></i>
        <?= $mensaje ?>
    </div>
    <?php endif; ?>

    <!-- KPIs -->
    <div class="ag-kpi-grid">
        <div class="ag-kpi-card">
            <div class="ag-kpi-label">Total Dimensiones</div>
            <div class="ag-kpi-value"><?= count($dimensiones) ?></div>
        </div>
        <div class="ag-kpi-card" style="border-left-color: var(--color-secundario, #059669);">
            <div class="ag-kpi-label">Proyectos Vinculados</div>
            <div class="ag-kpi-value" style="color:var(--color-secundario, #059669);">
                <?= htmlspecialchars($linea['total_proyectos'] ?? 0) ?>
            </div>
        </div>
    </div>

    <!-- LISTA DE DIMENSIONES -->
    <div class="ag-list-container">
        
        <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:2px solid #e2e8f0; padding-bottom:1.2rem; margin-bottom:1.8rem;">
            <div>
                <h2 style="margin:0 0 0.3rem 0; font-size:1.4rem; color:var(--texto-titulos, #0f172a); font-weight: 800;"><i class="ph-bold ph-squares-four"></i> Dimensiones Operativas (Componentes)</h2>
                <p style="margin:0; font-size:0.95rem; color:var(--texto-silenciado, #64748b);">Gestione las dimensiones asociadas a esta línea de investigación.</p>
            </div>
            <button type="button" onclick="abrirModalCrearDimension(<?= htmlspecialchars($linea['id']) ?>)" style="background: #505984; color: #ffffff; border: none; padding: 12px 24px; border-radius: 8px; font-weight: 700; font-size: 0.95rem; cursor: pointer; transition: 0.2s; box-shadow: 0 4px 12px rgba(80,89,132,0.3);" onmouseover="this.style.background='#3C456A'; this.style.transform='translateY(-2px)'" onmouseout="this.style.background='#505984'; this.style.transform='translateY(0)'">
                <i class="ph-bold ph-plus"></i> Añadir Dimensión
            </button>
        </div>

        <?php if (count($dimensiones) > 0): ?>
            <?php foreach($dimensiones as $dim): ?>
                <div class="ag-dim-item">
                    <div style="flex:1;">
                        <div class="ag-dim-title"><?= htmlspecialchars(mb_convert_case($dim['nombre'], MB_CASE_TITLE, 'UTF-8')) ?></div>
                        <div class="ag-dim-desc"><?= htmlspecialchars(mb_convert_encoding($dim['descripcion'], 'UTF-8', 'CP850')) ?></div>
                    </div>
                    <div style="display:flex; gap:10px; margin-left:2rem;">
                        <button type="button" class="ag-btn-edit" onclick="abrirModalEditarDimension(<?= htmlspecialchars(json_encode($dim)) ?>)">
                            <i class="ph-bold ph-pencil-simple"></i> Editar
                        </button>
                        
                        <?php if (isset($dim['activo']) && $dim['activo']): ?>
                            <button type="button" class="ag-btn-edit" style="background:#f59e0b; color:white; border-color:#f59e0b;" onclick="ocultarDimension(<?= htmlspecialchars($dim['id']) ?>, '<?= htmlspecialchars(addslashes($dim['nombre'])) ?>')">
                                <i class="ph-bold ph-eye-slash"></i> Ocultar
                            </button>
                        <?php else: ?>
                            <button type="button" class="ag-btn-edit" style="background:#10b981; color:white; border-color:#10b981;" onclick="mostrarDimension(<?= htmlspecialchars($dim['id']) ?>)">
                                <i class="ph-bold ph-eye"></i> Mostrar
                            </button>
                        <?php endif; ?>
                        
                        <?php if ($isSuper): ?>
                        <button type="button" class="ag-btn-delete" onclick="eliminarDimension(<?= htmlspecialchars($dim['id']) ?>, '<?= htmlspecialchars(addslashes($dim['nombre'])) ?>')">
                            <i class="ph-bold ph-trash"></i> Eliminar
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="text-align:center; padding: 4rem 0;">
                <div style="width: 80px; height: 80px; background: #f1f5f9; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1.5rem auto;">
                    <i class="ph-bold ph-ghost" style="font-size:2.5rem; color:#94a3b8;"></i>
                </div>
                <h3 style="color:#475569; margin:0 0 0.5rem 0; font-size: 1.2rem;">No hay dimensiones operativas</h3>
                <p style="color:#64748b; font-size:0.95rem;">Comience añadiendo la primera dimensión operativa para esta línea.</p>
            </div>
        <?php endif; ?>

    </div>

    <!-- LISTA DE PROFESORES AFILIADOS -->
    <div class="ag-list-container" style="margin-top: 2rem;">
        <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:2px solid #e2e8f0; padding-bottom:1.2rem; margin-bottom:1.8rem;">
            <div>
                <h2 style="margin:0 0 0.3rem 0; font-size:1.4rem; color:var(--texto-titulos, #0f172a); font-weight: 800;"><i class="ph-bold ph-users-three"></i> Profesores Afiliados</h2>
                <p style="margin:0; font-size:0.95rem; color:var(--texto-silenciado, #64748b);">Gestione los docentes vinculados al desarrollo de esta línea.</p>
            </div>
            <button type="button" onclick="abrirModalVincularProfesor()" style="background: #10b981; color: #ffffff; border: none; padding: 12px 24px; border-radius: 8px; font-weight: 700; font-size: 0.95rem; cursor: pointer; transition: 0.2s; box-shadow: 0 4px 12px rgba(16,185,129,0.3);" onmouseover="this.style.background='#059669'; this.style.transform='translateY(-2px)'" onmouseout="this.style.background='#10b981'; this.style.transform='translateY(0)'">
                <i class="ph-bold ph-plus"></i> Vincular Profesor
            </button>
        </div>

        <?php if (!empty($profesoresAfiliados)): ?>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1rem;">
            <?php foreach($profesoresAfiliados as $prof): ?>
                <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 1rem; display: flex; align-items: center; justify-content: space-between;">
                    <div style="display: flex; align-items: center; gap: 0.8rem;">
                        <i class="ph-fill ph-user-circle" style="font-size: 2.5rem; color: #505984;"></i>
                        <div>
                            <div style="font-weight: 700; color: #1e293b;"><?= htmlspecialchars($prof['nombre_profesor']) ?></div>
                            <div style="font-size: 0.8rem; color: #64748b;"><?= htmlspecialchars($prof['email']) ?></div>
                        </div>
                    </div>
                    <?php if ($isSuper || true): ?>
                    <button type="button" class="ag-btn-delete" style="padding: 0.5rem; border-radius: 50%; width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;" onclick="desvincularProfesor(<?= $prof['id'] ?>, '<?= htmlspecialchars(addslashes($prof['nombre_profesor'])) ?>')" title="Desvincular">
                        <i class="ph-bold ph-x"></i>
                    </button>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div style="text-align:center; padding: 2rem 0;">
                <div style="width: 60px; height: 60px; background: #f1f5f9; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem auto;">
                    <i class="ph-bold ph-users-slash" style="font-size:2rem; color:#94a3b8;"></i>
                </div>
                <h3 style="color:#475569; margin:0 0 0.5rem 0; font-size: 1.1rem;">No hay profesores vinculados</h3>
                <p style="color:#64748b; font-size:0.9rem;">Vincule docentes para que aparezcan en el portal público de la línea.</p>
            </div>
        <?php endif; ?>
    </div>

</div>

<!-- Formularios Ocultos -->
<form id="formEliminarDimension" method="POST" action="index.php?ruta=gestionar-dimensiones" style="display:none;">
    <input type="hidden" name="accion" value="eliminar">
        <?= CSRF::campoOculto() ?>
    <input type="hidden" name="id" id="deleteDimensionId" value="">
    <input type="hidden" name="redirect_to" value="detalle-gestion-linea&id=<?= $linea['id'] ?>">
</form>

<form id="formProfesorAction" method="POST" action="index.php?ruta=detalle-gestion-linea&id=<?= $linea['id'] ?>" style="display:none;">
    <input type="hidden" name="accion" id="profesorAccionValue" value="">
    <?= CSRF::campoOculto() ?>
    <input type="hidden" name="id_linea" value="<?= $linea['id'] ?>">
    <input type="hidden" name="id_profesor" id="profesorIdValue" value="">
</form>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function abrirModalVincularProfesor() {
    let optionsHtml = '';
    <?php foreach ($profesoresDisponibles as $p): ?>
    optionsHtml += `<option value="<?= $p['id'] ?>"><?= htmlspecialchars(addslashes($p['nombre_completo'])) ?> (<?= htmlspecialchars(addslashes($p['email'])) ?>)</option>`;
    <?php endforeach; ?>

    if (optionsHtml === '') {
        Swal.fire('Información', 'No hay profesores disponibles para vincular (todos están vinculados o no hay docentes registrados).', 'info');
        return;
    }

    Swal.fire({
        title: 'Vincular Profesor',
        customClass: { popup: 'ag-swal-popup' },
        html: `
            <div style="text-align: left; margin-top: 1rem;">
                <label class="ag-modal-label">Seleccione un profesor</label>
                <select id="select-profesor" class="ag-modal-input" style="width: 100%; padding: 10px; border-radius: 8px; border: 1px solid #cbd5e1;">
                    <option value="">-- Seleccionar --</option>
                    ${optionsHtml}
                </select>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: '<i class="ph-bold ph-link"></i> Vincular',
        cancelButtonText: 'Cancelar',
        confirmButtonColor: '#10b981',
        cancelButtonColor: '#94a3b8',
        preConfirm: () => {
            const val = document.getElementById('select-profesor').value;
            if (!val) {
                Swal.showValidationMessage('Debe seleccionar un profesor');
                return false;
            }
            document.getElementById('profesorAccionValue').value = 'vincular_profesor';
            document.getElementById('profesorIdValue').value = val;
            document.getElementById('formProfesorAction').submit();
        }
    });
}

function desvincularProfesor(id, nombre) {
    Swal.fire({
        title: '¿Desvincular profesor?',
        html: `El profesor <strong>${nombre}</strong> ya no aparecerá afiliado a esta línea.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        cancelButtonColor: '#64748b',
        confirmButtonText: '<i class="ph-bold ph-x"></i> Desvincular',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('profesorAccionValue').value = 'desvincular_profesor';
            document.getElementById('profesorIdValue').value = id;
            document.getElementById('formProfesorAction').submit();
        }
    });
}

function abrirModalEditarLinea(linea) {
    Swal.fire({
        title: 'Editar Línea de Investigación',
        customClass: { popup: 'ag-swal-popup' },
        html: `
            <div style="text-align: left; margin-top: 1rem;">
                <form id="form-edit-linea" method="POST" action="index.php?ruta=gestionar-lineas">
                    <input type="hidden" name="accion" value="editar">
                    <?= CSRF::campoOculto() ?>
                    <input type="hidden" name="id" value="${linea.id}">
                    <input type="hidden" name="id_carrera" value="${linea.id_carrera}">
                    <input type="hidden" name="redirect_to" value="detalle-gestion-linea&id=${linea.id}">
                    
                    <div style="margin-bottom:1.2rem;">
                        <label class="ag-modal-label">Nombre</label>
                        <input type="text" name="nombre" class="ag-modal-input" required value="${linea.nombre.replace(/"/g, '&quot;')}">
                    </div>
                    <div>
                        <label class="ag-modal-label">Descripción</label>
                        <textarea name="descripcion" class="ag-modal-input" style="height:220px; resize:vertical;" required>${linea.descripcion}</textarea>
                    </div>
                </form>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: '<i class="ph-bold ph-floppy-disk"></i> Guardar Cambios',
        cancelButtonText: 'Cancelar',
        confirmButtonColor: '#505984',
        cancelButtonColor: '#94a3b8',
        preConfirm: () => {
            const form = document.getElementById('form-edit-linea');
            if (!form.nombre.value || !form.descripcion.value) {
                Swal.showValidationMessage('Todos los campos son obligatorios');
                return false;
            }
            form.submit();
        }
    });
}

function eliminarDimension(id, nombre) {
    Swal.fire({
        title: '¡ADVERTENCIA CRÍTICA!',
        html: `Estás a punto de eliminar definitivamente la dimensión <strong>${nombre}</strong>.<br><br>` + 
              `<span style="color:#ef4444; font-weight:bold;">¡ESTO DEJARÁ PROYECTOS HUÉRFANOS!</span><br>` +
              `Los proyectos o postulaciones PST vinculados específicamente a esta dimensión quedarán en el aire sin categorización válida en la base de datos.<br><br>` + 
              `Para proceder, escribe la palabra <b>ELIMINAR</b> en mayúsculas:`,
        icon: 'error',
        input: 'text',
        inputPlaceholder: 'Escribe ELIMINAR',
        showCancelButton: true,
        confirmButtonColor: '#ef4444',
        cancelButtonColor: '#64748b',
        confirmButtonText: '<i class="ph-bold ph-trash"></i> Ejecutar Borrado Crítico',
        cancelButtonText: 'Cancelar',
        customClass: { popup: 'ag-swal-popup' },
        preConfirm: (inputValue) => {
            if (inputValue !== 'ELIMINAR') {
                Swal.showValidationMessage('Debes escribir la palabra ELIMINAR en mayúsculas.');
                return false;
            }
            return true;
        }
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('deleteDimensionId').value = id;
            document.getElementById('formEliminarDimension').submit();
        }
    });
}

function abrirModalCrearDimension(idLinea) {
    Swal.fire({
        title: 'Añadir Dimensión',
        customClass: { popup: 'ag-swal-popup' },
        html: `
            <div style="text-align: left; margin-top: 1rem;">
                <form id="form-create-dim" method="POST" action="index.php?ruta=gestionar-dimensiones">
                    <input type="hidden" name="accion" value="crear">
                    <?= CSRF::campoOculto() ?>
                    <input type="hidden" name="id_linea" value="${idLinea}">
                    <input type="hidden" name="redirect_to" value="detalle-gestion-linea&id=${idLinea}">
                    
                    <div style="margin-bottom:1.2rem;">
                        <label class="ag-modal-label">Nombre de la Dimensión</label>
                        <input type="text" name="nombre" class="ag-modal-input" required placeholder="Ej: Infraestructura Tecnológica">
                    </div>
                    <div>
                        <label class="ag-modal-label">Descripción</label>
                        <textarea name="descripcion" class="ag-modal-input" style="height:220px; resize:vertical;" required placeholder="Detalla el enfoque de la dimensión..."></textarea>
                    </div>
                </form>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: '<i class="ph-bold ph-floppy-disk"></i> Guardar',
        cancelButtonText: 'Cancelar',
        confirmButtonColor: '#505984',
        cancelButtonColor: '#94a3b8',
        preConfirm: () => {
            const form = document.getElementById('form-create-dim');
            if (!form.nombre.value || !form.descripcion.value) {
                Swal.showValidationMessage('Todos los campos son obligatorios');
                return false;
            }
            form.submit();
        }
    });
}

function abrirModalEditarDimension(dim) {
    Swal.fire({
        title: 'Editar Dimensión',
        customClass: { popup: 'ag-swal-popup' },
        html: `
            <div style="text-align: left; margin-top: 1rem;">
                <form id="form-edit-dim" method="POST" action="index.php?ruta=gestionar-dimensiones">
                    <input type="hidden" name="accion" value="editar">
                    <?= CSRF::campoOculto() ?>
                    <input type="hidden" name="id" value="${dim.id}">
                    <input type="hidden" name="id_linea" value="${dim.id_linea}">
                    <input type="hidden" name="redirect_to" value="detalle-gestion-linea&id=${dim.id_linea}">
                    
                    <div style="margin-bottom:1.2rem;">
                        <label class="ag-modal-label">Nombre</label>
                        <input type="text" name="nombre" class="ag-modal-input" required value="${dim.nombre.replace(/"/g, '&quot;')}">
                    </div>
                    <div>
                        <label class="ag-modal-label">Descripción</label>
                        <textarea name="descripcion" class="ag-modal-input" style="height:220px; resize:vertical;" required>${dim.descripcion}</textarea>
                    </div>
                </form>
            </div>
        `,
        showCancelButton: true,
        confirmButtonText: '<i class="ph-bold ph-floppy-disk"></i> Guardar Cambios',
        cancelButtonText: 'Cancelar',
        confirmButtonColor: '#505984',
        cancelButtonColor: '#94a3b8',
        preConfirm: () => {
            const form = document.getElementById('form-edit-dim');
            if (!form.nombre.value || !form.descripcion.value) {
                Swal.showValidationMessage('Todos los campos son obligatorios');
                return false;
            }
            form.submit();
        }
    });
}
</script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const canvas = document.getElementById('li-nodes-canvas');
    if (canvas) {
        const ctx = canvas.getContext('2d');
        let width = canvas.width = canvas.offsetWidth;
        let height = canvas.height = canvas.offsetHeight;
        
        window.addEventListener('resize', () => {
            if (!canvas) return;
            width = canvas.width = canvas.offsetWidth;
            height = canvas.height = canvas.offsetHeight;
        });

        const particles = [];
        const numParticles = 40;

        for (let i = 0; i < numParticles; i++) {
            particles.push({
                x: Math.random() * width,
                y: Math.random() * height,
                vx: (Math.random() - 0.5) * 0.5,
                vy: (Math.random() - 0.5) * 0.5,
                radius: Math.random() * 2 + 1.2
            });
        }

        function animate() {
            ctx.clearRect(0, 0, width, height);

            for (let i = 0; i < numParticles; i++) {
                const p = particles[i];
                p.x += p.vx;
                p.y += p.vy;

                if (p.x < 0 || p.x > width) p.vx *= -1;
                if (p.y < 0 || p.y > height) p.vy *= -1;

                ctx.beginPath();
                ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
                ctx.fillStyle = 'rgba(112, 144, 203, 0.75)';
                ctx.fill();

                for (let j = i + 1; j < numParticles; j++) {
                    const p2 = particles[j];
                    const dx = p.x - p2.x;
                    const dy = p.y - p2.y;
                    const dist = Math.sqrt(dx * dx + dy * dy);
                    
                    if (dist < 100) {
                        ctx.beginPath();
                        ctx.moveTo(p.x, p.y);
                        ctx.lineTo(p2.x, p2.y);
                        ctx.strokeStyle = `rgba(112, 144, 203, ${0.4 - dist/250})`;
                        ctx.lineWidth = 0.8;
                        ctx.stroke();
                    }
                }
            }
            requestAnimationFrame(animate);
        }
        animate();
    }
});
</script>
</body>


<form id="formOcultarDim" method="POST" action="index.php?ruta=detalle-gestion-linea&id=<?= urlencode($linea['id']) ?>" style="display:none;">
    <input type="hidden" name="accion" value="ocultar">
    <input type="hidden" name="id" id="inputIdOcultarDim">
    <?= CSRF::campoOculto() ?>
</form>

<form id="formMostrarDim" method="POST" action="index.php?ruta=detalle-gestion-linea&id=<?= urlencode($linea['id']) ?>" style="display:none;">
    <input type="hidden" name="accion" value="mostrar">
    <input type="hidden" name="id" id="inputIdMostrarDim">
    <?= CSRF::campoOculto() ?>
</form>

<script>
function ocultarDimension(id, nombre) {
    Swal.fire({
        title: '¿Ocultar Dimensión?',
        html: `La dimensión <strong>${nombre}</strong> se ocultará, pero sus proyectos permanecerán.`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#f59e0b',
        cancelButtonColor: '#64748b',
        confirmButtonText: 'Ocultar',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            document.getElementById('inputIdOcultarDim').value = id;
            document.getElementById('formOcultarDim').submit();
        }
    });
}
function mostrarDimension(id) {
    document.getElementById('inputIdMostrarDim').value = id;
    document.getElementById('formMostrarDim').submit();
}
</script>
</div> <!-- end wrapper -->
