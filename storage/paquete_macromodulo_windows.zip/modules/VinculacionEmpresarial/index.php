<?php
// modules/VinculacionEmpresarial/index.php

require_once CORE_PATH . 'Interfaces/ModuleContract.php';
require_once __DIR__ . '/../SuperAdmin/services/SystemConfigService.php';

class VinculacionEmpresarialModule implements ModuleContract {
    
    public function getNombre(): string {
        return 'Módulo de Vinculación Empresarial';
    }

    public function getRutas(): array {
        // Definimos la ruta del CSS específico de este módulo.
        $css_modulo = ['vinculacion.css'];

        return [
            'empresas-inicio' => [
                'vista'  => __DIR__ . '/views/landing_informativa.php', 
                'titulo' => 'Vinculación Empresarial - UPTTMBI',
                'css'    => $css_modulo
            ],
            // Tablero Unificado para el Comité de Proyectos
            'gestion-proyectos' => [
                'vista'  => __DIR__ . '/views/gestion_proyectos.php', 
                'titulo' => 'Gestión de Solicitudes',
                'css'    => $css_modulo,
                'controlador' => 'VinculacionController',
                'controlador_path' => __DIR__ . '/controllers/VinculacionController.php',
                'metodo' => 'gestionProyectos'
            ],
            'banco-propuestas' => [
                'vista'  => __DIR__ . '/views/gestion_proyectos.php', 
                'titulo' => 'Gestión de Solicitudes',
                'css'    => $css_modulo,
                'controlador' => 'VinculacionController',
                'controlador_path' => __DIR__ . '/controllers/VinculacionController.php',
                'metodo' => 'gestionProyectos'
            ],
            'gestion-equipos' => [
                'vista'  => __DIR__ . '/views/gestion_proyectos.php', 
                'titulo' => 'Gestión de Solicitudes',
                'css'    => $css_modulo,
                'controlador' => 'VinculacionController',
                'controlador_path' => __DIR__ . '/controllers/VinculacionController.php',
                'metodo' => 'gestionProyectos'
            ],
            'guardar-propuesta' => [
                'vista' => __DIR__ . '/controllers/VinculacionController.php',
                'metodo' => 'guardarPropuesta',
                'oculto' => true
            ],
            'procesar-propuesta' => [
                'vista' => __DIR__ . '/controllers/VinculacionController.php',
                'metodo' => 'procesarPropuesta',
                'oculto' => true
            ],
            'seguimiento-empresa' => [
                'vista'  => __DIR__ . '/views/seguimiento_empresa.php', 
                'titulo' => 'Rastrea tu Propuesta - CIIDI',
                'css'    => $css_modulo
            ],
            'guardar-configuracion' => ['vista' => __DIR__ . '/controllers/VinculacionController.php', 'metodo' => 'guardarConfiguracion', 'oculto' => true],
            'vinculacion-config' => ['vista' => __DIR__ . '/views/configuracion.php', 'titulo' => 'Configuración de Vinculación', 'css' => $css_modulo, 'controlador' => 'VinculacionController', 'controlador_path' => __DIR__ . '/controllers/VinculacionController.php', 'metodo' => 'configuracion'], 'cartelera-oportunidades' => [
                'vista'  => __DIR__ . '/views/cartelera_oportunidades.php', 
                'titulo' => 'Cartelera de Oportunidades',
                'css'    => $css_modulo,
                'controlador' => 'VinculacionController',
                'controlador_path' => __DIR__ . '/controllers/VinculacionController.php',
                'metodo' => 'carteleraOportunidades'
            ],
            'postular-oportunidad' => [
                'vista' => __DIR__ . '/controllers/VinculacionController.php',
                'metodo' => 'postularOportunidad',
                'oculto' => true
            ],
            'procesar-asignacion' => [
                'vista' => __DIR__ . '/controllers/VinculacionController.php',
                'metodo' => 'procesarAsignacion',
                'oculto' => true
            ],
            'api-transparencia' => [
                'controlador'      => 'TransparenciaController',
                'controlador_path' => __DIR__ . '/controllers/TransparenciaController.php',
                'metodo'           => 'rastrear',
                'oculto'           => true
            ],
            'postulaciones-pst' => [
                'vista'  => __DIR__ . '/views/postulaciones_pst.php',
                'titulo' => 'Postulaciones PST',
                'css'    => $css_modulo,
                'controlador' => 'ProfesorPSTController',
                'controlador_path' => __DIR__ . '/controllers/ProfesorPSTController.php',
                'metodo' => 'panel'
            ],
            'revisar-postulacion-pst' => [
                'vista' => __DIR__ . '/controllers/ProfesorPSTController.php',
                'metodo' => 'revisarPostulacion',
                'oculto' => true
            ],
            'guardar-mi-perfil-pst' => [
                'vista' => __DIR__ . '/controllers/ProfesorPSTController.php',
                'metodo' => 'guardarMiPerfil',
                'oculto' => true
            ],
            'profesores-pst' => [
                'vista'  => __DIR__ . '/views/profesores_pst.php',
                'titulo' => 'Docentes PST',
                'css'    => $css_modulo,
                'controlador' => 'ProfesorPSTController',
                'controlador_path' => __DIR__ . '/controllers/ProfesorPSTController.php',
                'metodo' => 'gestionProfesores'
            ],
            'guardar-profesor-pst' => [
                'vista' => __DIR__ . '/controllers/ProfesorPSTController.php',
                'metodo' => 'guardarProfesor',
                'oculto' => true
            ],
            'resolver-registro-docente' => [
                'vista' => __DIR__ . '/controllers/ProfesorPSTController.php',
                'metodo' => 'resolverRegistro',
                'oculto' => true
            ],
            'resolver-solicitud-pst' => [
                'vista' => __DIR__ . '/controllers/ProfesorPSTController.php',
                'metodo' => 'resolverSolicitudAcreditacion',
                'oculto' => true
            ]
        ];
    }

    public function getMenuConfig(): array {
        $nivelAdmin = 0;
        $nivelPublico = 999;
        $nivelLogueado = 999;
        return [
            [
                'tipo'        => 'parent',
                'titulo'      => 'Sector Productivo',
                'icono'       => 'ph-fill ph-buildings',
                'orden'       => 60,
                'grupo'       => 'lineas-investigacion',
                'orden_en_grupo' => 40,
                'enlace'      => 'empresas-inicio',
                'privilegio_minimo' =>  $nivelPublico,
                'activadores' => ['empresas-inicio', 'seguimiento-empresa', 'cartelera-oportunidades', 'gestion-proyectos', 'banco-propuestas', 'gestion-equipos', 'vinculacion-config', 'postulaciones-pst', 'profesores-pst'], 
                'subitems'    => [
                    ['ruta' => 'empresas-inicio', 'titulo' => 'Conócenos', 'privilegio_minimo' => $nivelPublico,],
                    ['ruta' => 'cartelera-oportunidades', 'titulo' => 'Oportunidades PST', 'privilegio_minimo' => $nivelLogueado],
                    ['ruta' => 'seguimiento-empresa', 'titulo' => 'Seguimiento', 'privilegio_minimo' => $nivelPublico,],
                    ['ruta' => 'gestion-proyectos', 'titulo' => 'Gestión de Solicitudes', 'privilegio_minimo' => $nivelLogueado, 'roles_permitidos' => ['Super Administrador', 'Comité', 'Profesor', 'Docentes']],
                    ['ruta' => 'vinculacion-config', 'titulo' => 'Configuración', 'privilegio_minimo' => $nivelAdmin]
                ]
            ]
        ];
    }
    public function getDescripcion(): string {
        return 'Puente con el sector productivo. Banco de problemas y recepción de solicitudes de empresas externas.';
    }
    public function getDependencias(): array {
        return [];
    }
    public function getHomeConfig(): array {
        return [
            'icono'       => 'ph-fill ph-buildings',
            'titulo' => 'Sector Productivo',
            'descripcion' => 'Conexión directa entre las necesidades tecnológicas del sector productivo y las soluciones de nuestro talento académico.',
            'enlace'      => 'empresas-inicio', 
            'texto_boton' => 'SECTOR PRODUCTIVO',
            'destacado'   => false 
        ];
    }
     public function getHeaderConfig(): array {
        return [];
    }
}

return new VinculacionEmpresarialModule();
