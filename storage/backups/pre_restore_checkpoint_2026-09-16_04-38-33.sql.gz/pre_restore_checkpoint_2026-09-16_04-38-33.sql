--
-- PostgreSQL database dump
--

\restrict EyIjV4b3ZwMAbxG8brlR0uVSgZ6pCq0IYZodnMEPn56JvsinAwRYjvDu1gPFgan

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_id_rol_fkey;
ALTER TABLE ONLY public.registro_actividad DROP CONSTRAINT registro_actividad_id_visitante_fkey;
ALTER TABLE ONLY public.registro_actividad DROP CONSTRAINT registro_actividad_id_usuario_fkey;
ALTER TABLE ONLY public.recursos DROP CONSTRAINT recursos_id_tipo_recurso_fkey;
ALTER TABLE ONLY public.recurso_categorias DROP CONSTRAINT recurso_categorias_id_recurso_fkey;
ALTER TABLE ONLY public.recurso_categorias DROP CONSTRAINT recurso_categorias_id_categoria_fkey;
ALTER TABLE ONLY public.recurso_autores DROP CONSTRAINT recurso_autores_id_recurso_fkey;
ALTER TABLE ONLY public.recurso_autores DROP CONSTRAINT recurso_autores_id_autor_fkey;
ALTER TABLE ONLY public.proyecto_tutores DROP CONSTRAINT proyecto_tutores_tipo_tutor_id_fkey;
ALTER TABLE ONLY public.proyecto_tutores DROP CONSTRAINT proyecto_tutores_id_tutor_fkey;
ALTER TABLE ONLY public.proyecto_tutores DROP CONSTRAINT proyecto_tutores_id_recurso_fkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT privilegio_fk;
ALTER TABLE ONLY public.preferencias_usuario DROP CONSTRAINT preferencias_usuario_id_usuario_fkey;
ALTER TABLE ONLY public.notificaciones DROP CONSTRAINT notificaciones_id_usuario_fkey;
ALTER TABLE ONLY public.lineas_investigacion DROP CONSTRAINT lineas_investigacion_id_carrera_fkey;
ALTER TABLE ONLY public.historico_versiones_pst DROP CONSTRAINT fk_version_recurso;
ALTER TABLE ONLY public.recurso_etiquetas DROP CONSTRAINT fk_recurso_etiqueta;
ALTER TABLE ONLY public.recurso_clasificaciones DROP CONSTRAINT fk_recurso;
ALTER TABLE ONLY public.postulaciones_estudiantes DROP CONSTRAINT fk_postulacion_inv;
ALTER TABLE ONLY public.postulaciones_estudiantes DROP CONSTRAINT fk_postulacion_estudiante;
ALTER TABLE ONLY public.recurso_clasificaciones DROP CONSTRAINT fk_linea_investigacion;
ALTER TABLE ONLY public.investigaciones_ofertadas DROP CONSTRAINT fk_inv_propuesta;
ALTER TABLE ONLY public.investigaciones_ofertadas DROP CONSTRAINT fk_inv_profesor;
ALTER TABLE ONLY public.investigaciones_ofertadas DROP CONSTRAINT fk_inv_linea;
ALTER TABLE ONLY public.investigaciones_ofertadas DROP CONSTRAINT fk_inv_dimension;
ALTER TABLE ONLY public.recurso_etiquetas DROP CONSTRAINT fk_etiqueta_recurso;
ALTER TABLE ONLY public.recurso_clasificaciones DROP CONSTRAINT fk_dimension_operativa;
ALTER TABLE ONLY public.dimensiones_operativas DROP CONSTRAINT fk_dimension_linea;
ALTER TABLE ONLY public.detalles_investigaciones DROP CONSTRAINT fk_detalles_investigaciones_recurso;
ALTER TABLE ONLY public.detalles_investigaciones DROP CONSTRAINT fk_detalles_investigaciones_ofertada;
ALTER TABLE ONLY public.detalles_articulos DROP CONSTRAINT fk_detalles_articulos_categoria;
ALTER TABLE ONLY public.detalles_articulos DROP CONSTRAINT detalles_revistas_id_recurso_fkey;
ALTER TABLE ONLY public.detalles_articulos DROP CONSTRAINT detalles_revistas_id_editorial_fkey;
ALTER TABLE ONLY public.detalles_proyectos DROP CONSTRAINT detalles_proyectos_id_recurso_fkey;
ALTER TABLE ONLY public.detalles_proyectos DROP CONSTRAINT detalles_proyectos_id_investigacion_padre_fkey;
ALTER TABLE ONLY public.detalles_proyectos DROP CONSTRAINT detalles_proyectos_id_carrera_fkey;
ALTER TABLE ONLY public.cursos DROP CONSTRAINT cursos_id_docente_fkey;
ALTER TABLE ONLY public.auditoria DROP CONSTRAINT auditoria_usuario_responsable_fkey;
ALTER TABLE ONLY public.accesos_recursos DROP CONSTRAINT accesos_recursos_id_registro_actividad_fkey;
ALTER TABLE ONLY public.accesos_recursos DROP CONSTRAINT accesos_recursos_id_recurso_fkey;
DROP TRIGGER tg_auditoria_usuarios_update ON public.usuarios;
DROP TRIGGER tg_auditoria_usuarios_insert ON public.usuarios;
DROP TRIGGER tg_auditoria_usuarios_delete ON public.usuarios;
DROP TRIGGER tg_auditoria_recursos_insert ON public.recursos;
DROP TRIGGER tg_auditoria_recursos_delete ON public.recursos;
DROP INDEX public.idx_recurso_clasif_linea;
DROP INDEX public.idx_recurso_clasif_dimension;
DROP INDEX public.idx_detalles_inv_ofertada;
ALTER TABLE ONLY public.visitantes DROP CONSTRAINT visitantes_pkey;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_pkey;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_email_key;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_cedula_key;
ALTER TABLE ONLY public.postulaciones_estudiantes DROP CONSTRAINT unique_postulacion;
ALTER TABLE ONLY public.tutores DROP CONSTRAINT tutores_pkey;
ALTER TABLE ONLY public.tutores DROP CONSTRAINT tutores_cedula_key;
ALTER TABLE ONLY public.tipo_tutor DROP CONSTRAINT tipo_tutor_pkey;
ALTER TABLE ONLY public.tipo_tutor DROP CONSTRAINT tipo_tutor_nombre_key;
ALTER TABLE ONLY public.tipo_recurso DROP CONSTRAINT tipo_recurso_pkey;
ALTER TABLE ONLY public.tipo_recurso DROP CONSTRAINT tipo_recurso_nombre_key;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_pkey;
ALTER TABLE ONLY public.roles DROP CONSTRAINT roles_nombre_key;
ALTER TABLE ONLY public.registro_actividad DROP CONSTRAINT registro_actividad_pkey;
ALTER TABLE ONLY public.recursos DROP CONSTRAINT recursos_pkey;
ALTER TABLE ONLY public.recurso_etiquetas DROP CONSTRAINT recurso_etiquetas_pkey;
ALTER TABLE ONLY public.recurso_clasificaciones DROP CONSTRAINT recurso_clasificaciones_pkey;
ALTER TABLE ONLY public.recurso_categorias DROP CONSTRAINT recurso_categorias_pkey;
ALTER TABLE ONLY public.recurso_autores DROP CONSTRAINT recurso_autores_pkey;
ALTER TABLE ONLY public.proyecto_tutores DROP CONSTRAINT proyecto_tutores_pkey;
ALTER TABLE ONLY public.propuestas_empresa DROP CONSTRAINT propuestas_empresa_pkey;
ALTER TABLE ONLY public.propuestas_empresa DROP CONSTRAINT propuestas_empresa_codigo_seguimiento_key;
ALTER TABLE ONLY public.privilegios DROP CONSTRAINT privilegios_pkey;
ALTER TABLE ONLY public.preferencias_usuario DROP CONSTRAINT preferencias_usuario_pkey;
ALTER TABLE ONLY public.postulaciones_estudiantes DROP CONSTRAINT postulaciones_estudiantes_pkey;
ALTER TABLE ONLY public.notificaciones DROP CONSTRAINT notificaciones_pkey;
ALTER TABLE ONLY public.lineas_investigacion DROP CONSTRAINT lineas_investigacion_pkey;
ALTER TABLE ONLY public.investigaciones_ofertadas DROP CONSTRAINT investigaciones_ofertadas_pkey;
ALTER TABLE ONLY public.historico_versiones_pst DROP CONSTRAINT historico_versiones_pst_pkey;
ALTER TABLE ONLY public.etiquetas DROP CONSTRAINT etiquetas_pkey;
ALTER TABLE ONLY public.etiquetas DROP CONSTRAINT etiquetas_nombre_key;
ALTER TABLE ONLY public.editoriales DROP CONSTRAINT editoriales_pkey;
ALTER TABLE ONLY public.editoriales DROP CONSTRAINT editoriales_nombre_key;
ALTER TABLE ONLY public.dimensiones_operativas DROP CONSTRAINT dimensiones_operativas_pkey;
ALTER TABLE ONLY public.detalles_articulos DROP CONSTRAINT detalles_revistas_pkey;
ALTER TABLE ONLY public.detalles_proyectos DROP CONSTRAINT detalles_proyectos_pkey;
ALTER TABLE ONLY public.detalles_investigaciones DROP CONSTRAINT detalles_investigaciones_pkey;
ALTER TABLE ONLY public.cursos DROP CONSTRAINT cursos_pkey;
ALTER TABLE ONLY public.categorias DROP CONSTRAINT categorias_pkey;
ALTER TABLE ONLY public.categorias DROP CONSTRAINT categorias_nombre_key;
ALTER TABLE ONLY public.carreras DROP CONSTRAINT carreras_pkey;
ALTER TABLE ONLY public.carreras DROP CONSTRAINT carreras_nombre_key;
ALTER TABLE ONLY public.autores DROP CONSTRAINT autores_pkey;
ALTER TABLE ONLY public.autores DROP CONSTRAINT autores_cedula_key;
ALTER TABLE ONLY public.auditoria DROP CONSTRAINT auditoria_pkey;
ALTER TABLE ONLY public.accesos_recursos DROP CONSTRAINT accesos_recursos_pkey;
ALTER TABLE public.visitantes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.usuarios ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tutores ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tipo_tutor ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tipo_recurso ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.registro_actividad ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.recursos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.propuestas_empresa ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.privilegios ALTER COLUMN privilegio_id DROP DEFAULT;
ALTER TABLE public.postulaciones_estudiantes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.notificaciones ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.lineas_investigacion ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.investigaciones_ofertadas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.historico_versiones_pst ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.etiquetas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.editoriales ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dimensiones_operativas ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.cursos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.categorias ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.carreras ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.autores ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auditoria ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.accesos_recursos ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.visitantes_id_seq;
DROP TABLE public.visitantes;
DROP SEQUENCE public.usuarios_id_seq;
DROP TABLE public.usuarios;
DROP SEQUENCE public.tutores_id_seq;
DROP TABLE public.tutores;
DROP SEQUENCE public.tipo_tutor_id_seq;
DROP TABLE public.tipo_tutor;
DROP SEQUENCE public.tipo_recurso_id_seq;
DROP TABLE public.tipo_recurso;
DROP SEQUENCE public.roles_id_seq;
DROP TABLE public.roles;
DROP SEQUENCE public.registro_actividad_id_seq;
DROP TABLE public.registro_actividad;
DROP SEQUENCE public.recursos_id_seq;
DROP TABLE public.recursos;
DROP TABLE public.recurso_etiquetas;
DROP TABLE public.recurso_clasificaciones;
DROP TABLE public.recurso_categorias;
DROP TABLE public.recurso_autores;
DROP TABLE public.proyecto_tutores;
DROP SEQUENCE public.propuestas_empresa_id_seq;
DROP TABLE public.propuestas_empresa;
DROP SEQUENCE public.privilegios_privilegio_id_seq;
DROP TABLE public.privilegios;
DROP TABLE public.preferencias_usuario;
DROP SEQUENCE public.postulaciones_estudiantes_id_seq;
DROP TABLE public.postulaciones_estudiantes;
DROP SEQUENCE public.notificaciones_id_seq;
DROP TABLE public.notificaciones;
DROP SEQUENCE public.lineas_investigacion_id_seq;
DROP TABLE public.lineas_investigacion;
DROP SEQUENCE public.investigaciones_ofertadas_id_seq;
DROP TABLE public.investigaciones_ofertadas;
DROP SEQUENCE public.historico_versiones_pst_id_seq;
DROP TABLE public.historico_versiones_pst;
DROP SEQUENCE public.etiquetas_id_seq;
DROP TABLE public.etiquetas;
DROP SEQUENCE public.editoriales_id_seq;
DROP TABLE public.editoriales;
DROP SEQUENCE public.dimensiones_operativas_id_seq;
DROP TABLE public.dimensiones_operativas;
DROP TABLE public.detalles_proyectos;
DROP TABLE public.detalles_investigaciones;
DROP TABLE public.detalles_articulos;
DROP SEQUENCE public.cursos_id_seq;
DROP TABLE public.cursos;
DROP SEQUENCE public.categorias_id_seq;
DROP TABLE public.categorias;
DROP SEQUENCE public.carreras_id_seq;
DROP TABLE public.carreras;
DROP SEQUENCE public.autores_id_seq;
DROP TABLE public.autores;
DROP SEQUENCE public.auditoria_id_seq;
DROP TABLE public.auditoria;
DROP SEQUENCE public.accesos_recursos_id_seq;
DROP TABLE public.accesos_recursos;
DROP PROCEDURE public.insertarproyectoaleatorio(IN fecha_creada timestamp without time zone);
DROP FUNCTION public.fn_auditoria_usuarios();
DROP FUNCTION public.fn_auditoria_recursos();
DROP TYPE public.tipo_pregunta_enum;
DROP TYPE public.tipo_interaccion_usuario_enum;
DROP TYPE public.tipo_interaccion_enum;
DROP TYPE public.nivel_academico_enum;
DROP TYPE public.estado_propuesta_enum;
DROP TYPE public.estado_curso_enum;
DROP TYPE public.accion_auditoria_enum;
DROP TYPE public.accion_acceso_enum;
--
-- Name: accion_acceso_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.accion_acceso_enum AS ENUM (
    'visualizacion',
    'descarga'
);


ALTER TYPE public.accion_acceso_enum OWNER TO postgres;

--
-- Name: accion_auditoria_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.accion_auditoria_enum AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE'
);


ALTER TYPE public.accion_auditoria_enum OWNER TO postgres;

--
-- Name: estado_curso_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.estado_curso_enum AS ENUM (
    'borrador',
    'publicado',
    'archivado'
);


ALTER TYPE public.estado_curso_enum OWNER TO postgres;

--
-- Name: estado_propuesta_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.estado_propuesta_enum AS ENUM (
    'pendiente',
    'aceptada',
    'rechazada'
);


ALTER TYPE public.estado_propuesta_enum OWNER TO postgres;

--
-- Name: nivel_academico_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.nivel_academico_enum AS ENUM (
    'TSU',
    'Pregrado',
    'Especializacion',
    'Maestria',
    'Doctorado'
);


ALTER TYPE public.nivel_academico_enum OWNER TO postgres;

--
-- Name: tipo_interaccion_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tipo_interaccion_enum AS ENUM (
    'like',
    'bookmark'
);


ALTER TYPE public.tipo_interaccion_enum OWNER TO postgres;

--
-- Name: tipo_interaccion_usuario_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tipo_interaccion_usuario_enum AS ENUM (
    'like',
    'guardado'
);


ALTER TYPE public.tipo_interaccion_usuario_enum OWNER TO postgres;

--
-- Name: tipo_pregunta_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tipo_pregunta_enum AS ENUM (
    'multiple',
    'v_f',
    'corta'
);


ALTER TYPE public.tipo_pregunta_enum OWNER TO postgres;

--
-- Name: fn_auditoria_recursos(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_auditoria_recursos() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Intenta leer una variable de sesión configurada por el backend, si no hay, asigna NULL
    v_usuario_actual INT := NULLIF(current_setting('app.usuario_actual', true), '')::INT; 
BEGIN
    IF (TG_OP = 'DELETE') THEN
        INSERT INTO auditoria (tabla_afectada, id_registro, accion, usuario_responsable, datos_anteriores, datos_nuevos, fecha_hora)
        VALUES ('recursos', OLD.id, 'DELETE', v_usuario_actual, jsonb_build_object('titulo', OLD.titulo, 'id_tipo_recurso', OLD.id_tipo_recurso), NULL, CURRENT_TIMESTAMP);
        RETURN OLD;
        
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO auditoria (tabla_afectada, id_registro, accion, usuario_responsable, datos_anteriores, datos_nuevos, fecha_hora)
        VALUES ('recursos', NEW.id, 'INSERT', v_usuario_actual, NULL, jsonb_build_object('titulo', NEW.titulo, 'id_tipo_recurso', NEW.id_tipo_recurso, 'ejemplares_totales', NEW.ejemplares_totales), CURRENT_TIMESTAMP);
        RETURN NEW;
    END IF;
    
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.fn_auditoria_recursos() OWNER TO postgres;

--
-- Name: fn_auditoria_usuarios(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_auditoria_usuarios() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_usuario_actual INT := NULLIF(current_setting('app.usuario_actual', true), '')::INT;
BEGIN
    IF (TG_OP = 'DELETE') THEN
        INSERT INTO auditoria (tabla_afectada, id_registro, accion, usuario_responsable, datos_anteriores, datos_nuevos, fecha_hora)
        VALUES ('usuarios', OLD.id, 'DELETE', v_usuario_actual, jsonb_build_object('nombre', OLD.nombre_completo, 'email', OLD.email, 'id_rol', OLD.id_rol), NULL, CURRENT_TIMESTAMP);
        RETURN OLD;
        
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO auditoria (tabla_afectada, id_registro, accion, usuario_responsable, datos_anteriores, datos_nuevos, fecha_hora)
        VALUES ('usuarios', NEW.id, 'INSERT', v_usuario_actual, NULL, jsonb_build_object('nombre', NEW.nombre_completo, 'email', NEW.email, 'id_rol', NEW.id_rol), CURRENT_TIMESTAMP);
        RETURN NEW;
        
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO auditoria (tabla_afectada, id_registro, accion, usuario_responsable, datos_anteriores, datos_nuevos, fecha_hora)
        VALUES ('usuarios', OLD.id, 'UPDATE', v_usuario_actual, 
                jsonb_build_object('nombre', OLD.nombre_completo, 'id_rol', OLD.id_rol, 'activo', OLD.activo), 
                jsonb_build_object('nombre', NEW.nombre_completo, 'id_rol', NEW.id_rol, 'activo', NEW.activo), 
                CURRENT_TIMESTAMP);
        RETURN NEW;
    END IF;
    
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.fn_auditoria_usuarios() OWNER TO postgres;

--
-- Name: insertarproyectoaleatorio(timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insertarproyectoaleatorio(IN fecha_creada timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE
    nuevo_id INT;
    nivel_academico_aleatorio nivel_academico_enum;
    carrera_aleatoria INT;
    titulo_base VARCHAR(255);
    palabras_clave_gen TEXT;
    resumen_texto TEXT;
    mes_actual INT;
    
    -- Arrays para simular el ELT de MySQL
    arr_niveles1 VARCHAR[] := ARRAY['TSU', 'Pregrado', 'Especializacion', 'Maestria'];
    arr_niveles2 VARCHAR[] := ARRAY['Especializacion', 'Maestria', 'Doctorado'];
    arr_niveles3 VARCHAR[] := ARRAY['TSU', 'Pregrado', 'Especializacion', 'Maestria', 'Doctorado'];
    
    arr_tit_acc VARCHAR[] := ARRAY['Sistema', 'Aplicación', 'Plataforma', 'Prototipo', 'Análisis', 'Diseño', 'Implementación', 'Optimización', 'Automatización', 'Evaluación', 'Desarrollo', 'Modelo'];
    arr_tit_obj VARCHAR[] := ARRAY['Gestión', 'Monitoreo', 'Control', 'Predicción', 'Seguridad', 'Reconocimiento', 'Clasificación', 'Procesamiento', 'Visualización', 'Comunicación', 'Bajo Costo', 'Alto Rendimiento'];
    arr_tit_dest VARCHAR[] := ARRAY['la Comunidad', 'UPTTMBI', 'el Sector Agroalimentario', 'Zonas Rurales', 'Instituciones Educativas', 'Pequeñas Empresas', 'el Área de Salud', 'el Transporte Público', 'la Industria 4.0', 'la Transformación Digital'];
    
    arr_carreras VARCHAR[] := ARRAY['Informática', 'Electricidad', 'Administración', 'Agroalimentación', 'Construcción Civil'];
BEGIN
    mes_actual := EXTRACT(MONTH FROM fecha_creada);

    -- Asignar nivel académico
    IF mes_actual IN (4,8) THEN
        nivel_academico_aleatorio := arr_niveles1[floor(random() * 4 + 1)::int]::nivel_academico_enum;
    ELSIF mes_actual = 12 THEN
        nivel_academico_aleatorio := arr_niveles2[floor(random() * 3 + 1)::int]::nivel_academico_enum;
    ELSE
        nivel_academico_aleatorio := arr_niveles3[floor(random() * 5 + 1)::int]::nivel_academico_enum;
    END IF;

    -- Ajustar pesos específicos
    IF random() < 0.4 THEN 
        nivel_academico_aleatorio := 'Pregrado';
    ELSIF random() < 0.25 THEN 
        nivel_academico_aleatorio := 'TSU';
    END IF;

    -- Carrera aleatoria
    carrera_aleatoria := floor(random() * 5 + 1)::int;

    -- Título dinámico
    titulo_base := arr_tit_acc[floor(random() * 12 + 1)::int] || ' de ' || 
                   arr_tit_obj[floor(random() * 12 + 1)::int] || ' para ' || 
                   arr_tit_dest[floor(random() * 10 + 1)::int];

    -- Resumen
    resumen_texto := 'Proyecto desarrollado en ' || arr_carreras[carrera_aleatoria] || '. Aborda problemáticas reales con enfoque práctico.';

    -- Insertar recurso y capturar el ID generado (RETURNING id)
    INSERT INTO recursos (titulo, id_tipo_recurso, anio_publicacion, ejemplares_totales, ejemplares_disponibles)
    VALUES (titulo_base, 1, EXTRACT(YEAR FROM fecha_creada), 1, 1)
    RETURNING id INTO nuevo_id;

    -- Insertar detalle proyecto
    INSERT INTO detalles_proyectos (id_recurso, fecha_defensa, nivel_academico, resumen, id_carrera, comunidad_beneficiada, palabras_clave, created_at) 
    VALUES (nuevo_id, (fecha_creada + (floor(random() * 90)::int || ' days')::interval)::date, nivel_academico_aleatorio, resumen_texto, carrera_aleatoria, 'Comunidad Generica', 'tecnologia, innovacion', fecha_creada);

    -- Relacionar con un autor aleatorio o el autor por defecto 1
    INSERT INTO recurso_autores (id_recurso, id_autor)
    SELECT nuevo_id, id FROM autores WHERE id BETWEEN 14 AND 29 ORDER BY random() LIMIT 1;
    
    -- Si no insertó (por no hallar autor en ese rango), fuerza el autor 1
    IF NOT FOUND THEN
        INSERT INTO recurso_autores (id_recurso, id_autor) VALUES (nuevo_id, 1);
    END IF;
END;
$$;


ALTER PROCEDURE public.insertarproyectoaleatorio(IN fecha_creada timestamp without time zone) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accesos_recursos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accesos_recursos (
    id integer NOT NULL,
    id_registro_actividad integer NOT NULL,
    id_recurso integer NOT NULL,
    accion public.accion_acceso_enum DEFAULT 'visualizacion'::public.accion_acceso_enum,
    fecha_acceso timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.accesos_recursos OWNER TO postgres;

--
-- Name: accesos_recursos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accesos_recursos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accesos_recursos_id_seq OWNER TO postgres;

--
-- Name: accesos_recursos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accesos_recursos_id_seq OWNED BY public.accesos_recursos.id;


--
-- Name: auditoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auditoria (
    id integer NOT NULL,
    tabla_afectada character varying(50) NOT NULL,
    id_registro integer NOT NULL,
    accion public.accion_auditoria_enum NOT NULL,
    usuario_responsable integer,
    ip_origen character varying(45),
    datos_anteriores jsonb,
    datos_nuevos jsonb,
    fecha_hora timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.auditoria OWNER TO postgres;

--
-- Name: auditoria_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auditoria_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.auditoria_id_seq OWNER TO postgres;

--
-- Name: auditoria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auditoria_id_seq OWNED BY public.auditoria.id;


--
-- Name: autores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.autores (
    id integer NOT NULL,
    nombre_completo character varying(150) NOT NULL,
    cedula character varying(20)
);


ALTER TABLE public.autores OWNER TO postgres;

--
-- Name: autores_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.autores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.autores_id_seq OWNER TO postgres;

--
-- Name: autores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.autores_id_seq OWNED BY public.autores.id;


--
-- Name: carreras; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carreras (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion text
);


ALTER TABLE public.carreras OWNER TO postgres;

--
-- Name: carreras_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.carreras_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.carreras_id_seq OWNER TO postgres;

--
-- Name: carreras_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.carreras_id_seq OWNED BY public.carreras.id;


--
-- Name: categorias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categorias (
    id integer NOT NULL,
    nombre character varying(150) NOT NULL
);


ALTER TABLE public.categorias OWNER TO postgres;

--
-- Name: categorias_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categorias_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categorias_id_seq OWNER TO postgres;

--
-- Name: categorias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categorias_id_seq OWNED BY public.categorias.id;


--
-- Name: cursos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cursos (
    id integer NOT NULL,
    id_docente integer NOT NULL,
    titulo character varying(255) NOT NULL,
    descripcion text,
    imagen_portada character varying(255),
    estado public.estado_curso_enum DEFAULT 'borrador'::public.estado_curso_enum NOT NULL,
    nota_minima_aprobacion numeric(5,2) DEFAULT 70.00 NOT NULL,
    fecha_creacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.cursos OWNER TO postgres;

--
-- Name: cursos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cursos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cursos_id_seq OWNER TO postgres;

--
-- Name: cursos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cursos_id_seq OWNED BY public.cursos.id;


--
-- Name: detalles_articulos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detalles_articulos (
    id_recurso integer CONSTRAINT detalles_revistas_id_recurso_not_null NOT NULL,
    id_editorial integer,
    volumen character varying(50),
    numero character varying(50),
    issn character varying(20),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    imagen_portada character varying(255) DEFAULT 'default_article.jpg'::character varying,
    resumen text,
    id_categoria integer,
    activo boolean DEFAULT true
);


ALTER TABLE public.detalles_articulos OWNER TO postgres;

--
-- Name: detalles_investigaciones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detalles_investigaciones (
    id_recurso integer NOT NULL,
    planteamiento_problema text NOT NULL,
    objetivo_general text NOT NULL,
    id_investigacion_ofertada integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.detalles_investigaciones OWNER TO postgres;

--
-- Name: detalles_proyectos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detalles_proyectos (
    id_recurso integer NOT NULL,
    fecha_defensa date,
    nivel_academico public.nivel_academico_enum DEFAULT 'Pregrado'::public.nivel_academico_enum,
    resumen text,
    id_carrera integer,
    comunidad_beneficiada text,
    palabras_clave text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    id_investigacion_padre integer,
    trayecto character varying(50) DEFAULT 'Trayecto I'::character varying,
    url_repositorio text,
    activo boolean DEFAULT true,
    obj_general text
);


ALTER TABLE public.detalles_proyectos OWNER TO postgres;

--
-- Name: dimensiones_operativas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dimensiones_operativas (
    id integer NOT NULL,
    id_linea integer NOT NULL,
    nombre character varying(150) NOT NULL,
    descripcion text
);


ALTER TABLE public.dimensiones_operativas OWNER TO postgres;

--
-- Name: dimensiones_operativas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dimensiones_operativas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dimensiones_operativas_id_seq OWNER TO postgres;

--
-- Name: dimensiones_operativas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dimensiones_operativas_id_seq OWNED BY public.dimensiones_operativas.id;


--
-- Name: editoriales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.editoriales (
    id integer NOT NULL,
    nombre character varying(150) NOT NULL
);


ALTER TABLE public.editoriales OWNER TO postgres;

--
-- Name: editoriales_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.editoriales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.editoriales_id_seq OWNER TO postgres;

--
-- Name: editoriales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.editoriales_id_seq OWNED BY public.editoriales.id;


--
-- Name: etiquetas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.etiquetas (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    color_hex character varying(7) DEFAULT '#0ea5e9'::character varying
);


ALTER TABLE public.etiquetas OWNER TO postgres;

--
-- Name: etiquetas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.etiquetas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.etiquetas_id_seq OWNER TO postgres;

--
-- Name: etiquetas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.etiquetas_id_seq OWNED BY public.etiquetas.id;


--
-- Name: historico_versiones_pst; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.historico_versiones_pst (
    id integer NOT NULL,
    id_recurso integer NOT NULL,
    archivo_pdf character varying(500) NOT NULL,
    usuario_id integer,
    motivo character varying(255) DEFAULT 'Actualización'::character varying,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.historico_versiones_pst OWNER TO postgres;

--
-- Name: historico_versiones_pst_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.historico_versiones_pst_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.historico_versiones_pst_id_seq OWNER TO postgres;

--
-- Name: historico_versiones_pst_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.historico_versiones_pst_id_seq OWNED BY public.historico_versiones_pst.id;


--
-- Name: investigaciones_ofertadas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.investigaciones_ofertadas (
    id integer NOT NULL,
    id_profesor integer NOT NULL,
    titulo character varying(255) NOT NULL,
    planteamiento_problema text NOT NULL,
    objetivo_general text NOT NULL,
    id_linea integer NOT NULL,
    id_dimension integer,
    cupos_disponibles integer DEFAULT 3,
    estado character varying(20) DEFAULT 'Abierta'::character varying,
    fecha_creacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    id_propuesta_empresa integer,
    CONSTRAINT investigaciones_ofertadas_estado_check CHECK (((estado)::text = ANY (ARRAY[('Abierta'::character varying)::text, ('Cerrada'::character varying)::text, ('En Desarrollo'::character varying)::text, ('Finalizada'::character varying)::text])))
);


ALTER TABLE public.investigaciones_ofertadas OWNER TO postgres;

--
-- Name: investigaciones_ofertadas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.investigaciones_ofertadas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.investigaciones_ofertadas_id_seq OWNER TO postgres;

--
-- Name: investigaciones_ofertadas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.investigaciones_ofertadas_id_seq OWNED BY public.investigaciones_ofertadas.id;


--
-- Name: lineas_investigacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lineas_investigacion (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    id_carrera integer NOT NULL,
    descripcion text
);


ALTER TABLE public.lineas_investigacion OWNER TO postgres;

--
-- Name: lineas_investigacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lineas_investigacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lineas_investigacion_id_seq OWNER TO postgres;

--
-- Name: lineas_investigacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lineas_investigacion_id_seq OWNED BY public.lineas_investigacion.id;


--
-- Name: notificaciones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notificaciones (
    id integer NOT NULL,
    id_usuario integer,
    titulo character varying(255),
    mensaje text,
    leido boolean DEFAULT false,
    fecha_hora timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    fecha timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notificaciones OWNER TO postgres;

--
-- Name: notificaciones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notificaciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notificaciones_id_seq OWNER TO postgres;

--
-- Name: notificaciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notificaciones_id_seq OWNED BY public.notificaciones.id;


--
-- Name: postulaciones_estudiantes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.postulaciones_estudiantes (
    id integer NOT NULL,
    id_investigacion integer NOT NULL,
    id_estudiante integer NOT NULL,
    mensaje_motivacion text,
    estado character varying(20) DEFAULT 'Pendiente'::character varying,
    fecha_postulacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    fecha_respuesta timestamp without time zone,
    equipo_extra json,
    CONSTRAINT postulaciones_estudiantes_estado_check CHECK (((estado)::text = ANY (ARRAY[('Pendiente'::character varying)::text, ('Aceptado'::character varying)::text, ('Rechazado'::character varying)::text])))
);


ALTER TABLE public.postulaciones_estudiantes OWNER TO postgres;

--
-- Name: postulaciones_estudiantes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.postulaciones_estudiantes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.postulaciones_estudiantes_id_seq OWNER TO postgres;

--
-- Name: postulaciones_estudiantes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.postulaciones_estudiantes_id_seq OWNED BY public.postulaciones_estudiantes.id;


--
-- Name: preferencias_usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.preferencias_usuario (
    id_usuario integer NOT NULL,
    tema character varying(50) DEFAULT 'light'::character varying,
    notificaciones_sistema boolean DEFAULT true
);


ALTER TABLE public.preferencias_usuario OWNER TO postgres;

--
-- Name: privilegios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.privilegios (
    privilegio_id integer NOT NULL,
    nivel_privilegio integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.privilegios OWNER TO postgres;

--
-- Name: privilegios_privilegio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.privilegios_privilegio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.privilegios_privilegio_id_seq OWNER TO postgres;

--
-- Name: privilegios_privilegio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.privilegios_privilegio_id_seq OWNED BY public.privilegios.privilegio_id;


--
-- Name: propuestas_empresa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.propuestas_empresa (
    id integer NOT NULL,
    nombre_empresa character varying(255) NOT NULL,
    rif_empresa character varying(50),
    persona_contacto character varying(150) NOT NULL,
    telefono_contacto character varying(50) NOT NULL,
    correo_contacto character varying(150) NOT NULL,
    area_afectada character varying(100) NOT NULL,
    descripcion_problema text NOT NULL,
    estado public.estado_propuesta_enum DEFAULT 'pendiente'::public.estado_propuesta_enum,
    fecha_creacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    nivel_trayecto character varying(50),
    codigo_seguimiento character varying(20),
    motivo_rechazo text
);


ALTER TABLE public.propuestas_empresa OWNER TO postgres;

--
-- Name: propuestas_empresa_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.propuestas_empresa_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.propuestas_empresa_id_seq OWNER TO postgres;

--
-- Name: propuestas_empresa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.propuestas_empresa_id_seq OWNED BY public.propuestas_empresa.id;


--
-- Name: proyecto_tutores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.proyecto_tutores (
    id_recurso integer NOT NULL,
    id_tutor integer NOT NULL,
    tipo_tutor_id integer
);


ALTER TABLE public.proyecto_tutores OWNER TO postgres;

--
-- Name: recurso_autores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurso_autores (
    id_recurso integer NOT NULL,
    id_autor integer NOT NULL
);


ALTER TABLE public.recurso_autores OWNER TO postgres;

--
-- Name: recurso_categorias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurso_categorias (
    id_recurso integer NOT NULL,
    id_categoria integer NOT NULL
);


ALTER TABLE public.recurso_categorias OWNER TO postgres;

--
-- Name: recurso_clasificaciones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurso_clasificaciones (
    id_recurso integer NOT NULL,
    id_linea_investigacion integer NOT NULL,
    id_dimension_operativa integer
);


ALTER TABLE public.recurso_clasificaciones OWNER TO postgres;

--
-- Name: recurso_etiquetas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurso_etiquetas (
    id_recurso integer NOT NULL,
    id_etiqueta integer NOT NULL
);


ALTER TABLE public.recurso_etiquetas OWNER TO postgres;

--
-- Name: recursos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recursos (
    id integer NOT NULL,
    titulo character varying(255) NOT NULL,
    id_tipo_recurso integer NOT NULL,
    anio_publicacion integer,
    ejemplares_totales integer DEFAULT 1,
    ejemplares_disponibles integer DEFAULT 1,
    archivo_pdf character varying(255)
);


ALTER TABLE public.recursos OWNER TO postgres;

--
-- Name: recursos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recursos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recursos_id_seq OWNER TO postgres;

--
-- Name: recursos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recursos_id_seq OWNED BY public.recursos.id;


--
-- Name: registro_actividad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.registro_actividad (
    id integer NOT NULL,
    id_usuario integer,
    id_visitante integer,
    fecha_inicial timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    ultima_actividad timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    conteo_accesos integer DEFAULT 1
);


ALTER TABLE public.registro_actividad OWNER TO postgres;

--
-- Name: registro_actividad_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.registro_actividad_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.registro_actividad_id_seq OWNER TO postgres;

--
-- Name: registro_actividad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.registro_actividad_id_seq OWNED BY public.registro_actividad.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    privilegio_id integer DEFAULT 1 CONSTRAINT roles_privilegios_id_not_null NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: tipo_recurso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_recurso (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    descripcion text
);


ALTER TABLE public.tipo_recurso OWNER TO postgres;

--
-- Name: tipo_recurso_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_recurso_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tipo_recurso_id_seq OWNER TO postgres;

--
-- Name: tipo_recurso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_recurso_id_seq OWNED BY public.tipo_recurso.id;


--
-- Name: tipo_tutor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_tutor (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    descripcion text
);


ALTER TABLE public.tipo_tutor OWNER TO postgres;

--
-- Name: tipo_tutor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_tutor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tipo_tutor_id_seq OWNER TO postgres;

--
-- Name: tipo_tutor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_tutor_id_seq OWNED BY public.tipo_tutor.id;


--
-- Name: tutores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tutores (
    id integer NOT NULL,
    nombre_completo character varying(150) NOT NULL,
    cedula character varying(20)
);


ALTER TABLE public.tutores OWNER TO postgres;

--
-- Name: tutores_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tutores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tutores_id_seq OWNER TO postgres;

--
-- Name: tutores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tutores_id_seq OWNED BY public.tutores.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    nombre_completo character varying(150) NOT NULL,
    email character varying(100),
    cedula character varying(20),
    contrasena character varying(255),
    id_rol integer,
    activo boolean DEFAULT true,
    reset_token character varying(255) DEFAULT NULL::character varying,
    reset_expires timestamp without time zone,
    telefono character varying(50) DEFAULT NULL::character varying
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuarios_id_seq OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: visitantes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.visitantes (
    id integer NOT NULL,
    ip_address character varying(45) NOT NULL,
    user_agent text,
    pagina_origen character varying(255)
);


ALTER TABLE public.visitantes OWNER TO postgres;

--
-- Name: visitantes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.visitantes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.visitantes_id_seq OWNER TO postgres;

--
-- Name: visitantes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.visitantes_id_seq OWNED BY public.visitantes.id;


--
-- Name: accesos_recursos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesos_recursos ALTER COLUMN id SET DEFAULT nextval('public.accesos_recursos_id_seq'::regclass);


--
-- Name: auditoria id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auditoria ALTER COLUMN id SET DEFAULT nextval('public.auditoria_id_seq'::regclass);


--
-- Name: autores id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.autores ALTER COLUMN id SET DEFAULT nextval('public.autores_id_seq'::regclass);


--
-- Name: carreras id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carreras ALTER COLUMN id SET DEFAULT nextval('public.carreras_id_seq'::regclass);


--
-- Name: categorias id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias ALTER COLUMN id SET DEFAULT nextval('public.categorias_id_seq'::regclass);


--
-- Name: cursos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cursos ALTER COLUMN id SET DEFAULT nextval('public.cursos_id_seq'::regclass);


--
-- Name: dimensiones_operativas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimensiones_operativas ALTER COLUMN id SET DEFAULT nextval('public.dimensiones_operativas_id_seq'::regclass);


--
-- Name: editoriales id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.editoriales ALTER COLUMN id SET DEFAULT nextval('public.editoriales_id_seq'::regclass);


--
-- Name: etiquetas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.etiquetas ALTER COLUMN id SET DEFAULT nextval('public.etiquetas_id_seq'::regclass);


--
-- Name: historico_versiones_pst id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.historico_versiones_pst ALTER COLUMN id SET DEFAULT nextval('public.historico_versiones_pst_id_seq'::regclass);


--
-- Name: investigaciones_ofertadas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investigaciones_ofertadas ALTER COLUMN id SET DEFAULT nextval('public.investigaciones_ofertadas_id_seq'::regclass);


--
-- Name: lineas_investigacion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lineas_investigacion ALTER COLUMN id SET DEFAULT nextval('public.lineas_investigacion_id_seq'::regclass);


--
-- Name: notificaciones id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notificaciones ALTER COLUMN id SET DEFAULT nextval('public.notificaciones_id_seq'::regclass);


--
-- Name: postulaciones_estudiantes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postulaciones_estudiantes ALTER COLUMN id SET DEFAULT nextval('public.postulaciones_estudiantes_id_seq'::regclass);


--
-- Name: privilegios privilegio_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.privilegios ALTER COLUMN privilegio_id SET DEFAULT nextval('public.privilegios_privilegio_id_seq'::regclass);


--
-- Name: propuestas_empresa id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.propuestas_empresa ALTER COLUMN id SET DEFAULT nextval('public.propuestas_empresa_id_seq'::regclass);


--
-- Name: recursos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recursos ALTER COLUMN id SET DEFAULT nextval('public.recursos_id_seq'::regclass);


--
-- Name: registro_actividad id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registro_actividad ALTER COLUMN id SET DEFAULT nextval('public.registro_actividad_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: tipo_recurso id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_recurso ALTER COLUMN id SET DEFAULT nextval('public.tipo_recurso_id_seq'::regclass);


--
-- Name: tipo_tutor id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_tutor ALTER COLUMN id SET DEFAULT nextval('public.tipo_tutor_id_seq'::regclass);


--
-- Name: tutores id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tutores ALTER COLUMN id SET DEFAULT nextval('public.tutores_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Name: visitantes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visitantes ALTER COLUMN id SET DEFAULT nextval('public.visitantes_id_seq'::regclass);


--
-- Data for Name: accesos_recursos; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: auditoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.auditoria VALUES (1, 'usuarios', 1, 'INSERT', NULL, NULL, NULL, '{"email": "andru@gmail.com", "id_rol": 1, "nombre": "Adrus"}', '2026-03-23 14:09:42');
INSERT INTO public.auditoria VALUES (2, 'usuarios', 2, 'INSERT', NULL, NULL, NULL, '{"email": "lando@gmail.com", "id_rol": 2, "nombre": "lando"}', '2026-03-23 14:09:42');
INSERT INTO public.auditoria VALUES (3, 'usuarios', 3, 'INSERT', NULL, NULL, NULL, '{"email": "miki@gmail.com", "id_rol": 3, "nombre": "miki"}', '2026-03-23 14:09:42');
INSERT INTO public.auditoria VALUES (4, 'usuarios', 4, 'INSERT', NULL, NULL, NULL, '{"email": "ale@yaju.com", "id_rol": 3, "nombre": "ale"}', '2026-03-23 14:09:42');
INSERT INTO public.auditoria VALUES (5, 'recursos', 1, 'INSERT', NULL, NULL, NULL, '{"titulo": "Sistema de Reconocimiento Biométrico Facial para Comedor Universitario", "id_tipo_recurso": 1, "ejemplares_totales": 1}', '2026-03-23 14:09:42');
INSERT INTO public.auditoria VALUES (6, 'recursos', 2, 'INSERT', NULL, NULL, NULL, '{"titulo": "Prototipo de Cerradura Digital con Matriz de Teclado y Arduino", "id_tipo_recurso": 1, "ejemplares_totales": 1}', '2026-03-23 14:09:42');
INSERT INTO public.auditoria VALUES (7, 'recursos', 3, 'INSERT', NULL, NULL, NULL, '{"titulo": "Aplicación de Redes Neuronales Convolucionales para la Detección de Plagas en Cultivos Trujillanos", "id_tipo_recurso": 2, "ejemplares_totales": 1}', '2026-03-23 14:09:42');
INSERT INTO public.auditoria VALUES (8, 'usuarios', 4, 'UPDATE', 1, NULL, '{"activo": 1, "id_rol": 3, "nombre": "ale"}', '{"activo": 1, "id_rol": 1, "nombre": "ale"}', '2026-03-23 16:14:24');
INSERT INTO public.auditoria VALUES (9, 'recursos', 4, 'INSERT', NULL, NULL, NULL, '{"titulo": "Impacto del Cambio Climático en Trujillo - Parte 8", "id_tipo_recurso": 2, "ejemplares_totales": 1}', '2026-03-23 16:56:13');
INSERT INTO public.auditoria VALUES (10, 'recursos', 5, 'INSERT', NULL, NULL, NULL, '{"titulo": "Simulación de Cargas Estáticas en Puentes - Parte 7", "id_tipo_recurso": 2, "ejemplares_totales": 1}', '2026-03-23 16:57:08');
INSERT INTO public.auditoria VALUES (11, 'recursos', 6, 'INSERT', NULL, NULL, NULL, '{"titulo": "Big Data en Finanzas Institucionales - Parte 9", "id_tipo_recurso": 1, "ejemplares_totales": 1}', '2026-03-23 16:58:11');
INSERT INTO public.auditoria VALUES (12, 'recursos', 7, 'INSERT', NULL, NULL, NULL, '{"titulo": "Optimización de CPU en Servidores Locales - Parte 7", "id_tipo_recurso": 1, "ejemplares_totales": 1}', '2026-03-23 16:58:11');
INSERT INTO public.auditoria VALUES (13, 'recursos', 8, 'INSERT', NULL, NULL, NULL, '{"titulo": "Sistemas de Riego Automatizado - Parte 5", "id_tipo_recurso": 1, "ejemplares_totales": 1}', '2026-03-23 16:58:11');
INSERT INTO public.auditoria VALUES (14, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 3, "nombre": "piña"}', '{"activo": true, "id_rol": 3, "nombre": "piña"}', '2026-06-18 18:46:17.662484');
INSERT INTO public.auditoria VALUES (15, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 3, "nombre": "piña"}', '{"activo": true, "id_rol": 3, "nombre": "piña"}', '2026-06-18 19:05:42.587427');
INSERT INTO public.auditoria VALUES (16, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 3, "nombre": "piña"}', '{"activo": true, "id_rol": 3, "nombre": "piña"}', '2026-06-18 19:54:46.993547');
INSERT INTO public.auditoria VALUES (17, 'usuarios', 7, 'INSERT', NULL, NULL, NULL, '{"email": "erwazaaaa@gmail.com", "id_rol": 3, "nombre": "Migel González"}', '2026-06-18 20:58:57.768568');
INSERT INTO public.auditoria VALUES (18, 'usuarios', 8, 'INSERT', NULL, NULL, NULL, '{"email": "yisu@gmail.com", "id_rol": 3, "nombre": "Yisu Monte"}', '2026-06-18 20:59:49.682537');
INSERT INTO public.auditoria VALUES (19, 'usuarios', 7, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 3, "nombre": "Migel González"}', '{"activo": true, "id_rol": 1, "nombre": "Migel González"}', '2026-06-18 21:38:28.663879');
INSERT INTO public.auditoria VALUES (20, 'usuarios', 9, 'INSERT', NULL, NULL, NULL, '{"email": "iaiaia@gmail.com", "id_rol": 3, "nombre": "Pedro Perez"}', '2026-06-24 23:07:53.05286');
INSERT INTO public.auditoria VALUES (21, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 3, "nombre": "piña"}', '{"activo": true, "id_rol": 3, "nombre": "Piñin"}', '2026-06-24 23:57:15.201582');
INSERT INTO public.auditoria VALUES (22, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 3, "nombre": "Piñin"}', '{"activo": true, "id_rol": 4, "nombre": "Piñin"}', '2026-06-24 23:57:20.104368');
INSERT INTO public.auditoria VALUES (23, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 4, "nombre": "Piñin"}', '{"activo": true, "id_rol": 2, "nombre": "Piñin"}', '2026-06-24 23:57:31.726744');
INSERT INTO public.auditoria VALUES (24, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 2, "nombre": "Piñin"}', '{"activo": true, "id_rol": 4, "nombre": "Piñin"}', '2026-06-24 23:57:37.330082');
INSERT INTO public.auditoria VALUES (25, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 4, "nombre": "Piñin"}', '{"activo": true, "id_rol": 4, "nombre": "Piñin"}', '2026-06-25 00:01:40.353031');
INSERT INTO public.auditoria VALUES (26, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 4, "nombre": "Piñin"}', '{"activo": true, "id_rol": 4, "nombre": "Piñin"}', '2026-06-25 00:01:46.873155');
INSERT INTO public.auditoria VALUES (27, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 4, "nombre": "Piñin"}', '{"activo": true, "id_rol": 4, "nombre": "Piñin Piña"}', '2026-06-25 00:01:55.730238');
INSERT INTO public.auditoria VALUES (28, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 4, "nombre": "Piñin Piña"}', '{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}', '2026-06-25 00:23:15.783421');
INSERT INTO public.auditoria VALUES (29, 'usuarios', 10, 'INSERT', NULL, NULL, NULL, '{"email": "wazaaa@gmail.com", "id_rol": 3, "nombre": "Wazaaaa"}', '2026-06-25 00:33:07.592137');
INSERT INTO public.auditoria VALUES (30, 'usuarios', 11, 'INSERT', NULL, NULL, NULL, '{"email": "123@gmail.com", "id_rol": 3, "nombre": "Juan"}', '2026-06-25 00:33:28.49575');
INSERT INTO public.auditoria VALUES (31, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}', '{"activo": true, "id_rol": 4, "nombre": "Piñin Piña"}', '2026-06-25 00:34:43.439159');
INSERT INTO public.auditoria VALUES (32, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 4, "nombre": "Piñin Piña"}', '{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}', '2026-06-25 00:34:45.543113');
INSERT INTO public.auditoria VALUES (33, 'usuarios', 10, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 3, "nombre": "Wazaaaa"}', '{"activo": false, "id_rol": 3, "nombre": "Wazaaaa"}', '2026-06-25 00:34:51.608311');
INSERT INTO public.auditoria VALUES (34, 'usuarios', 10, 'UPDATE', NULL, NULL, '{"activo": false, "id_rol": 3, "nombre": "Wazaaaa"}', '{"activo": true, "id_rol": 3, "nombre": "Wazaaaa"}', '2026-06-25 00:35:18.586051');
INSERT INTO public.auditoria VALUES (35, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}', '{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}', '2026-06-25 00:57:51.974985');
INSERT INTO public.auditoria VALUES (36, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}', '{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}', '2026-06-25 00:57:57.479012');
INSERT INTO public.auditoria VALUES (37, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}', '{"activo": true, "id_rol": 4, "nombre": "Piñin Piña"}', '2026-06-25 00:58:00.692516');
INSERT INTO public.auditoria VALUES (38, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 4, "nombre": "Piñin Piña"}', '{"activo": true, "id_rol": 4, "nombre": "Piñin Piña"}', '2026-06-25 00:58:05.014824');
INSERT INTO public.auditoria VALUES (39, 'usuarios', 10, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 3, "nombre": "Wazaaaa"}', '{"activo": true, "id_rol": 1, "nombre": "Wazaaaa"}', '2026-06-25 00:58:32.420893');
INSERT INTO public.auditoria VALUES (40, 'usuarios', 7, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 1, "nombre": "Migel González"}', '{"activo": true, "id_rol": 1, "nombre": "Miguel González"}', '2026-06-25 01:22:04.451131');
INSERT INTO public.auditoria VALUES (41, 'usuarios', 6, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 4, "nombre": "Piñin Piña"}', '{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}', '2026-06-29 11:45:47.198869');
INSERT INTO public.auditoria VALUES (123, 'recursos', 61, 'INSERT', NULL, NULL, NULL, '{"titulo": "ASASDA", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-09 16:59:31.204976');
INSERT INTO public.auditoria VALUES (42, 'usuarios', 10, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 1, "nombre": "Wazaaaa"}', '{"activo": true, "id_rol": 3, "nombre": "Wazaaaa"}', '2026-06-29 12:10:37.626132');
INSERT INTO public.auditoria VALUES (43, 'usuarios', 10, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 3, "nombre": "Wazaaaa"}', '{"activo": true, "id_rol": 1, "nombre": "Wazaaaa"}', '2026-06-29 14:18:17.58523');
INSERT INTO public.auditoria VALUES (44, 'usuarios', 10, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 1, "nombre": "Wazaaaa"}', '{"activo": true, "id_rol": 4, "nombre": "Wazaaaa"}', '2026-06-29 14:18:34.834966');
INSERT INTO public.auditoria VALUES (45, 'usuarios', 10, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 4, "nombre": "Wazaaaa"}', '{"activo": true, "id_rol": 4, "nombre": "Wazaaaa"}', '2026-06-29 14:19:05.388306');
INSERT INTO public.auditoria VALUES (46, 'recursos', 21, 'INSERT', NULL, NULL, NULL, '{"titulo": "Betty yo a usted la amo", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-04 23:19:52.515406');
INSERT INTO public.auditoria VALUES (47, 'recursos', 22, 'INSERT', NULL, NULL, NULL, '{"titulo": "Don Pepe el de los Globos", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 11:43:06.035947');
INSERT INTO public.auditoria VALUES (48, 'recursos', 23, 'INSERT', NULL, NULL, NULL, '{"titulo": "La Gran Verge", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 11:47:05.718779');
INSERT INTO public.auditoria VALUES (49, 'recursos', 24, 'INSERT', NULL, NULL, NULL, '{"titulo": "Pepe", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 12:02:34.181399');
INSERT INTO public.auditoria VALUES (50, 'recursos', 25, 'INSERT', NULL, NULL, NULL, '{"titulo": "Luisito comunicando", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 12:18:57.684684');
INSERT INTO public.auditoria VALUES (51, 'recursos', 26, 'INSERT', NULL, NULL, NULL, '{"titulo": "Manguagua", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 12:24:53.394994');
INSERT INTO public.auditoria VALUES (52, 'recursos', 27, 'INSERT', NULL, NULL, NULL, '{"titulo": "Que la guagua", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 12:29:10.583616');
INSERT INTO public.auditoria VALUES (53, 'recursos', 28, 'INSERT', NULL, NULL, NULL, '{"titulo": "En los tiempos de los apostoles", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 12:38:15.349753');
INSERT INTO public.auditoria VALUES (54, 'recursos', 22, 'DELETE', NULL, NULL, '{"titulo": "Don Pepe el de los Globos", "id_tipo_recurso": 3}', NULL, '2026-07-05 12:43:01.095251');
INSERT INTO public.auditoria VALUES (55, 'recursos', 26, 'DELETE', NULL, NULL, '{"titulo": "Manguagua", "id_tipo_recurso": 3}', NULL, '2026-07-05 12:43:29.378629');
INSERT INTO public.auditoria VALUES (58, 'recursos', 31, 'INSERT', NULL, NULL, NULL, '{"titulo": "Imitadora", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 12:57:22.541344');
INSERT INTO public.auditoria VALUES (59, 'recursos', 23, 'DELETE', NULL, NULL, '{"titulo": "La Gran Verge", "id_tipo_recurso": 3}', NULL, '2026-07-05 13:31:21.954982');
INSERT INTO public.auditoria VALUES (60, 'recursos', 32, 'INSERT', NULL, NULL, NULL, '{"titulo": "Manguagua 2", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 14:44:32.452702');
INSERT INTO public.auditoria VALUES (61, 'recursos', 33, 'INSERT', NULL, NULL, NULL, '{"titulo": "Waos", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 15:04:26.857648');
INSERT INTO public.auditoria VALUES (62, 'recursos', 33, 'DELETE', NULL, NULL, '{"titulo": "Waos", "id_tipo_recurso": 3}', NULL, '2026-07-05 15:05:03.276405');
INSERT INTO public.auditoria VALUES (63, 'recursos', 34, 'INSERT', NULL, NULL, NULL, '{"titulo": "Waos 1", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 15:24:54.658482');
INSERT INTO public.auditoria VALUES (64, 'recursos', 35, 'INSERT', NULL, NULL, NULL, '{"titulo": "Waos 2", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 15:25:19.934157');
INSERT INTO public.auditoria VALUES (65, 'recursos', 36, 'INSERT', NULL, NULL, NULL, '{"titulo": "Waos 3", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 15:25:52.428559');
INSERT INTO public.auditoria VALUES (66, 'recursos', 37, 'INSERT', NULL, NULL, NULL, '{"titulo": "23123", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 15:26:06.835471');
INSERT INTO public.auditoria VALUES (67, 'recursos', 38, 'INSERT', NULL, NULL, NULL, '{"titulo": "23", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 15:26:22.136069');
INSERT INTO public.auditoria VALUES (68, 'recursos', 39, 'INSERT', NULL, NULL, NULL, '{"titulo": "123123", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 15:26:32.188843');
INSERT INTO public.auditoria VALUES (69, 'recursos', 40, 'INSERT', NULL, NULL, NULL, '{"titulo": "123", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 15:26:43.872553');
INSERT INTO public.auditoria VALUES (70, 'recursos', 41, 'INSERT', NULL, NULL, NULL, '{"titulo": "123123", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 15:28:49.036024');
INSERT INTO public.auditoria VALUES (71, 'recursos', 42, 'INSERT', NULL, NULL, NULL, '{"titulo": "123123", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 15:28:59.682383');
INSERT INTO public.auditoria VALUES (72, 'recursos', 43, 'INSERT', NULL, NULL, NULL, '{"titulo": "123123123123", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 15:29:13.986916');
INSERT INTO public.auditoria VALUES (73, 'recursos', 44, 'INSERT', NULL, NULL, NULL, '{"titulo": "auuuu", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-05 16:15:08.182516');
INSERT INTO public.auditoria VALUES (74, 'recursos', 45, 'INSERT', NULL, NULL, NULL, '{"titulo": "Desarrollo de un Motor para Novelas Visuales Nativas usando Rust y Tauri", "id_tipo_recurso": 1, "ejemplares_totales": 2}', '2026-07-05 17:21:44.350197');
INSERT INTO public.auditoria VALUES (75, 'recursos', 46, 'INSERT', NULL, NULL, NULL, '{"titulo": "Arquitectura de L¢gica de Estados para Videojuegos en Consolas Virtuales TIC-80", "id_tipo_recurso": 1, "ejemplares_totales": 1}', '2026-07-05 17:21:44.350197');
INSERT INTO public.auditoria VALUES (76, 'recursos', 47, 'INSERT', NULL, NULL, NULL, '{"titulo": "Protocolo de Restauraci¢n y Diagn¢stico de Capacitores en Tarjetas Madre Socket 478", "id_tipo_recurso": 1, "ejemplares_totales": 3}', '2026-07-05 17:21:44.350197');
INSERT INTO public.auditoria VALUES (77, 'recursos', 48, 'INSERT', NULL, NULL, NULL, '{"titulo": "Implementaci¢n de un Enrutador Din mico basado en Arquitectura Microkernel con PHP Puro", "id_tipo_recurso": 1, "ejemplares_totales": 1}', '2026-07-05 17:21:44.350197');
INSERT INTO public.auditoria VALUES (78, 'recursos', 49, 'INSERT', NULL, NULL, NULL, '{"titulo": "Sistema de Informaci¢n Automatizado para la Gesti¢n de Inventario y Suministros M‚dicos", "id_tipo_recurso": 1, "ejemplares_totales": 1}', '2026-07-05 17:39:35.498485');
INSERT INTO public.auditoria VALUES (79, 'recursos', 50, 'INSERT', NULL, NULL, NULL, '{"titulo": "Software Educativo Multimedial para el Fortalecimiento del Aprendizaje de µlgebra Lineal", "id_tipo_recurso": 1, "ejemplares_totales": 1}', '2026-07-05 17:39:35.498485');
INSERT INTO public.auditoria VALUES (80, 'recursos', 51, 'INSERT', NULL, NULL, NULL, '{"titulo": "Plataforma Web bajo Arquitectura Cliente-Servidor para el Control de Citas Acad‚micas", "id_tipo_recurso": 1, "ejemplares_totales": 1}', '2026-07-05 17:39:35.498485');
INSERT INTO public.auditoria VALUES (81, 'recursos', 52, 'INSERT', NULL, NULL, NULL, '{"titulo": "Simulador de Enrutamiento por Estado de Enlace para la Validaci¢n de Topolog¡as Complejas", "id_tipo_recurso": 1, "ejemplares_totales": 1}', '2026-07-05 17:39:35.498485');
INSERT INTO public.auditoria VALUES (85, 'recursos', 56, 'INSERT', NULL, NULL, NULL, '{"titulo": "hola", "id_tipo_recurso": 1, "ejemplares_totales": 1}', '2026-07-05 18:14:56.263164');
INSERT INTO public.auditoria VALUES (86, 'recursos', 57, 'INSERT', NULL, NULL, NULL, '{"titulo": "hola adios", "id_tipo_recurso": 1, "ejemplares_totales": 1}', '2026-07-05 18:21:33.639701');
INSERT INTO public.auditoria VALUES (87, 'recursos', 56, 'DELETE', NULL, NULL, '{"titulo": "hola", "id_tipo_recurso": 1}', NULL, '2026-07-05 18:29:50.693972');
INSERT INTO public.auditoria VALUES (120, 'recursos', 58, 'INSERT', NULL, NULL, NULL, '{"titulo": "Middleware MiSCi para ciudades inteligentes extendido con datos enlazados", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-09 15:19:57.897052');
INSERT INTO public.auditoria VALUES (121, 'recursos', 59, 'INSERT', NULL, NULL, NULL, '{"titulo": "E", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-09 16:31:13.973946');
INSERT INTO public.auditoria VALUES (122, 'recursos', 60, 'INSERT', NULL, NULL, NULL, '{"titulo": "123", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-09 16:40:45.294611');
INSERT INTO public.auditoria VALUES (124, 'recursos', 21, 'DELETE', NULL, NULL, '{"titulo": "La Bebecita Bebelin", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:00.506138');
INSERT INTO public.auditoria VALUES (125, 'recursos', 59, 'DELETE', NULL, NULL, '{"titulo": "E", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:05.068211');
INSERT INTO public.auditoria VALUES (126, 'recursos', 61, 'DELETE', NULL, NULL, '{"titulo": "Juan", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:07.154446');
INSERT INTO public.auditoria VALUES (127, 'recursos', 60, 'DELETE', NULL, NULL, '{"titulo": "123", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:08.869819');
INSERT INTO public.auditoria VALUES (128, 'recursos', 44, 'DELETE', NULL, NULL, '{"titulo": "auuuu", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:10.961748');
INSERT INTO public.auditoria VALUES (129, 'recursos', 43, 'DELETE', NULL, NULL, '{"titulo": "123123123123", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:12.868199');
INSERT INTO public.auditoria VALUES (130, 'recursos', 42, 'DELETE', NULL, NULL, '{"titulo": "123123", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:14.485366');
INSERT INTO public.auditoria VALUES (131, 'recursos', 41, 'DELETE', NULL, NULL, '{"titulo": "123123", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:16.590235');
INSERT INTO public.auditoria VALUES (132, 'recursos', 40, 'DELETE', NULL, NULL, '{"titulo": "123", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:18.156327');
INSERT INTO public.auditoria VALUES (133, 'recursos', 39, 'DELETE', NULL, NULL, '{"titulo": "123123", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:19.628119');
INSERT INTO public.auditoria VALUES (134, 'recursos', 38, 'DELETE', NULL, NULL, '{"titulo": "23", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:21.323411');
INSERT INTO public.auditoria VALUES (135, 'recursos', 37, 'DELETE', NULL, NULL, '{"titulo": "23123", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:22.704036');
INSERT INTO public.auditoria VALUES (136, 'recursos', 36, 'DELETE', NULL, NULL, '{"titulo": "Waos 3", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:25.469091');
INSERT INTO public.auditoria VALUES (137, 'recursos', 35, 'DELETE', NULL, NULL, '{"titulo": "Waos 2", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:28.095958');
INSERT INTO public.auditoria VALUES (138, 'recursos', 34, 'DELETE', NULL, NULL, '{"titulo": "Waos 1", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:33.17519');
INSERT INTO public.auditoria VALUES (139, 'recursos', 32, 'DELETE', NULL, NULL, '{"titulo": "Manguagua", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:34.779212');
INSERT INTO public.auditoria VALUES (140, 'recursos', 31, 'DELETE', NULL, NULL, '{"titulo": "Imitadora", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:36.557448');
INSERT INTO public.auditoria VALUES (141, 'recursos', 28, 'DELETE', NULL, NULL, '{"titulo": "En los tiempos de los apostoles", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:38.469427');
INSERT INTO public.auditoria VALUES (142, 'recursos', 27, 'DELETE', NULL, NULL, '{"titulo": "Que la guagua", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:40.153464');
INSERT INTO public.auditoria VALUES (143, 'recursos', 25, 'DELETE', NULL, NULL, '{"titulo": "Luisito comunicando", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:42.016396');
INSERT INTO public.auditoria VALUES (144, 'recursos', 24, 'DELETE', NULL, NULL, '{"titulo": "Pepe", "id_tipo_recurso": 3}', NULL, '2026-07-09 20:02:43.469089');
INSERT INTO public.auditoria VALUES (145, 'recursos', 62, 'INSERT', NULL, NULL, NULL, '{"titulo": "Determinantes de la aceptación del uso de la banca móvil por parte de ganaderos", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-09 20:08:48.117741');
INSERT INTO public.auditoria VALUES (146, 'recursos', 63, 'INSERT', NULL, NULL, NULL, '{"titulo": "Modelo matemático para el balance de calor de un techo verde en condiciones de trópico húmedo", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-09 20:13:49.50881');
INSERT INTO public.auditoria VALUES (147, 'recursos', 64, 'INSERT', NULL, NULL, NULL, '{"titulo": "Revisión sistemática del impacto de las fibras de polipropileno en las propiedades físico-mecánicas, microestructurales y de durabilidad del concreto", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-09 20:16:51.643727');
INSERT INTO public.auditoria VALUES (148, 'recursos', 65, 'INSERT', NULL, NULL, NULL, '{"titulo": "Entorno virtual de capacitación con EOG para manipular robots asistenciales", "id_tipo_recurso": 3, "ejemplares_totales": 1}', '2026-07-09 20:19:28.855723');
INSERT INTO public.auditoria VALUES (149, 'usuarios', 12, 'INSERT', NULL, NULL, NULL, '{"email": "orlanndo@gmail.com", "id_rol": 1, "nombre": "mando"}', '2026-07-09 22:44:06.213847');
INSERT INTO public.auditoria VALUES (150, 'usuarios', 12, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 1, "nombre": "mando"}', '{"activo": true, "id_rol": 1, "nombre": "mando"}', '2026-07-09 22:45:11.322849');
INSERT INTO public.auditoria VALUES (151, 'usuarios', 12, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 1, "nombre": "mando"}', '{"activo": true, "id_rol": 2, "nombre": "mando"}', '2026-07-09 22:52:03.914865');
INSERT INTO public.auditoria VALUES (152, 'usuarios', 12, 'DELETE', NULL, NULL, '{"email": "orlanndo@gmail.com", "id_rol": 2, "nombre": "mando"}', NULL, '2026-07-09 22:52:03.914865');
INSERT INTO public.auditoria VALUES (153, 'usuarios', 13, 'INSERT', NULL, NULL, NULL, '{"email": "lando1609721@gmail.com", "id_rol": 3, "nombre": "landorus"}', '2026-07-09 22:52:09.392899');
INSERT INTO public.auditoria VALUES (154, 'usuarios', 13, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 3, "nombre": "landorus"}', '{"activo": true, "id_rol": 2, "nombre": "landorus"}', '2026-07-10 00:15:15.117147');
INSERT INTO public.auditoria VALUES (155, 'usuarios', 13, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 2, "nombre": "landorus"}', '{"activo": true, "id_rol": 3, "nombre": "landorus"}', '2026-07-10 00:32:43.609875');
INSERT INTO public.auditoria VALUES (156, 'usuarios', 13, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 3, "nombre": "landorus"}', '{"activo": true, "id_rol": 2, "nombre": "landorus"}', '2026-07-10 13:56:49.450118');
INSERT INTO public.auditoria VALUES (157, 'usuarios', 13, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 2, "nombre": "landorus"}', '{"activo": true, "id_rol": 3, "nombre": "landorus"}', '2026-07-11 08:20:17.188625');
INSERT INTO public.auditoria VALUES (158, 'usuarios', 13, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 3, "nombre": "landorus"}', '{"activo": true, "id_rol": 2, "nombre": "landorus"}', '2026-07-11 08:29:49.150563');
INSERT INTO public.auditoria VALUES (159, 'usuarios', 14, 'INSERT', NULL, NULL, NULL, '{"email": "pipa1234@gmail.com", "id_rol": 3, "nombre": "Pipin"}', '2026-08-20 13:12:32.533521');
INSERT INTO public.auditoria VALUES (160, 'usuarios', 14, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 3, "nombre": "Pipin"}', '{"activo": true, "id_rol": 2, "nombre": "Pipin"}', '2026-08-20 13:13:06.265487');
INSERT INTO public.auditoria VALUES (161, 'usuarios', 13, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 2, "nombre": "landorus"}', '{"activo": true, "id_rol": 2, "nombre": "landorus"}', '2026-09-13 11:11:08.793177');
INSERT INTO public.auditoria VALUES (162, 'usuarios', 13, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 2, "nombre": "landorus"}', '{"activo": true, "id_rol": 2, "nombre": "landorus"}', '2026-09-13 11:12:37.825949');
INSERT INTO public.auditoria VALUES (163, 'usuarios', 13, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 2, "nombre": "landorus"}', '{"activo": true, "id_rol": 2, "nombre": "landorus"}', '2026-09-13 11:18:58.150125');
INSERT INTO public.auditoria VALUES (164, 'usuarios', 13, 'UPDATE', NULL, NULL, '{"activo": true, "id_rol": 2, "nombre": "landorus"}', '{"activo": true, "id_rol": 2, "nombre": "landorus"}', '2026-09-13 11:30:30.358069');
INSERT INTO public.auditoria VALUES (165, 'usuarios', 15, 'INSERT', NULL, NULL, NULL, '{"email": "orlando5711666@gmail.com", "id_rol": 3, "nombre": "orlando"}', '2026-09-13 11:53:01.637331');


--
-- Data for Name: autores; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.autores VALUES (1, 'Prof. Andrus', 'V-11223344');
INSERT INTO public.autores VALUES (2, 'Estudiante Dev', 'V-27000111');
INSERT INTO public.autores VALUES (3, 'Estudiante Electrónica', 'V-28000222');
INSERT INTO public.autores VALUES (4, 'Juan Pérez', NULL);
INSERT INTO public.autores VALUES (5, 'María García', NULL);
INSERT INTO public.autores VALUES (6, 'Ing. Pedro Díaz', NULL);
INSERT INTO public.autores VALUES (7, 'Carlos López', NULL);
INSERT INTO public.autores VALUES (8, 'Ana Martínez', NULL);
INSERT INTO public.autores VALUES (9, 'Dra. Sofía Rojas', NULL);
INSERT INTO public.autores VALUES (14, 'Dr. Ramón Fuentes', 'V-10111213');
INSERT INTO public.autores VALUES (15, 'Dra. Clara Vásquez', 'V-10222333');
INSERT INTO public.autores VALUES (16, 'Ing. Luis Morelo', 'V-10333444');
INSERT INTO public.autores VALUES (17, 'Prof. Yolanda Díaz', 'V-10444555');
INSERT INTO public.autores VALUES (18, 'Ing. Pedro Ríos', 'V-10555666');
INSERT INTO public.autores VALUES (19, 'Prof. Ana Suárez', 'V-10666777');
INSERT INTO public.autores VALUES (20, 'Ángel Ferrer', 'V-27100001');
INSERT INTO public.autores VALUES (21, 'Mariela Colón', 'V-27100002');
INSERT INTO public.autores VALUES (22, 'Javier Navas', 'V-27100003');
INSERT INTO public.autores VALUES (23, 'Luisa Paredes', 'V-27100004');
INSERT INTO public.autores VALUES (24, 'Tomás Guerrero', 'V-27100005');
INSERT INTO public.autores VALUES (25, 'Valentina Soto', 'V-27100006');
INSERT INTO public.autores VALUES (26, 'Rodrigo Méndez', 'V-27100007');
INSERT INTO public.autores VALUES (27, 'Gabriela López', 'V-27100008');
INSERT INTO public.autores VALUES (28, 'Hernán Castro', 'V-27100009');
INSERT INTO public.autores VALUES (29, 'Isabel Ramos', 'V-27100010');
INSERT INTO public.autores VALUES (32, 'Fernando Carmino', 'V-12312313');
INSERT INTO public.autores VALUES (30, 'Mariano Rajoy', 'V-9857492');
INSERT INTO public.autores VALUES (31, 'Alejandro Alicante', 'V-12312391');
INSERT INTO public.autores VALUES (33, 'Luis Enrique Morelos', 'E-5184865');
INSERT INTO public.autores VALUES (34, 'Jesús Montilla', 'V-30866991');
INSERT INTO public.autores VALUES (35, 'Luis Miguel', 'V-17855689');
INSERT INTO public.autores VALUES (36, 'Fausto Hernandez', 'V-21314132');
INSERT INTO public.autores VALUES (37, 'miki', 'V-1234');
INSERT INTO public.autores VALUES (41, 'aaaa aaa aaa', '2222222');
INSERT INTO public.autores VALUES (42, 'Ricardo Dos Santos', 'V-24503215');
INSERT INTO public.autores VALUES (43, 'Jose Aguilar-Castro', 'V-14584964');
INSERT INTO public.autores VALUES (44, 'Taniana Rodríguez', 'V-18458789');
INSERT INTO public.autores VALUES (45, 'Rafael Aldana', 'V-123123123');
INSERT INTO public.autores VALUES (46, 'Rafiña', 'V-123123');
INSERT INTO public.autores VALUES (13, 'Jose Alejandro Rojo', 'E-2323232');
INSERT INTO public.autores VALUES (47, 'Andrés Felipe Sarmiento-Fernández', 'V-15487956');
INSERT INTO public.autores VALUES (48, 'Dursun Barrios', 'V-17890100');
INSERT INTO public.autores VALUES (49, 'Adriana de la Cruz-Uribe', 'E-1452145');
INSERT INTO public.autores VALUES (50, 'Erika Escalante-Espinosa', 'E-1231231');
INSERT INTO public.autores VALUES (51, 'José Roberto Hernández-Barajas', 'V-14515');
INSERT INTO public.autores VALUES (52, 'José Ramón Laines-Canepa', 'E-124411');
INSERT INTO public.autores VALUES (53, 'Piero Antonio Chávez-Malque', 'E-123123');
INSERT INTO public.autores VALUES (54, 'Gérlin Milquito López-Meléndez', 'V-1314114');
INSERT INTO public.autores VALUES (55, 'Edwin Olano-Inga', 'V-2151413');
INSERT INTO public.autores VALUES (56, 'Sócrates Pedro Muñoz-Pérez', 'V-15151123');
INSERT INTO public.autores VALUES (57, 'Karen Elizabeth Mora-Mora', 'V-1231315');
INSERT INTO public.autores VALUES (58, 'David Santiago Sanchez-Garcia', 'V-1451515');
INSERT INTO public.autores VALUES (59, 'Maria Paula Rodriguez-Alba', 'V-412414');
INSERT INTO public.autores VALUES (60, 'Jhon Andres Gomez-Portilla', 'V-5414213');


--
-- Data for Name: carreras; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.carreras VALUES (1, 'PNF en Informática', 'Ingeniería y TSU en Informática');
INSERT INTO public.carreras VALUES (2, 'PNF en Electricidad', 'Ingeniería y TSU en Electricidad');
INSERT INTO public.carreras VALUES (3, 'PNF en Administración', 'Licenciatura y TSU en Administración');
INSERT INTO public.carreras VALUES (4, 'PNF en Agroalimentación', 'Ingeniería y TSU Agroalimentario');
INSERT INTO public.carreras VALUES (5, 'PNF en Construcción Civil', 'Ingeniería y TSU en Construcción Civil');


--
-- Data for Name: categorias; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.categorias VALUES (1, 'Tecnología');
INSERT INTO public.categorias VALUES (3, 'Ingeniería');
INSERT INTO public.categorias VALUES (4, 'Sociales');
INSERT INTO public.categorias VALUES (5, 'Innovación');
INSERT INTO public.categorias VALUES (6, 'Ciencias Sociales');
INSERT INTO public.categorias VALUES (7, 'Salud y Biociencias');
INSERT INTO public.categorias VALUES (11, 'Salud');
INSERT INTO public.categorias VALUES (2, 'ACEMA');
INSERT INTO public.categorias VALUES (13, 'Matemáticas');
INSERT INTO public.categorias VALUES (14, 'Literatura');
INSERT INTO public.categorias VALUES (15, 'Psicología');
INSERT INTO public.categorias VALUES (16, 'Economía');
INSERT INTO public.categorias VALUES (17, 'Contaduría');
INSERT INTO public.categorias VALUES (18, 'Ingeniería Civil');


--
-- Data for Name: cursos; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.cursos VALUES (1, 4, 'Introducción a la Metodología de la Investigación', 'Curso fundamental para comprender los métodos y técnicas de investigación científica aplicados al PNF en Informática. Incluye diseño experimental, recolección de datos y análisis estadístico básico.', NULL, 'publicado', 70.00, '2026-04-03 03:28:04', '2026-04-03 03:28:04');
INSERT INTO public.cursos VALUES (2, 4, 'Fundamentos de Inteligencia Artificial', 'Curso introductorio sobre los conceptos básicos de la IA, redes neuronales, aprendizaje automático y sus aplicaciones en el contexto venezolano.', NULL, 'publicado', 70.00, '2026-04-03 03:28:04', '2026-04-03 03:28:04');
INSERT INTO public.cursos VALUES (3, 1, 'Normas APA y Redacción Científica', 'Aprende a redactar documentos académicos siguiendo las normas APA 7ma edición. Ideal para la elaboración de tu Proyecto Socio-Tecnológico.', NULL, 'publicado', 60.00, '2026-04-03 03:28:04', '2026-04-03 03:53:35');
INSERT INTO public.cursos VALUES (4, 1, 'tamaños de jose', 'los pn que jose ha tenido segun tamaño', NULL, 'publicado', 70.00, '2026-04-03 04:40:03', '2026-04-03 04:40:03');


--
-- Data for Name: detalles_articulos; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.detalles_articulos VALUES (58, 5, '87', '213', '0012-7353', '2026-07-09 15:19:57.897052', 'https://revistas.unal.edu.co/public/journals/21/cover_issue_5423_es_ES.png', 'Este artículo propone una ampliación de las capacidades del middleware MiSCi, al agregar una nueva capa denominada Datos Enlazados, para  identificar,  describir,  conectar,  relacionar  y  explotar  los  distintos  datos  generados  por  los  usuarios  y  las  aplicaciones  de  la  ciudad  inteligente usando el paradigma de datos enlazados. Esta nueva capa está compuestas por distintos agentes que permiten automatizar las etapas  de  especificación,  modelado,  generación,  vinculación,  publicación  y  explotación  de  los  datos  basados  en  MEDAWEDE.  Dichos  agentes  pueden  enriquecer  ontologías  existentes  en  MiSCi,  generar  modelos  de  conocimiento  requeridos  por  los  servicios  de  MiSCi, generar datos para construir modelos de conocimiento para MiSCi, y recomendar información en contextos de incertidumbre a través de una inferencia híbrida basada en lógica descriptiva/dialéctica. Además en este trabajo se especifica un caso de estudio, donde se muestran las capacidades del MiSCi para manejar distintas situaciones críticas, apoyado en la nueva capa de enlazado de dato', NULL, true);
INSERT INTO public.detalles_articulos VALUES (63, 8, '93', '241', '0012-7353', '2026-07-09 20:13:49.50881', 'art_1783642429_6a50393d74626.png', 'Los techos verdes representan una estrategia pasiva eficaz para reducir la transferencia de calor hacia el interior de los edificios, especialmente en climas  cálidos  y  húmedos.  En  este  trabajo  se  presenta  un  modelo  dinámico  unidimensional  de  balance  de  calor  y  masa  para  evaluar  el  comportamiento térmico de un techo verde extensivo en condiciones de trópico húmedo. El modelo considera procesos de conducción, convección, radiación y transferencia de humedad, incorporando la evapotranspiración y parámetros de la vegetación dependientes de la especie. La calibración y simulación se realizaron usando datos experimentales obtenidos de una base experimental de techos verde ubicada en Tabasco, México, con las especies Tradescantia  spathaceay Tradescantia  pallida.  El  desempeño  del  sistema  se  evaluó  bajo  tres  escenarios  climáticos  representativos:  temporada de estiaje, temporada de lluvia y de frente frío. Los resultados muestran que la capa vegetal reduce la transferencia de calor hacia el interior del edificio, además de contribuir a la estabilización térmica del microclima del techo. El análisis de sensibilidad indica que parámetros asociados a la vegetación, en particular el índice de área foliar y la resistencia interna de las hojas, ejercen una influencia dominante en la respuesta del sistema. Aunque el modelo se limita al caso unidimensional y a especies específicas, constituye una herramienta útil para la evaluación del desempeño térmico de techos verdes en climas tropicales húmedos', NULL, true);
INSERT INTO public.detalles_articulos VALUES (64, NULL, '93', '241', '0012-7353', '2026-07-09 20:16:51.643727', 'art_1783642611_6a5039f396bec.png', 'La industria de la construcción enfrenta un serio impacto ambiental por las altas emisiones del cemento, lo que impulsa la búsqueda de alternativas sostenibles como el concreto reforzado con fibras de polipropileno (FPP). Para ello se analizó su efecto en las propiedades del concreto a través de una revisión sistemática y filtrada de 66 artículos recientes entre los años 2021 y 2025 extraídos de Scopus, ScienceDirect y MDPI. Los estudios muestran que la FPP mejora la resistencia a compresión, flexión y tracción, especialmente en proporciones cercanas al 0.5%. También aumenta la durabilidad frente a agentes agresivos y mejora la microestructura al controlar grietas, aunque, puede reducir la trabajabilidad y aumentar la porosidad, efectos mitigables mediante el uso de fibras metálicas o adiciones puzolánicas. En conclusión, el uso de FPP es una opción viable para reducir el impacto ambiental del concreto y mejorar su desempeño cuando se aplica en proporciones adecuada', NULL, true);
INSERT INTO public.detalles_articulos VALUES (65, 8, '93', '241', '0012-7353', '2026-07-09 20:19:28.855723', 'art_1783642768_6a503a90ca313.png', 'La discapacidad motora en Colombia afecta a un porcentaje significativo de la población, constituye una problemática relevante de salud pública,  asociada  con  diversos  factores  del  país.  Este  proyecto  desarrolla  un  sistema  de  control  de  robots  asistenciales  controlados  por  señales electrooculográficas (EOG), logrando que aquellas personas con movilidad reducida tengan acceso a este tipo de tecnologías. Para el desarrollo se adquirieron señales con el hardware Bitalino para generar y normalizar un conjunto de datos, que luego se procesa con Python y Open Signals para establecer comandos confiables. El entorno de simulación se realizó en CoppeliaSim. Durante el proceso de desarrollo, se encontraron obstáculos como el ruido y la exactitud de las señales. No obstante, se ha terminado la interfaz y la conexión entre CoppeliaSim, Python y las señales EOG, permitiendo que el robot se mueva en tiempo real. En la actualidad, se realizan pruebas de funcionamiento, exactitud y precisión de los movimientos.', NULL, true);
INSERT INTO public.detalles_articulos VALUES (62, 8, '93', '241', '0012-7353', '2026-07-09 20:08:48.117741', 'art_1783642127_6a50380feed3b.png', 'La  banca  móvil  se  ha  consolidado  como  una  herramienta  clave  para  la  inclusión  financiera,  particularmente  en  zonas  rurales  donde  las  barreras geográficas y de infraestructura limitan el acceso a servicios bancarios tradicionales. Este estudio analiza los determinantes de la aceptación de la banca móvil en ganaderos del occidente de Antioquia, Colombia, utilizando el modelo UTAUT. Se aplicó una metodología cuantitativa  basada  en  encuestas  estructuradas  a  132  productores  rurales,  evaluando  variables  como  la  expectativa  de  rendimiento,  la  expectativa de esfuerzo, la influencia social, el riesgo y la confianza. Los resultados revelan que la expectativa de rendimiento y la facilidad de uso son los principales factores que influyen en la adopción de la banca móvil, mientras que la confianza, el riesgo y la influencia social no  mostraron  un  impacto  significativo.  Estos  hallazgos  destacan  la  necesidad  de  desarrollar  estrategias  que  promuevan  el  acceso  a  plataformas digitales intuitivas y capacitaciones enfocadas en el uso de estas herramientas.', NULL, true);


--
-- Data for Name: detalles_investigaciones; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: detalles_proyectos; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.detalles_proyectos VALUES (45, '2026-06-15', 'Pregrado', 'Dise¤o e implementaci¢n de un motor de renderizado ligero y de alto rendimiento. Se evit¢ el uso de frameworks pesados para garantizar una ejecuci¢n "metal pure", optimizando el consumo de RAM y CPU en equipos de bajos recursos.', 1, 'Comunidad de Desarrolladores Independientes', 'Rust, Tauri, Novela Visual, Nativo, Optimizaci¢n', '2026-07-05 17:21:44.350197', NULL, 'Trayecto I', NULL, true, NULL);
INSERT INTO public.detalles_proyectos VALUES (46, '2025-11-20', 'TSU', 'Estudio de la gesti¢n de memoria y el ciclo de vida de los sprites utilizando Lua dentro del motor TIC-80. El proyecto demuestra c¢mo estructurar el c¢digo para videojuegos con est‚tica retro-tech sin saturar el l¡mite de procesamiento de la consola virtual.', 1, 'Estudiantes de Computaci¢n Gr fica', 'Lua, TIC-80, Retro, GameDev, M quina de Estados', '2026-07-05 17:21:44.350197', NULL, 'Trayecto I', NULL, true, NULL);
INSERT INTO public.detalles_proyectos VALUES (47, '2026-07-02', 'Pregrado', 'Metodolog¡a pr ctica para revivir equipos de torre de principios de los 2000. El caso de estudio se centra en una Utech Pentium 4, abordando el reemplazo de condensadores inflados y la instalaci¢n limpia de sistemas operativos legacy para la preservaci¢n de software antiguo.', 1, 'Laboratorios de Arquitectura del Computador', 'Pentium 4, Hardware, Restauraci¢n, Condensadores, Legacy', '2026-07-05 17:21:44.350197', NULL, 'Trayecto I', NULL, true, NULL);
INSERT INTO public.detalles_proyectos VALUES (48, '2026-05-10', 'Pregrado', 'Creaci¢n de un n£cleo de procesamiento (Core) capaz de cargar m¢dulos MVC de forma independiente. Se detalla la construcci¢n del QueryBuilder, gesti¢n de conexiones PostgreSQL y un sistema de enrutamiento estricto para evitar acoplamientos.', 1, 'Departamento de Sistemas de la Universidad', 'Microkernel, PHP, PostgreSQL, MVC, Arquitectura', '2026-07-05 17:21:44.350197', NULL, 'Trayecto I', NULL, true, NULL);
INSERT INTO public.detalles_proyectos VALUES (49, '2026-03-15', 'Pregrado', 'Desarrollo de un sistema tradicional para optimizar los m‚todos y procedimientos del inventario m‚dico. Sigue un patr¢n arquitect¢nico modular para agilizar los procesos organizacionales.', 1, 'Ambulatorio Urbano Tipo II', 'Sistemas de Informaci¢n, PostgreSQL, Gesti¢n, Inventario', '2026-07-05 17:39:35.498485', NULL, 'Trayecto I', NULL, true, NULL);
INSERT INTO public.detalles_proyectos VALUES (50, '2026-04-22', 'Pregrado', 'Aplicaci¢n interactiva dise¤ada como medio did ctico para facilitar los procesos de ense¤anza. Combina fundamentos comunicacionales y l¢gicos mediante una interfaz interactiva de alto rendimiento.', 1, 'µrea de Ciencias B sicas de la Instituci¢n', 'Edum tica, Software Educativo, Multimedia, µlgebra', '2026-07-05 17:39:35.498485', NULL, 'Trayecto I', NULL, true, NULL);
INSERT INTO public.detalles_proyectos VALUES (51, '2025-07-10', 'TSU', 'Dise¤o de un sistema distribuido cooperativo entre clientes y un servidor centralizado. Permite la gesti¢n din mica de solicitudes concurrentes controlando de manera efectiva las peticiones HTTP contra la base de datos.', 1, 'Coordinaci¢n de Control de Estudios', 'Web, Cliente-Servidor, PHP, PostgreSQL', '2026-07-05 17:39:35.498485', NULL, 'Trayecto I', NULL, true, NULL);
INSERT INTO public.detalles_proyectos VALUES (52, '2026-06-18', 'Pregrado', 'Herramienta de simulaci¢n orientada al testeo preventivo de la transmisi¢n de datos. Permite modelar el comportamiento de las decisiones de routing antes de iniciar el despliegue f¡sico de una infraestructura de red.', 1, 'Laboratorio de Redes y Telecomunicaciones', 'Simulaci¢n, Routing, Algoritmos, Redes, Topolog¡a', '2026-07-05 17:39:35.498485', NULL, 'Trayecto I', NULL, true, NULL);
INSERT INTO public.detalles_proyectos VALUES (57, '2026-07-05', 'Pregrado', 'ahsdhajsdhahakjfhafggfjhgfkjh', 1, 'asdasdasdasd', 'asdasdasdasdasd', '2026-07-05 18:21:33.639701', NULL, 'Trayecto I', NULL, true, NULL);


--
-- Data for Name: dimensiones_operativas; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.dimensiones_operativas VALUES (6, 7, 'Sistemas de información con propiedades geográficas', 'Son sistemas que permiten evaluar propiedades geográficas de un entorno, generando información referente a una entidad geográfica desplegando imágenes e información en un hipermapa.');
INSERT INTO public.dimensiones_operativas VALUES (14, 8, 'Entornos interactivos de enseñanza', 'Proyectos donde el profesor y los alumnos se encuentran en lugares físicamente distintos. El proceso de enseñanza-aprendizaje se lleva a cabo a trav‚s de Internet, en cualquier momento y en cualquier lugar.');
INSERT INTO public.dimensiones_operativas VALUES (15, 8, 'Sistemas e-learning', 'Programas que faciliten la creación, adopción y distribución de contenidos, así como la adaptación del ritmo de aprendizaje y la disponibilidad de las herramientas de aprendizaje independientemente de límites horarios o geográficos.');
INSERT INTO public.dimensiones_operativas VALUES (16, 9, 'Aplicaciones cliente - servidor', 'Sistema distribuido entre múltiples procesadores donde hay clientes que solicitan servicios y servidores que los proporcionan. Separa los servicios situando cada uno en su plataforma más adecuada.');
INSERT INTO public.dimensiones_operativas VALUES (17, 9, 'Servicios de integración para aplicaciones web', 'Medio para exponer y hacer disponible la funcionalidad de los sistemas de información mediante las tecnologías estándar Web, permitiendo reducción de la heterogeneidad por uso de tecnologías estándar.');
INSERT INTO public.dimensiones_operativas VALUES (18, 10, 'Simulación y herramientas de simulación', 'Antes de iniciar el desarrollo de cualquier sistema complejo, los ingenieros suelen utilizar alguna herramienta de simulación o test donde sea posible modelizar y probar el sistema que está desarrollando. Reduce tiempo y chequea decisiones a priori.');
INSERT INTO public.dimensiones_operativas VALUES (19, 10, 'Modelos de transmisión de datos', 'Se discute la conceptualización integral de un sistema de transmisión desde un marco común a diferentes tecnologías, tales como: sistemas de comunicación por cable, radio enlaces fijos, móviles y satelitales.');
INSERT INTO public.dimensiones_operativas VALUES (9, 7, 'Gestión tecnológica', 'Procesos relacionados con la implantación de sistemas, tales como, verificar e instalar nuevos equipos, entrenar a los usuarios, instalar nuevas aplicaciones, agregar nuevos módulos, además de comprobar el correcto funcionamiento de los componentes de un sistema de información que puede abarcar auditorías, técnicas de control, evaluación de la calidad.');
INSERT INTO public.dimensiones_operativas VALUES (5, 7, 'Sistemas de Información Tradicionales', 'Está constituido por un conjunto de elementos de naturaleza diversa que incluyen: equipos, recursos humanos (usuario), datos e información y programas y aplicaciones; que interactúan entre sí dentro de una organización con el fin de apoyar las actividades y funciones que cumplan con los objetivos propuestos de la misma.');
INSERT INTO public.dimensiones_operativas VALUES (7, 7, 'Sistemas de información web', 'Son primeramente sistemas de información que para su desarrollo se debe considerar la misma disciplina de construcción de sistemas de información no Web exitosos y de calidad, sirven para integrar procesos o sistemas dentro de una sola interfaz y a ellos se puede acceder por medio de una Intranet local o por la red global Internet van más allá de ser un conjunto de páginas Web.');
INSERT INTO public.dimensiones_operativas VALUES (8, 7, 'Sistemas de información colaborativos', 'Son sistemas donde se pueden expresar ideas, experiencias, definiciones, entre otros; los cuales constituyen una red de distribución de la información en una organización o entre organizaciones.');
INSERT INTO public.dimensiones_operativas VALUES (10, 8, 'Software educativo', 'Programas para el computador creados con la finalidad específica de ser utilizados como medio didáctico, es decir, para facilitar los procesos de enseñanza y de aprendizaje. Combina conocimiento educacional, comunicacional e informático.');
INSERT INTO public.dimensiones_operativas VALUES (11, 8, 'Guías de estudio web', 'Representan un material instruccional utilizados para cursos de educación a distancia y como complemento a la educación presencial, lo cual provee una estructura para un curso.');
INSERT INTO public.dimensiones_operativas VALUES (12, 8, 'Tutoriales', 'Son programas que en mayor o menor medida dirigen el trabajo de los alumnos. Pretenden que, a partir de unas informaciones y mediante la realización de ciertas actividades, los estudiantes pongan en juego determinadas capacidades.');
INSERT INTO public.dimensiones_operativas VALUES (13, 8, 'Juegos didácticos', 'El juego puede cumplir al menos tres funciones en el proceso de aprendizaje, al constituirse en un medio de exploración y expresión, un instrumento para la organización y aplicación de habilidades y, un factor de socialización e integración.');


--
-- Data for Name: editoriales; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.editoriales VALUES (1, 'IEEE');
INSERT INTO public.editoriales VALUES (3, 'Springer');
INSERT INTO public.editoriales VALUES (4, 'Elsevier');
INSERT INTO public.editoriales VALUES (5, 'UPTTMBI Ediciones');
INSERT INTO public.editoriales VALUES (6, 'UNESCO');
INSERT INTO public.editoriales VALUES (7, 'SciELO Venezuela');
INSERT INTO public.editoriales VALUES (8, 'DYNA');
INSERT INTO public.editoriales VALUES (2, 'ACM');


--
-- Data for Name: etiquetas; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.etiquetas VALUES (1, 'Inteligencia Artificial', '#0ea5e9');
INSERT INTO public.etiquetas VALUES (2, 'Machine Learning', '#0ea5e9');
INSERT INTO public.etiquetas VALUES (3, 'Educación', '#0ea5e9');
INSERT INTO public.etiquetas VALUES (4, 'Redes Neuronales', '#0ea5e9');
INSERT INTO public.etiquetas VALUES (5, 'Desarrollo Web', '#0ea5e9');
INSERT INTO public.etiquetas VALUES (8, 'Teoría Matemática', '#0ea5e9');
INSERT INTO public.etiquetas VALUES (9, 'Modelo Económico', '#0ea5e9');
INSERT INTO public.etiquetas VALUES (10, 'Construcción', '#0ea5e9');


--
-- Data for Name: historico_versiones_pst; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: investigaciones_ofertadas; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.investigaciones_ofertadas VALUES (1, 7, 'Diseño de una arquitectura de bases de datos NoSQL 591', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2024-12-23 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (2, 5, 'Propuesta de mejora para sistemas embebidos 932', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2025-07-08 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (3, 6, 'Evaluación de rendimiento en bases de datos NoSQL 433', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2024-12-05 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (4, 11, 'Análisis del impacto de redes neuronales 434', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2025-04-23 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (5, 6, 'Desarrollo de un sistema gestión de inventarios 773', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2025-06-21 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (6, 10, 'Diseño de una arquitectura de computación cuántica 511', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2026-05-28 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (7, 2, 'Implementación de algoritmo de procesamiento de lenguaje natural 536', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2024-12-19 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (8, 10, 'Análisis del impacto de redes neuronales 204', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2025-08-06 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (9, 6, 'Propuesta de mejora para aplicaciones web distribuidas 440', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 10, 3, 'Cerrada', '2024-10-18 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (10, 6, 'Implementación de algoritmo de procesamiento de lenguaje natural 780', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 7, 3, 'Cerrada', '2025-11-22 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (11, 5, 'Propuesta de mejora para bases de datos NoSQL 245', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 13, 3, 'Cerrada', '2024-12-06 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (12, 1, 'Análisis del impacto de sistemas embebidos 984', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-01-19 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (13, 8, 'Optimización de procesos mediante gestión de inventarios 377', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-11-04 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (14, 9, 'Evaluación de rendimiento en gestión de inventarios 644', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 10, 3, 'Cerrada', '2024-12-17 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (15, 1, 'Implementación de algoritmo de seguridad informática 278', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2026-06-03 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (16, 11, 'Evaluación de rendimiento en visión por computadora 545', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 9, 3, 'Cerrada', '2026-08-18 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (17, 8, 'Diseño de una arquitectura de bases de datos NoSQL 899', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2026-07-06 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (18, 3, 'Estudio comparativo sobre gestión de inventarios 667', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-05-23 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (19, 2, 'Diseño de una arquitectura de bases de datos NoSQL 655', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2026-02-19 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (20, 1, 'Propuesta de mejora para aplicaciones web distribuidas 507', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 9, 3, 'Cerrada', '2025-01-28 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (21, 5, 'Estudio comparativo sobre bases de datos NoSQL 997', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2026-04-10 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (22, 4, 'Desarrollo de un sistema bases de datos NoSQL 182', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 6, 3, 'Cerrada', '2025-05-19 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (23, 6, 'Implementación de algoritmo de procesamiento de lenguaje natural 573', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 6, 3, 'Cerrada', '2024-09-22 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (24, 9, 'Optimización de procesos mediante visión por computadora 155', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 15, 3, 'Cerrada', '2025-04-08 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (25, 3, 'Desarrollo de un sistema computación cuántica 792', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-02-11 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (26, 2, 'Optimización de procesos mediante seguridad informática 704', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-02-25 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (27, 4, 'Optimización de procesos mediante redes neuronales 187', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 12, 3, 'Cerrada', '2026-02-03 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (28, 9, 'Diseño de una arquitectura de gestión de inventarios 835', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2026-07-14 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (29, 7, 'Evaluación de rendimiento en procesamiento de lenguaje natural 862', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2026-05-11 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (30, 5, 'Estudio comparativo sobre procesamiento de lenguaje natural 302', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-12-23 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (31, 6, 'Estudio comparativo sobre gestión de inventarios 129', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2024-08-24 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (32, 9, 'Propuesta de mejora para seguridad informática 828', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-04-07 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (33, 3, 'Análisis del impacto de computación cuántica 839', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 13, 3, 'Cerrada', '2025-04-01 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (34, 2, 'Desarrollo de un sistema redes neuronales 217', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2026-08-06 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (35, 9, 'Evaluación de rendimiento en gestión de inventarios 395', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 6, 3, 'Cerrada', '2024-09-02 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (36, 13, 'Análisis del impacto de gestión de inventarios 942', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2025-10-29 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (37, 9, 'Estudio comparativo sobre seguridad informática 685', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 6, 3, 'Cerrada', '2024-11-09 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (38, 6, 'Análisis del impacto de computación cuántica 243', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 13, 3, 'Cerrada', '2026-03-31 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (39, 8, 'Diseño de una arquitectura de seguridad informática 157', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2025-10-10 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (40, 6, 'Análisis del impacto de bases de datos NoSQL 592', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 12, 3, 'Cerrada', '2026-04-30 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (41, 8, 'Desarrollo de un sistema sistemas embebidos 331', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2026-08-08 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (42, 8, 'Optimización de procesos mediante redes neuronales 725', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 5, 3, 'Cerrada', '2025-12-26 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (43, 1, 'Desarrollo de un sistema bases de datos NoSQL 341', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 5, 3, 'Cerrada', '2025-12-10 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (44, 4, 'Optimización de procesos mediante sistemas embebidos 338', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2024-11-10 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (45, 6, 'Propuesta de mejora para sistemas embebidos 683', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-03-27 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (46, 2, 'Estudio comparativo sobre aplicaciones web distribuidas 399', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 13, 3, 'Cerrada', '2025-03-08 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (47, 10, 'Diseño de una arquitectura de bases de datos NoSQL 516', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 11, 3, 'Cerrada', '2025-04-28 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (48, 5, 'Optimización de procesos mediante seguridad informática 714', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 10, 3, 'Cerrada', '2026-02-28 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (49, 2, 'Estudio comparativo sobre bases de datos NoSQL 373', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 15, 3, 'Cerrada', '2025-06-02 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (50, 4, 'Diseño de una arquitectura de aplicaciones web distribuidas 598', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 10, 3, 'Cerrada', '2025-07-21 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (177, 11, 'Estudio comparativo sobre sistemas embebidos 640', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 10, 3, 'Cerrada', '2025-08-15 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (51, 6, 'Evaluación de rendimiento en computación cuántica 776', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2026-06-27 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (52, 13, 'Propuesta de mejora para computación cuántica 879', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2025-05-05 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (53, 4, 'Optimización de procesos mediante visión por computadora 682', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2026-08-03 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (54, 2, 'Optimización de procesos mediante seguridad informática 956', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2024-11-14 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (55, 11, 'Optimización de procesos mediante visión por computadora 742', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2026-06-08 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (56, 1, 'Optimización de procesos mediante bases de datos NoSQL 268', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-06-05 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (57, 13, 'Estudio comparativo sobre computación cuántica 737', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 15, 3, 'Cerrada', '2025-05-27 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (58, 8, 'Evaluación de rendimiento en bases de datos NoSQL 421', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 10, 3, 'Cerrada', '2025-08-08 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (59, 3, 'Propuesta de mejora para procesamiento de lenguaje natural 622', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2025-09-23 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (60, 1, 'Desarrollo de un sistema sistemas embebidos 951', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2024-10-09 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (61, 4, 'Propuesta de mejora para visión por computadora 406', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 12, 3, 'Cerrada', '2026-07-08 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (62, 2, 'Análisis del impacto de computación cuántica 224', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-08-18 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (63, 11, 'Estudio comparativo sobre seguridad informática 609', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 6, 3, 'Cerrada', '2025-11-15 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (64, 8, 'Implementación de algoritmo de procesamiento de lenguaje natural 663', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 9, 3, 'Cerrada', '2025-03-06 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (65, 6, 'Estudio comparativo sobre computación cuántica 875', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 10, 3, 'Cerrada', '2024-08-25 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (66, 13, 'Implementación de algoritmo de sistemas embebidos 822', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 13, 3, 'Cerrada', '2024-12-16 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (67, 3, 'Implementación de algoritmo de sistemas embebidos 865', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 6, 3, 'Cerrada', '2026-02-15 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (68, 8, 'Propuesta de mejora para visión por computadora 331', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 6, 3, 'Cerrada', '2025-09-13 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (69, 2, 'Desarrollo de un sistema visión por computadora 642', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-06-22 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (70, 2, 'Diseño de una arquitectura de sistemas embebidos 631', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-08-21 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (71, 7, 'Propuesta de mejora para bases de datos NoSQL 660', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2024-10-30 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (72, 7, 'Estudio comparativo sobre computación cuántica 755', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-03-21 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (73, 8, 'Implementación de algoritmo de procesamiento de lenguaje natural 907', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-06-14 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (74, 5, 'Estudio comparativo sobre procesamiento de lenguaje natural 967', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 9, 3, 'Cerrada', '2024-11-24 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (75, 2, 'Implementación de algoritmo de aplicaciones web distribuidas 221', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2024-11-16 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (76, 2, 'Propuesta de mejora para computación cuántica 629', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 5, 3, 'Cerrada', '2025-07-05 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (77, 13, 'Análisis del impacto de visión por computadora 637', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 7, 3, 'Cerrada', '2025-05-22 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (78, 11, 'Desarrollo de un sistema aplicaciones web distribuidas 269', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-06-21 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (79, 13, 'Desarrollo de un sistema gestión de inventarios 733', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-10-22 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (80, 4, 'Análisis del impacto de seguridad informática 413', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-12-03 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (81, 8, 'Evaluación de rendimiento en seguridad informática 586', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 13, 3, 'Cerrada', '2024-12-17 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (82, 4, 'Optimización de procesos mediante seguridad informática 169', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2026-03-16 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (83, 9, 'Propuesta de mejora para visión por computadora 315', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2025-05-31 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (84, 3, 'Implementación de algoritmo de sistemas embebidos 684', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 9, 3, 'Cerrada', '2025-08-18 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (85, 1, 'Desarrollo de un sistema seguridad informática 312', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-11-08 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (86, 13, 'Optimización de procesos mediante redes neuronales 735', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 10, 3, 'Cerrada', '2024-09-30 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (87, 3, 'Propuesta de mejora para bases de datos NoSQL 425', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2025-08-09 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (88, 7, 'Propuesta de mejora para computación cuántica 607', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-02-03 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (89, 11, 'Desarrollo de un sistema procesamiento de lenguaje natural 664', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 12, 3, 'Cerrada', '2025-01-06 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (90, 13, 'Evaluación de rendimiento en sistemas embebidos 973', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-03-02 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (91, 8, 'Análisis del impacto de computación cuántica 793', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 15, 3, 'Cerrada', '2025-09-09 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (92, 3, 'Diseño de una arquitectura de seguridad informática 859', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2026-06-01 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (93, 8, 'Propuesta de mejora para redes neuronales 815', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-03-27 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (94, 2, 'Diseño de una arquitectura de sistemas embebidos 469', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 7, 3, 'Cerrada', '2026-02-12 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (95, 2, 'Análisis del impacto de seguridad informática 505', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2024-12-04 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (96, 4, 'Implementación de algoritmo de computación cuántica 523', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 14, 3, 'Cerrada', '2025-05-23 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (97, 7, 'Implementación de algoritmo de visión por computadora 999', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2026-03-13 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (98, 7, 'Diseño de una arquitectura de aplicaciones web distribuidas 243', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-01-24 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (99, 7, 'Optimización de procesos mediante visión por computadora 384', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 13, 3, 'Cerrada', '2026-08-11 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (100, 2, 'Estudio comparativo sobre seguridad informática 596', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-02-20 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (101, 10, 'Evaluación de rendimiento en procesamiento de lenguaje natural 329', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 11, 3, 'Cerrada', '2026-04-14 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (102, 4, 'Evaluación de rendimiento en aplicaciones web distribuidas 690', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2025-12-21 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (103, 10, 'Análisis del impacto de aplicaciones web distribuidas 289', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-08-19 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (104, 3, 'Implementación de algoritmo de computación cuántica 719', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2026-03-04 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (105, 1, 'Implementación de algoritmo de visión por computadora 872', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 7, 3, 'Cerrada', '2025-05-18 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (106, 5, 'Implementación de algoritmo de redes neuronales 966', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-10-06 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (107, 5, 'Optimización de procesos mediante procesamiento de lenguaje natural 262', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2026-02-04 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (108, 2, 'Diseño de una arquitectura de computación cuántica 240', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 7, 3, 'Cerrada', '2025-04-26 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (109, 6, 'Análisis del impacto de gestión de inventarios 590', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2025-01-03 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (110, 9, 'Implementación de algoritmo de procesamiento de lenguaje natural 562', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2026-01-21 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (111, 3, 'Optimización de procesos mediante aplicaciones web distribuidas 296', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 9, 3, 'Cerrada', '2025-01-02 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (112, 1, 'Diseño de una arquitectura de seguridad informática 189', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2026-06-25 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (113, 2, 'Análisis del impacto de procesamiento de lenguaje natural 776', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-08-30 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (114, 8, 'Propuesta de mejora para bases de datos NoSQL 709', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 15, 3, 'Cerrada', '2025-02-17 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (115, 8, 'Optimización de procesos mediante redes neuronales 403', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 13, 3, 'Cerrada', '2024-09-09 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (116, 1, 'Desarrollo de un sistema seguridad informática 459', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2026-06-04 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (117, 7, 'Optimización de procesos mediante gestión de inventarios 559', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 15, 3, 'Cerrada', '2026-02-06 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (118, 13, 'Desarrollo de un sistema sistemas embebidos 439', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2025-10-19 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (119, 7, 'Propuesta de mejora para bases de datos NoSQL 782', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 11, 3, 'Cerrada', '2026-03-02 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (120, 3, 'Desarrollo de un sistema sistemas embebidos 391', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 11, 3, 'Cerrada', '2025-08-19 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (121, 7, 'Estudio comparativo sobre sistemas embebidos 966', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-10-30 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (122, 10, 'Propuesta de mejora para redes neuronales 976', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 15, 3, 'Cerrada', '2025-11-01 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (123, 9, 'Análisis del impacto de seguridad informática 131', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 5, 3, 'Cerrada', '2026-03-19 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (124, 1, 'Evaluación de rendimiento en bases de datos NoSQL 491', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2024-12-13 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (125, 3, 'Diseño de una arquitectura de sistemas embebidos 906', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2026-01-19 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (126, 7, 'Optimización de procesos mediante redes neuronales 150', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2025-09-26 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (127, 13, 'Diseño de una arquitectura de visión por computadora 299', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 12, 3, 'Cerrada', '2025-12-04 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (128, 9, 'Estudio comparativo sobre computación cuántica 224', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-03-08 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (129, 1, 'Estudio comparativo sobre gestión de inventarios 908', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-06-10 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (130, 8, 'Desarrollo de un sistema redes neuronales 562', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 9, 3, 'Cerrada', '2026-08-15 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (131, 1, 'Evaluación de rendimiento en computación cuántica 875', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-02-20 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (132, 2, 'Evaluación de rendimiento en computación cuántica 942', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2026-06-03 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (133, 2, 'Desarrollo de un sistema procesamiento de lenguaje natural 359', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2026-03-30 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (134, 6, 'Propuesta de mejora para visión por computadora 871', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-12-20 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (135, 8, 'Optimización de procesos mediante procesamiento de lenguaje natural 165', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 10, 3, 'Cerrada', '2025-10-05 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (136, 3, 'Evaluación de rendimiento en aplicaciones web distribuidas 377', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 15, 3, 'Cerrada', '2025-02-03 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (137, 10, 'Evaluación de rendimiento en gestión de inventarios 657', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 13, 3, 'Cerrada', '2025-01-31 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (138, 3, 'Implementación de algoritmo de seguridad informática 686', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2025-03-24 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (139, 5, 'Diseño de una arquitectura de sistemas embebidos 296', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2024-08-31 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (140, 1, 'Estudio comparativo sobre bases de datos NoSQL 255', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2024-09-28 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (141, 9, 'Optimización de procesos mediante sistemas embebidos 250', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 9, 3, 'Cerrada', '2026-03-23 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (142, 10, 'Optimización de procesos mediante seguridad informática 120', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2026-04-16 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (143, 5, 'Implementación de algoritmo de bases de datos NoSQL 533', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 5, 3, 'Cerrada', '2025-01-17 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (144, 4, 'Diseño de una arquitectura de sistemas embebidos 518', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-08-12 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (145, 6, 'Implementación de algoritmo de gestión de inventarios 993', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 5, 3, 'Cerrada', '2025-09-29 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (146, 8, 'Estudio comparativo sobre visión por computadora 932', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2026-06-17 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (147, 4, 'Estudio comparativo sobre bases de datos NoSQL 957', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 6, 3, 'Cerrada', '2026-07-18 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (148, 6, 'Desarrollo de un sistema aplicaciones web distribuidas 419', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 14, 3, 'Cerrada', '2026-08-01 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (149, 2, 'Desarrollo de un sistema bases de datos NoSQL 603', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2024-11-16 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (150, 2, 'Evaluación de rendimiento en bases de datos NoSQL 957', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2026-04-01 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (151, 8, 'Optimización de procesos mediante aplicaciones web distribuidas 920', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 12, 3, 'Cerrada', '2024-12-09 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (152, 9, 'Propuesta de mejora para sistemas embebidos 962', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-03-20 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (153, 4, 'Optimización de procesos mediante visión por computadora 145', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2026-01-27 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (154, 8, 'Análisis del impacto de sistemas embebidos 352', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2025-11-03 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (155, 11, 'Implementación de algoritmo de procesamiento de lenguaje natural 425', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-05-02 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (156, 7, 'Estudio comparativo sobre procesamiento de lenguaje natural 655', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2025-01-09 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (157, 5, 'Diseño de una arquitectura de procesamiento de lenguaje natural 546', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 11, 3, 'Cerrada', '2024-10-02 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (158, 13, 'Optimización de procesos mediante redes neuronales 406', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 15, 3, 'Cerrada', '2025-01-02 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (159, 11, 'Evaluación de rendimiento en aplicaciones web distribuidas 437', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-09-13 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (160, 5, 'Análisis del impacto de sistemas embebidos 515', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 7, 3, 'Cerrada', '2024-11-10 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (161, 4, 'Implementación de algoritmo de sistemas embebidos 654', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 15, 3, 'Cerrada', '2024-09-10 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (162, 3, 'Optimización de procesos mediante sistemas embebidos 174', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-04-18 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (163, 6, 'Análisis del impacto de seguridad informática 483', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2024-12-03 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (164, 7, 'Propuesta de mejora para procesamiento de lenguaje natural 662', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-12-07 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (165, 11, 'Diseño de una arquitectura de computación cuántica 806', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-01-24 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (166, 7, 'Diseño de una arquitectura de computación cuántica 278', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 5, 3, 'Cerrada', '2026-05-21 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (167, 13, 'Análisis del impacto de sistemas embebidos 338', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 14, 3, 'Cerrada', '2025-05-22 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (168, 5, 'Diseño de una arquitectura de gestión de inventarios 201', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 6, 3, 'Cerrada', '2025-04-27 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (169, 3, 'Desarrollo de un sistema procesamiento de lenguaje natural 430', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 10, 3, 'Cerrada', '2025-10-11 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (170, 2, 'Desarrollo de un sistema redes neuronales 858', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-03-29 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (171, 13, 'Análisis del impacto de procesamiento de lenguaje natural 182', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2026-06-04 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (172, 13, 'Evaluación de rendimiento en aplicaciones web distribuidas 799', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-09-07 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (173, 11, 'Evaluación de rendimiento en aplicaciones web distribuidas 265', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-11-28 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (174, 8, 'Evaluación de rendimiento en visión por computadora 230', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 14, 3, 'Cerrada', '2024-12-04 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (175, 13, 'Implementación de algoritmo de gestión de inventarios 835', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2025-04-04 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (176, 8, 'Evaluación de rendimiento en visión por computadora 138', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-12-10 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (178, 6, 'Implementación de algoritmo de sistemas embebidos 511', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 12, 3, 'Cerrada', '2025-03-16 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (179, 2, 'Implementación de algoritmo de procesamiento de lenguaje natural 164', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-07-08 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (180, 7, 'Estudio comparativo sobre aplicaciones web distribuidas 684', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-01-17 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (181, 4, 'Propuesta de mejora para seguridad informática 613', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-07-19 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (182, 1, 'Optimización de procesos mediante bases de datos NoSQL 986', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-01-29 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (183, 8, 'Análisis del impacto de redes neuronales 785', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 11, 3, 'Cerrada', '2026-04-10 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (184, 9, 'Implementación de algoritmo de visión por computadora 155', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-09-30 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (185, 10, 'Análisis del impacto de gestión de inventarios 628', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 14, 3, 'Cerrada', '2025-06-01 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (186, 1, 'Implementación de algoritmo de aplicaciones web distribuidas 527', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-09-30 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (187, 13, 'Desarrollo de un sistema computación cuántica 173', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 7, 3, 'Cerrada', '2026-02-10 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (188, 7, 'Implementación de algoritmo de redes neuronales 808', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 13, 3, 'Cerrada', '2025-01-26 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (189, 9, 'Propuesta de mejora para gestión de inventarios 354', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 13, 3, 'Cerrada', '2026-03-07 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (190, 11, 'Análisis del impacto de gestión de inventarios 441', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 6, 3, 'Cerrada', '2026-01-11 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (191, 6, 'Optimización de procesos mediante computación cuántica 218', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 13, 3, 'Cerrada', '2024-10-08 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (192, 7, 'Estudio comparativo sobre bases de datos NoSQL 378', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2024-08-27 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (193, 2, 'Análisis del impacto de aplicaciones web distribuidas 325', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 7, 3, 'Cerrada', '2025-06-11 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (194, 1, 'Implementación de algoritmo de gestión de inventarios 241', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-09-14 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (195, 9, 'Análisis del impacto de aplicaciones web distribuidas 863', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2026-03-22 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (196, 3, 'Evaluación de rendimiento en redes neuronales 139', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2024-12-08 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (197, 3, 'Implementación de algoritmo de gestión de inventarios 637', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2026-07-24 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (198, 3, 'Implementación de algoritmo de bases de datos NoSQL 359', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-11-17 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (199, 6, 'Optimización de procesos mediante seguridad informática 322', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 5, 3, 'Cerrada', '2025-08-28 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (200, 7, 'Diseño de una arquitectura de visión por computadora 912', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2024-09-20 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (201, 10, 'Estudio comparativo sobre gestión de inventarios 942', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 10, 3, 'Cerrada', '2026-02-20 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (202, 8, 'Propuesta de mejora para seguridad informática 691', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 5, 3, 'Cerrada', '2025-08-16 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (203, 6, 'Propuesta de mejora para gestión de inventarios 497', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-11-07 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (204, 2, 'Propuesta de mejora para procesamiento de lenguaje natural 537', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 9, 3, 'Cerrada', '2024-12-26 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (205, 10, 'Análisis del impacto de seguridad informática 869', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-10-07 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (206, 4, 'Optimización de procesos mediante aplicaciones web distribuidas 980', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2025-06-19 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (207, 8, 'Implementación de algoritmo de visión por computadora 284', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-04-13 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (208, 9, 'Desarrollo de un sistema gestión de inventarios 801', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 14, 3, 'Cerrada', '2025-12-29 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (209, 7, 'Optimización de procesos mediante procesamiento de lenguaje natural 665', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 5, 3, 'Cerrada', '2024-10-03 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (210, 7, 'Evaluación de rendimiento en aplicaciones web distribuidas 690', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-01-25 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (211, 11, 'Análisis del impacto de sistemas embebidos 442', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-09-23 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (212, 11, 'Optimización de procesos mediante bases de datos NoSQL 109', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 7, 3, 'Cerrada', '2024-12-21 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (213, 3, 'Propuesta de mejora para procesamiento de lenguaje natural 930', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-02-27 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (214, 11, 'Optimización de procesos mediante sistemas embebidos 843', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2026-01-24 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (215, 2, 'Estudio comparativo sobre visión por computadora 720', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 12, 3, 'Cerrada', '2026-01-12 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (216, 11, 'Optimización de procesos mediante sistemas embebidos 647', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2024-10-20 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (217, 1, 'Análisis del impacto de visión por computadora 233', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2025-02-22 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (218, 6, 'Diseño de una arquitectura de visión por computadora 592', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 13, 3, 'Cerrada', '2025-12-23 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (219, 10, 'Estudio comparativo sobre gestión de inventarios 930', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2024-12-17 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (220, 13, 'Evaluación de rendimiento en redes neuronales 951', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 6, 3, 'Cerrada', '2025-10-03 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (221, 11, 'Propuesta de mejora para bases de datos NoSQL 920', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-07-13 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (222, 7, 'Diseño de una arquitectura de bases de datos NoSQL 729', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 10, 3, 'Cerrada', '2025-09-03 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (223, 5, 'Estudio comparativo sobre bases de datos NoSQL 410', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-09-14 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (224, 10, 'Estudio comparativo sobre seguridad informática 863', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 12, 3, 'Cerrada', '2025-05-16 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (225, 4, 'Evaluación de rendimiento en aplicaciones web distribuidas 664', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2026-07-17 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (226, 4, 'Diseño de una arquitectura de redes neuronales 857', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2024-10-12 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (227, 2, 'Evaluación de rendimiento en bases de datos NoSQL 321', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2024-10-18 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (228, 13, 'Desarrollo de un sistema bases de datos NoSQL 779', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-07-23 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (229, 13, 'Análisis del impacto de computación cuántica 612', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2024-10-09 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (230, 5, 'Propuesta de mejora para sistemas embebidos 116', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-11-17 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (231, 7, 'Diseño de una arquitectura de computación cuántica 461', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2024-10-12 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (232, 1, 'Diseño de una arquitectura de aplicaciones web distribuidas 795', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2025-06-24 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (233, 13, 'Implementación de algoritmo de visión por computadora 442', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2024-09-18 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (234, 10, 'Análisis del impacto de bases de datos NoSQL 485', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 10, 3, 'Cerrada', '2025-01-01 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (235, 8, 'Estudio comparativo sobre bases de datos NoSQL 400', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 7, 3, 'Cerrada', '2025-06-07 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (236, 3, 'Optimización de procesos mediante visión por computadora 472', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2025-07-23 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (237, 6, 'Estudio comparativo sobre seguridad informática 464', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2025-11-29 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (238, 6, 'Análisis del impacto de gestión de inventarios 365', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 10, 3, 'Cerrada', '2025-07-18 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (239, 6, 'Diseño de una arquitectura de redes neuronales 480', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-04-24 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (240, 4, 'Análisis del impacto de gestión de inventarios 826', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2024-12-15 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (241, 7, 'Desarrollo de un sistema seguridad informática 352', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 12, 3, 'Cerrada', '2025-12-23 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (242, 6, 'Estudio comparativo sobre computación cuántica 261', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2024-10-09 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (243, 5, 'Estudio comparativo sobre sistemas embebidos 116', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-03-07 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (244, 4, 'Diseño de una arquitectura de bases de datos NoSQL 343', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 13, 3, 'Cerrada', '2025-02-03 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (245, 10, 'Estudio comparativo sobre procesamiento de lenguaje natural 677', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2026-02-18 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (246, 10, 'Implementación de algoritmo de seguridad informática 384', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2026-02-22 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (247, 5, 'Evaluación de rendimiento en bases de datos NoSQL 349', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 6, 3, 'Cerrada', '2025-01-29 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (248, 5, 'Evaluación de rendimiento en seguridad informática 179', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-10-31 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (249, 7, 'Propuesta de mejora para gestión de inventarios 664', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2026-03-07 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (250, 11, 'Análisis del impacto de gestión de inventarios 887', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 7, 3, 'Cerrada', '2025-01-28 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (251, 6, 'Desarrollo de un sistema seguridad informática 773', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2024-08-24 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (252, 5, 'Implementación de algoritmo de seguridad informática 762', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-11-18 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (253, 6, 'Implementación de algoritmo de aplicaciones web distribuidas 527', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-12-23 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (254, 3, 'Propuesta de mejora para sistemas embebidos 312', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 13, 3, 'Cerrada', '2025-01-11 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (255, 3, 'Análisis del impacto de bases de datos NoSQL 350', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 13, 3, 'Cerrada', '2024-12-08 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (256, 10, 'Propuesta de mejora para sistemas embebidos 679', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2026-03-26 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (257, 5, 'Implementación de algoritmo de gestión de inventarios 550', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 9, 3, 'Cerrada', '2024-12-26 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (258, 13, 'Optimización de procesos mediante sistemas embebidos 349', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 6, 3, 'Cerrada', '2026-02-26 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (259, 10, 'Evaluación de rendimiento en visión por computadora 914', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-05-10 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (260, 10, 'Optimización de procesos mediante procesamiento de lenguaje natural 747', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-10-24 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (261, 7, 'Diseño de una arquitectura de visión por computadora 886', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 11, 3, 'Cerrada', '2025-11-21 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (262, 3, 'Optimización de procesos mediante visión por computadora 191', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-01-05 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (263, 6, 'Implementación de algoritmo de visión por computadora 565', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2025-02-12 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (264, 11, 'Optimización de procesos mediante computación cuántica 599', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2024-11-08 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (265, 4, 'Evaluación de rendimiento en bases de datos NoSQL 944', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2025-04-08 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (266, 1, 'Análisis del impacto de computación cuántica 222', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 9, 3, 'Cerrada', '2026-06-29 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (267, 6, 'Propuesta de mejora para sistemas embebidos 881', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2026-06-16 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (268, 3, 'Evaluación de rendimiento en visión por computadora 679', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-03-23 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (269, 5, 'Propuesta de mejora para sistemas embebidos 901', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-10-25 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (270, 8, 'Diseño de una arquitectura de computación cuántica 507', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-12-17 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (271, 1, 'Diseño de una arquitectura de visión por computadora 512', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2024-10-02 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (272, 6, 'Diseño de una arquitectura de sistemas embebidos 627', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-04-13 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (273, 9, 'Optimización de procesos mediante gestión de inventarios 268', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2026-08-04 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (274, 1, 'Análisis del impacto de aplicaciones web distribuidas 506', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-12-25 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (275, 1, 'Evaluación de rendimiento en visión por computadora 715', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2026-04-05 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (276, 1, 'Desarrollo de un sistema seguridad informática 969', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-05-05 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (277, 3, 'Evaluación de rendimiento en redes neuronales 880', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 5, 3, 'Cerrada', '2026-08-17 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (278, 8, 'Implementación de algoritmo de procesamiento de lenguaje natural 357', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-10-20 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (279, 8, 'Optimización de procesos mediante computación cuántica 388', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-04-04 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (280, 4, 'Propuesta de mejora para computación cuántica 356', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-12-06 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (281, 2, 'Diseño de una arquitectura de aplicaciones web distribuidas 631', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2025-10-06 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (282, 13, 'Evaluación de rendimiento en aplicaciones web distribuidas 710', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-06-18 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (283, 2, 'Estudio comparativo sobre sistemas embebidos 513', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2025-05-26 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (284, 6, 'Optimización de procesos mediante sistemas embebidos 697', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 17, 3, 'Cerrada', '2025-10-14 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (285, 10, 'Desarrollo de un sistema redes neuronales 683', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 9, 3, 'Cerrada', '2025-06-01 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (286, 2, 'Optimización de procesos mediante redes neuronales 911', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 5, 3, 'Cerrada', '2026-07-09 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (287, 6, 'Propuesta de mejora para gestión de inventarios 480', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-03-10 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (288, 3, 'Propuesta de mejora para procesamiento de lenguaje natural 411', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-07-31 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (289, 2, 'Evaluación de rendimiento en sistemas embebidos 116', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 15, 3, 'Cerrada', '2026-07-08 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (290, 9, 'Evaluación de rendimiento en procesamiento de lenguaje natural 663', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 7, 3, 'Cerrada', '2025-11-04 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (291, 5, 'Diseño de una arquitectura de seguridad informática 938', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 9, 3, 'Cerrada', '2026-07-30 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (292, 5, 'Análisis del impacto de gestión de inventarios 705', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 11, 3, 'Cerrada', '2025-12-07 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (293, 2, 'Implementación de algoritmo de sistemas embebidos 750', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 8, 3, 'Cerrada', '2025-02-09 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (294, 5, 'Propuesta de mejora para bases de datos NoSQL 835', 'Este proyecto surge por la necesidad de resolver problemas en el área de SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en SISTEMAS DE INFORMACION Y MODELADO DE DATOS.', 7, 5, 3, 'Cerrada', '2025-09-01 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (295, 8, 'Análisis del impacto de computación cuántica 824', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 18, 3, 'Cerrada', '2025-05-06 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (296, 11, 'Diseño de una arquitectura de redes neuronales 429', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 10, 3, 'Cerrada', '2024-10-24 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (297, 11, 'Análisis del impacto de redes neuronales 354', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2026-02-16 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (298, 10, 'Implementación de algoritmo de sistemas embebidos 140', 'Este proyecto surge por la necesidad de resolver problemas en el área de EDUMATICA.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en EDUMATICA.', 8, 14, 3, 'Cerrada', '2026-02-13 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (299, 13, 'Análisis del impacto de seguridad informática 468', 'Este proyecto surge por la necesidad de resolver problemas en el área de APLICACIONES WEB.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en APLICACIONES WEB.', 9, 16, 3, 'Cerrada', '2026-03-23 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (300, 4, 'Diseño de una arquitectura de procesamiento de lenguaje natural 434', 'Este proyecto surge por la necesidad de resolver problemas en el área de REDES Y TELECOMUNICACIONES.', 'Mejorar las métricas de rendimiento y evaluar alternativas viables en REDES Y TELECOMUNICACIONES.', 10, 19, 3, 'Cerrada', '2026-08-10 17:06:10', NULL);
INSERT INTO public.investigaciones_ofertadas VALUES (301, 14, 'Requerimiento: inventario', 'necesito un sistema para mi alacen

(Nivel Requerido: Trayecto I)', 'Dar respuesta y solución tecnológica a los requerimientos de Megacell', 9, NULL, 3, 'Abierta', '2026-09-09 21:53:07.080851', 6);
INSERT INTO public.investigaciones_ofertadas VALUES (302, 14, 'Requerimiento: redes', '11111111111111

(Nivel Requerido: Trayecto I)', 'Dar respuesta y solución tecnológica a los requerimientos de Megacellll', 11, NULL, 3, 'En Desarrollo', '2026-09-12 22:46:16.656536', 7);
INSERT INTO public.investigaciones_ofertadas VALUES (304, 13, 'Requerimiento: facturacion', 'hola

(Nivel Requerido: Trayecto II)', 'Dar respuesta y solución tecnológica a los requerimientos de gregoria', 7, 7, 3, 'Abierta', '2026-09-13 18:51:15.27075', 9);
INSERT INTO public.investigaciones_ofertadas VALUES (305, 13, 'Requerimiento: inventario', 'ailberth deje de robarse las pantallas pa su primo chamo

(Nivel Requerido: Trayecto III)', 'Dar respuesta y solución tecnológica a los requerimientos de zambrano cell', 7, 8, 3, 'Abierta', '2026-09-13 18:55:47.614826', 11);
INSERT INTO public.investigaciones_ofertadas VALUES (306, 13, 'Requerimiento: datos', 'yisus porfa ordeña a carmencita sisisisi

(Nivel Requerido: Trayecto IV)', 'Dar respuesta y solución tecnológica a los requerimientos de carmencita coito', 7, 9, 3, 'Abierta', '2026-09-13 18:55:58.545224', 10);
INSERT INTO public.investigaciones_ofertadas VALUES (303, 13, 'Requerimiento: inventario', 'necesito ayuda con respecto a un sistema que me controle el inventario de los productos que vendo aca en el local

(Nivel Requerido: Trayecto I)', 'Dar respuesta y solución tecnológica a los requerimientos de Punto Yali', 7, 5, 4, 'En Desarrollo', '2026-09-13 18:37:00.617613', 8);
INSERT INTO public.investigaciones_ofertadas VALUES (307, 7, 'Requerimiento: Sistema de Inventario', 'necesito un sistema para poder registrar los telefonos que estamo haciendo

(Nivel Requerido: Trayecto I)', 'Dar respuesta y solución tecnológica a los requerimientos de Megacell', 7, 7, 3, 'En Desarrollo', '2026-09-13 20:28:59.866797', 12);
INSERT INTO public.investigaciones_ofertadas VALUES (308, 7, 'Requerimiento: Sistema de Inventario', 'caafagsdfddsfdsfdsf

(Nivel Requerido: Trayecto I)', 'Dar respuesta y solución tecnológica a los requerimientos de Punto Yali', 7, 9, 2, 'Abierta', '2026-09-13 22:29:24.900457', 13);
INSERT INTO public.investigaciones_ofertadas VALUES (309, 7, 'Requerimiento: Mejora de sistema', 'ghfjhmfhjfgdjhfd

(Nivel Requerido: Trayecto I)', 'Dar respuesta y solución tecnológica a los requerimientos de zambrano cell', 7, 9, 4, 'Abierta', '2026-09-13 22:31:01.700119', 15);
INSERT INTO public.investigaciones_ofertadas VALUES (310, 7, 'Requerimiento: Sistema de Inventario', 'vbnchngfhgjfhgj

(Nivel Requerido: Trayecto I)', 'Dar respuesta y solución tecnológica a los requerimientos de Punto Yali', 7, 8, 3, 'Abierta', '2026-09-13 22:31:22.687385', 14);


--
-- Data for Name: lineas_investigacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.lineas_investigacion VALUES (11, 'Agroelectroniloko', 1, 'Carrera nueva');
INSERT INTO public.lineas_investigacion VALUES (8, 'EDUMÁTICA', 1, 'Aplicar las Tecnologías de la Información y Comunicación (TIC) para apoyar el proceso de aprendizaje, y así contribuir al mejoramiento de la educación en todos sus niveles.');
INSERT INTO public.lineas_investigacion VALUES (9, 'DESARROLLO DE APLICACIONES', 1, 'Desarrollar aplicaciones informáticas que respondan a las necesidades de gestión, control e intercambio de información en diversos entornos organizacionales, educativos y sociales, mediante el uso de tecnologías multiplataforma y arquitecturas orientadas a servicios, tanto en entornos locales como distribuidos.');
INSERT INTO public.lineas_investigacion VALUES (10, 'REDES Y TELECOMUNICACIONES', 1, 'Desarrollar aplicaciones que permitan analizar, verificar y simular la transmisión de datos, como también la detección de fallas dentro de una red.');
INSERT INTO public.lineas_investigacion VALUES (7, 'SISTEMAS DE INFORMACIÓN Y MODELADO DE DATOS', 1, 'Desarrollar y gestionar sistemas de información dentro del áámbito social. Aplicando soluciones efectivas para el uso adecuado y óóptimo de los sistemas de información.');
INSERT INTO public.lineas_investigacion VALUES (13, 'waza', 1, 'cositas');


--
-- Data for Name: notificaciones; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.notificaciones VALUES (1, 4, 'Actualización Moderada de Cuenta', 'Su perfil fue ajustado por un administrador. Nuevo rol ID: 1. El estado de la cuenta es: completamente Activa.', true, '2026-03-23 16:14:24', '2026-03-23 20:40:28');
INSERT INTO public.notificaciones VALUES (2, 4, 'Actualización Moderada de Cuenta', 'Su perfil fue ajustado por un administrador. Nuevo rol ID: 4. El estado de la cuenta es: completamente Activa.', true, '2026-03-23 20:10:36', '2026-03-23 20:40:28');
INSERT INTO public.notificaciones VALUES (3, 5, 'Actualización Moderada de Cuenta', 'Su perfil fue ajustado por un administrador. Nuevo rol ID: 1. El estado de la cuenta es: completamente Activa.', true, '2026-03-23 21:42:42', '2026-03-23 21:42:42');
INSERT INTO public.notificaciones VALUES (4, 4, 'Actualización Moderada de Cuenta', 'Su perfil fue ajustado por un administrador. Nuevo rol ID: 3. El estado de la cuenta es: Suspendida por completo.', true, '2026-04-02 02:13:17', '2026-04-02 02:13:17');
INSERT INTO public.notificaciones VALUES (5, 4, 'Actualización Moderada de Cuenta', 'Su perfil fue ajustado por un administrador. Nuevo rol ID: 3. El estado de la cuenta es: completamente Activa.', true, '2026-04-02 02:13:22', '2026-04-02 02:13:22');
INSERT INTO public.notificaciones VALUES (6, 5, 'Actualización Moderada de Cuenta', 'Su perfil fue ajustado por un administrador. Nuevo rol ID: 3. El estado de la cuenta es: completamente Activa.', true, '2026-04-04 16:13:51', '2026-04-04 16:13:51');


--
-- Data for Name: postulaciones_estudiantes; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.postulaciones_estudiantes VALUES (9, 301, 14, 'jhkhkjh', 'Pendiente', '2026-09-12 22:00:23.993506', NULL, NULL);
INSERT INTO public.postulaciones_estudiantes VALUES (11, 302, 13, 'Porque somos muy buenos', 'Aceptado', '2026-09-13 14:24:25.472775', '2026-09-13 14:57:55.735404', '[{"nombre":"ale alphar","cedula":"12233334","telefono":"04141609721"},{"nombre":"miki wazaa","cedula":"23565755","telefono":"no hay"}]');
INSERT INTO public.postulaciones_estudiantes VALUES (12, 303, 13, 'porque me gusta el pingo', 'Aceptado', '2026-09-13 19:00:50.660565', '2026-09-13 19:10:25.816423', '[{"nombre":"yisus del carmen","cedula":"123345678","telefono":"0412223847377665"}]');
INSERT INTO public.postulaciones_estudiantes VALUES (13, 307, 7, '', 'Aceptado', '2026-09-13 21:02:52.845339', '2026-09-13 21:03:27.070465', '[{"nombre":"alesasio","cedula":"123445","telefono":"1234543423"}]');


--
-- Data for Name: preferencias_usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.preferencias_usuario VALUES (1, 'ocean', true);
INSERT INTO public.preferencias_usuario VALUES (3, 'sunset', true);
INSERT INTO public.preferencias_usuario VALUES (4, 'ocean', true);
INSERT INTO public.preferencias_usuario VALUES (6, 'sunset', true);


--
-- Data for Name: privilegios; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.privilegios VALUES (1, 0);
INSERT INTO public.privilegios VALUES (2, 1);
INSERT INTO public.privilegios VALUES (3, 2);
INSERT INTO public.privilegios VALUES (4, 3);
INSERT INTO public.privilegios VALUES (5, 4);
INSERT INTO public.privilegios VALUES (6, 5);


--
-- Data for Name: propuestas_empresa; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.propuestas_empresa VALUES (14, 'Punto Yali', '27889926', 'Miki boss', '04121609721', 'lando1609721@gmail.com', 'Sistema de Inventario', 'vbnchngfhgjfhgj', 'aceptada', '2026-09-13 22:30:07.723734', 'Trayecto I', 'CIIDI-2026-29E32', NULL);
INSERT INTO public.propuestas_empresa VALUES (5, 'Megacell', 'J-12045552-', 'Miki waza', '04121609721', 'lando1609721@gmail.com', 'inventario', 'Necesito un sistema que haga inventario', 'rechazada', '2026-08-25 17:16:56.513754', 'Trayecto II', NULL, NULL);
INSERT INTO public.propuestas_empresa VALUES (6, 'Megacell', 'J20789378', 'Miki waza', '0414-7573234', 'lando1609721@gmail.com', 'inventario', 'necesito un sistema para mi alacen', 'aceptada', '2026-09-09 21:47:51.4141', 'Trayecto I', 'CIIDI-2026-AF997', NULL);
INSERT INTO public.propuestas_empresa VALUES (7, 'Megacellll', 'J20789378', 'Miki waza', '04121609721', 'lando16097211@gmail.com', 'redes', '11111111111111', 'aceptada', '2026-09-10 23:12:34.730038', 'Trayecto I', 'CIIDI-2026-4050F', NULL);
INSERT INTO public.propuestas_empresa VALUES (8, 'Punto Yali', '27889926', 'Miki waza', '04121609721', 'orlando5711666@gmail.com', 'inventario', 'necesito ayuda con respecto a un sistema que me controle el inventario de los productos que vendo aca en el local', 'aceptada', '2026-09-13 18:02:49.521927', 'Trayecto I', 'CIIDI-2026-84BAE', NULL);
INSERT INTO public.propuestas_empresa VALUES (9, 'gregoria', '123456789', 'Miki waza', '04121609721', 'orlando5711666@gmail.com', 'facturacion', 'hola', 'aceptada', '2026-09-13 18:42:50.07038', 'Trayecto II', 'CIIDI-2026-4DDC5', NULL);
INSERT INTO public.propuestas_empresa VALUES (11, 'zambrano cell', '27889926', 'chailon', '04121609721', 'lando1609721@gmail.com', 'inventario', 'ailberth deje de robarse las pantallas pa su primo chamo', 'aceptada', '2026-09-13 18:55:13.333522', 'Trayecto III', 'CIIDI-2026-E5EAE', NULL);
INSERT INTO public.propuestas_empresa VALUES (10, 'carmencita coito', '12345567889', 'Miki boss', '04121609721', 'lando1609721@gmail.com', 'datos', 'yisus porfa ordeña a carmencita sisisisi', 'aceptada', '2026-09-13 18:53:14.455601', 'Trayecto IV', 'CIIDI-2026-D55D0', NULL);
INSERT INTO public.propuestas_empresa VALUES (4, 'Punto G De Yali', 'G-30676767-0', 'Iojan', '4147755888', 'Puntogdeyali@gmail.com', 'redes', 'Quiero un sistema de clasificacion de los pelos de mi anito riko mmm sisisii', 'aceptada', '2026-07-10 14:02:25.411413', 'Trayecto I', NULL, NULL);
INSERT INTO public.propuestas_empresa VALUES (1, 'Megacell', 'J-12045552-', 'ELLL PRIMOOOO', '04121609721', 'lando1609721@gmail.com', 'facturacion', 'NECESITAMOS UN SISTEMA PARA CLASIFICAR FEMBOY, FURROS Y KPOPERAS ', 'aceptada', '2026-07-10 00:05:36.297999', 'Trayecto I', NULL, NULL);
INSERT INTO public.propuestas_empresa VALUES (12, 'Megacell', 'J20789378', 'chailon', '04121609721', 'lando1609721@gmail.com', 'Sistema de Inventario', 'necesito un sistema para poder registrar los telefonos que estamo haciendo', 'aceptada', '2026-09-13 19:46:05.970023', 'Trayecto I', 'CIIDI-2026-F5A16', NULL);
INSERT INTO public.propuestas_empresa VALUES (13, 'Punto Yali', '20789378', 'Miki boss', '04121609721', 'lando1609721@gmail.com', 'Sistema de Inventario', 'caafagsdfddsfdsfdsf', 'aceptada', '2026-09-13 22:28:56.260924', 'Trayecto I', 'CIIDI-2026-EC9AC', NULL);
INSERT INTO public.propuestas_empresa VALUES (15, 'zambrano cell', '20789378', 'chailon', '04121609721', 'lando1609721@gmail.com', 'Mejora de sistema', 'ghfjhmfhjfgdjhfd', 'aceptada', '2026-09-13 22:30:21.539904', 'Trayecto I', 'CIIDI-2026-C8F0D', NULL);


--
-- Data for Name: proyecto_tutores; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.proyecto_tutores VALUES (57, 7, 3);
INSERT INTO public.proyecto_tutores VALUES (57, 8, 2);
INSERT INTO public.proyecto_tutores VALUES (57, 9, 4);


--
-- Data for Name: recurso_autores; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.recurso_autores VALUES (3, 1);
INSERT INTO public.recurso_autores VALUES (57, 41);
INSERT INTO public.recurso_autores VALUES (58, 42);
INSERT INTO public.recurso_autores VALUES (58, 43);
INSERT INTO public.recurso_autores VALUES (58, 44);
INSERT INTO public.recurso_autores VALUES (62, 47);
INSERT INTO public.recurso_autores VALUES (62, 48);
INSERT INTO public.recurso_autores VALUES (63, 49);
INSERT INTO public.recurso_autores VALUES (63, 50);
INSERT INTO public.recurso_autores VALUES (63, 51);
INSERT INTO public.recurso_autores VALUES (63, 52);
INSERT INTO public.recurso_autores VALUES (64, 53);
INSERT INTO public.recurso_autores VALUES (64, 54);
INSERT INTO public.recurso_autores VALUES (64, 55);
INSERT INTO public.recurso_autores VALUES (64, 56);
INSERT INTO public.recurso_autores VALUES (65, 57);
INSERT INTO public.recurso_autores VALUES (65, 58);
INSERT INTO public.recurso_autores VALUES (65, 59);
INSERT INTO public.recurso_autores VALUES (65, 60);


--
-- Data for Name: recurso_categorias; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Data for Name: recurso_clasificaciones; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.recurso_clasificaciones VALUES (49, 7, 5);
INSERT INTO public.recurso_clasificaciones VALUES (50, 8, 10);
INSERT INTO public.recurso_clasificaciones VALUES (51, 9, 16);
INSERT INTO public.recurso_clasificaciones VALUES (52, 10, 18);
INSERT INTO public.recurso_clasificaciones VALUES (57, 9, 17);


--
-- Data for Name: recurso_etiquetas; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.recurso_etiquetas VALUES (58, 1);
INSERT INTO public.recurso_etiquetas VALUES (62, 3);
INSERT INTO public.recurso_etiquetas VALUES (62, 1);
INSERT INTO public.recurso_etiquetas VALUES (63, 8);
INSERT INTO public.recurso_etiquetas VALUES (64, 10);
INSERT INTO public.recurso_etiquetas VALUES (65, 1);
INSERT INTO public.recurso_etiquetas VALUES (65, 2);
INSERT INTO public.recurso_etiquetas VALUES (65, 4);


--
-- Data for Name: recursos; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.recursos VALUES (1, 'Sistema de Reconocimiento Biométrico Facial para Comedor Universitario', 1, 2026, 1, 1, NULL);
INSERT INTO public.recursos VALUES (2, 'Prototipo de Cerradura Digital con Matriz de Teclado y Arduino', 1, 2025, 1, 1, NULL);
INSERT INTO public.recursos VALUES (3, 'Aplicación de Redes Neuronales Convolucionales para la Detección de Plagas en Cultivos Trujillanos', 2, 2026, 1, 1, NULL);
INSERT INTO public.recursos VALUES (4, 'Impacto del Cambio Climático en Trujillo - Parte 8', 2, 2023, 1, 1, 'dummy.pdf');
INSERT INTO public.recursos VALUES (5, 'Simulación de Cargas Estáticas en Puentes - Parte 7', 2, 2024, 1, 1, 'dummy.pdf');
INSERT INTO public.recursos VALUES (6, 'Big Data en Finanzas Institucionales - Parte 9', 1, 2024, 1, 1, 'dummy.pdf');
INSERT INTO public.recursos VALUES (7, 'Optimización de CPU en Servidores Locales - Parte 7', 1, 2026, 1, 1, 'dummy.pdf');
INSERT INTO public.recursos VALUES (8, 'Sistemas de Riego Automatizado - Parte 5', 1, 2023, 1, 1, 'dummy.pdf');
INSERT INTO public.recursos VALUES (9, 'Bioinformática y Análisis de ADN - Parte 5', 3, 2025, 1, 1, 'dummy.pdf');
INSERT INTO public.recursos VALUES (10, 'Inteligencia Artificial en Diagnóstico Médico - Parte 6', 2, 2025, 1, 1, 'dummy.pdf');
INSERT INTO public.recursos VALUES (11, 'Robótica Educativa para Escuelas - Parte 5', 3, 2023, 1, 1, 'dummy.pdf');
INSERT INTO public.recursos VALUES (12, 'Software Libre para Bibliotecas - Parte 1', 3, 2026, 1, 1, 'dummy.pdf');
INSERT INTO public.recursos VALUES (13, 'E-Learning para Zonas Desfavorecidas - Parte 1', 3, 2018, 1, 1, 'dummy.pdf');
INSERT INTO public.recursos VALUES (14, 'Telecomunicaciones de Fibra Óptica Rural - Parte 1', 2, 2022, 1, 1, 'dummy.pdf');
INSERT INTO public.recursos VALUES (15, 'Criptografía Cuántica Post-RSA - Parte 2', 1, 2024, 1, 1, 'dummy.pdf');
INSERT INTO public.recursos VALUES (16, 'Criptografía Cuántica Post-RSA - Parte 7', 3, 2026, 1, 1, 'dummy.pdf');
INSERT INTO public.recursos VALUES (17, 'Criptografía Cuántica Post-RSA - Parte 5', 1, 2024, 1, 1, 'dummy.pdf');
INSERT INTO public.recursos VALUES (18, 'Criptografía Cuántica Post-RSA - Parte 8', 1, 2021, 1, 1, 'dummy.pdf');
INSERT INTO public.recursos VALUES (19, 'Software Libre para Bibliotecas - Parte 6', 1, 2023, 1, 1, 'dummy.pdf');
INSERT INTO public.recursos VALUES (20, 'Inteligencia Artificial en Diagnóstico Médico - Parte 1', 3, 2020, 1, 1, 'dummy.pdf');
INSERT INTO public.recursos VALUES (45, 'Desarrollo de un Motor para Novelas Visuales Nativas usando Rust y Tauri', 1, 2026, 2, 2, 'motor_rust_tauri_v1.pdf');
INSERT INTO public.recursos VALUES (46, 'Arquitectura de L¢gica de Estados para Videojuegos en Consolas Virtuales TIC-80', 1, 2025, 1, 1, 'juego_aislamiento_tic80.pdf');
INSERT INTO public.recursos VALUES (47, 'Protocolo de Restauraci¢n y Diagn¢stico de Capacitores en Tarjetas Madre Socket 478', 1, 2026, 3, 3, 'restauracion_pentium4.pdf');
INSERT INTO public.recursos VALUES (48, 'Implementaci¢n de un Enrutador Din mico basado en Arquitectura Microkernel con PHP Puro', 1, 2026, 1, 1, 'microkernel_php_routing.pdf');
INSERT INTO public.recursos VALUES (49, 'Sistema de Informaci¢n Automatizado para la Gesti¢n de Inventario y Suministros M‚dicos', 1, 2026, 1, 1, 'proyecto_inventario_medico.pdf');
INSERT INTO public.recursos VALUES (50, 'Software Educativo Multimedial para el Fortalecimiento del Aprendizaje de µlgebra Lineal', 1, 2026, 1, 1, 'software_educativo_algebra.pdf');
INSERT INTO public.recursos VALUES (51, 'Plataforma Web bajo Arquitectura Cliente-Servidor para el Control de Citas Acad‚micas', 1, 2025, 1, 1, 'plataforma_web_citas.pdf');
INSERT INTO public.recursos VALUES (52, 'Simulador de Enrutamiento por Estado de Enlace para la Validaci¢n de Topolog¡as Complejas', 1, 2026, 1, 1, 'simulador_routing_topologias.pdf');
INSERT INTO public.recursos VALUES (57, 'hola adios', 1, 2026, 1, 1, 'documentos/pst/pst_hola_adios_1783290093.pdf');
INSERT INTO public.recursos VALUES (58, 'Middleware MiSCi para ciudades inteligentes extendido con datos enlazados', 3, 2020, 1, 1, 'https://revistas.unal.edu.co/index.php/dyna/article/view/83226');
INSERT INTO public.recursos VALUES (65, 'Entorno virtual de capacitación con EOG para manipular robots asistenciales', 3, 2026, 1, 1, 'https://revistas.unal.edu.co/index.php/dyna/article/view/124310/98135');
INSERT INTO public.recursos VALUES (62, 'Determinantes de la aceptación del uso de la banca móvil por parte de ganaderos', 3, 2026, 1, 1, 'https://revistas.unal.edu.co/index.php/dyna/article/view/121522/97457');
INSERT INTO public.recursos VALUES (63, 'Modelo matemático para el balance de calor de un techo verde en condiciones de trópico húmedo', 3, 2026, 1, 1, 'https://revistas.unal.edu.co/index.php/dyna/article/view/123977/97473');
INSERT INTO public.recursos VALUES (64, 'Revisión sistemática del impacto de las fibras de polipropileno en las propiedades físico-mecánicas, microestructurales y de durabilidad del concreto', 3, 2026, 1, 1, 'https://revistas.unal.edu.co/index.php/dyna/article/view/121649/97474');


--
-- Data for Name: registro_actividad; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.registro_actividad VALUES (1, 1, NULL, '2026-03-23 14:49:58', '2026-03-23 14:49:58', 1);


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.roles VALUES (3, 'Estudiante', 1);
INSERT INTO public.roles VALUES (4, 'Profesor', 2);
INSERT INTO public.roles VALUES (2, 'Comite', 3);
INSERT INTO public.roles VALUES (1, 'Super Administrador', 1);


--
-- Data for Name: tipo_recurso; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.tipo_recurso VALUES (1, 'PST / Trabajo de Grado', 'Proyectos Socio-Tecnológicos y Tesis');
INSERT INTO public.tipo_recurso VALUES (2, 'Investigación Docente', 'Papers y artículos de investigación del personal académico');
INSERT INTO public.tipo_recurso VALUES (3, 'Material de Apoyo / Didáctico', 'Recursos adicionales para estudiantes');


--
-- Data for Name: tipo_tutor; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.tipo_tutor VALUES (1, 'Director', 'Director principal del proyecto');
INSERT INTO public.tipo_tutor VALUES (2, 'Coordinador', 'Asesor metodológico');
INSERT INTO public.tipo_tutor VALUES (3, 'Tutor Académico', 'Especialista en el área');
INSERT INTO public.tipo_tutor VALUES (4, 'Tutor Comunitario', 'Representante de la comunidad');


--
-- Data for Name: tutores; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.tutores VALUES (1, 'Lando', 'V-12345678');
INSERT INTO public.tutores VALUES (2, 'Mikeyisito', 'V-18765432');
INSERT INTO public.tutores VALUES (3, 'María Antonieta Pérez', 'V-15444333');
INSERT INTO public.tutores VALUES (7, 'aaaaa aaa', '22222');
INSERT INTO public.tutores VALUES (8, 'aaa aaaa', '33333');
INSERT INTO public.tutores VALUES (9, 'aaaaa aaaaaa', '444444');


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.usuarios VALUES (1, 'Adrus', 'andru@gmail.com', '11111111', '$2y$10$o0Uk8V6gzXNSW/EZBWvd1OoC7O6UzrU3LRbDMIqxYDou2KJGRXdUa', 1, true, NULL, NULL, NULL);
INSERT INTO public.usuarios VALUES (2, 'lando', 'lando@gmail.com', '22222222', '$2y$10$o0Uk8V6gzXNSW/EZBWvd1OoC7O6UzrU3LRbDMIqxYDou2KJGRXdUa', 2, true, NULL, NULL, NULL);
INSERT INTO public.usuarios VALUES (3, 'miki', 'miki@gmail.com', '33333333', '$2y$10$o0Uk8V6gzXNSW/EZBWvd1OoC7O6UzrU3LRbDMIqxYDou2KJGRXdUa', 3, true, NULL, NULL, NULL);
INSERT INTO public.usuarios VALUES (4, 'ale', 'ale@yaju.com', '44444444', '$2y$10$o0Uk8V6gzXNSW/EZBWvd1OoC7O6UzrU3LRbDMIqxYDou2KJGRXdUa', 3, true, NULL, NULL, NULL);
INSERT INTO public.usuarios VALUES (5, 'bibi', 'bibi@gmail.com', '4444111', NULL, 3, true, NULL, NULL, NULL);
INSERT INTO public.usuarios VALUES (8, 'Yisu Monte', 'yisu@gmail.com', '30866991', '$2y$10$jOukhIGIbdJCmpHdS.MqWusufmhQgHf.O9UByeqN.NFue38kT47xa', 3, true, NULL, NULL, NULL);
INSERT INTO public.usuarios VALUES (9, 'Pedro Perez', 'iaiaia@gmail.com', '4123123', '$2y$10$xOgs5kJnv17wwzjNtnNUguWc7pxdYv.lMZGFejPOz7fIgLNEybLgC', 3, true, NULL, NULL, NULL);
INSERT INTO public.usuarios VALUES (11, 'Juan', '123@gmail.com', '1234', '$2y$10$HBPGRak0eIYzElwfC.bGuOvgFOfK.GbG40ct2e7X9CS7OgMARJRcC', 3, true, NULL, NULL, NULL);
INSERT INTO public.usuarios VALUES (7, 'Miguel González', 'erwazaaaa@gmail.com', '32621284', '$2y$10$tqm17pwan91BnMUfmCAB/O01faShLfeK3jo0jYVwpQcBpGr5iLiE.', 1, true, NULL, NULL, NULL);
INSERT INTO public.usuarios VALUES (6, 'Piñin Piña', 'pina@hotmail.com', '1', '$2y$10$wqwwyjK8T7ccki5IeOK4ueZRlW8K3g2xC42ZyOG01kDru0CNhba/a', 4, false, NULL, NULL, NULL);
INSERT INTO public.usuarios VALUES (10, 'Wazaaaa', 'wazaaa@gmail.com', '123', '$2y$10$G7tnCsgxNo7nFV93A4H7Ie86N2RYtbppgkB6iEPg.STWF4wn2qn7O', 4, true, NULL, NULL, NULL);
INSERT INTO public.usuarios VALUES (14, 'Pipin', 'pipa1234@gmail.com', '070901', '$2y$10$xGRULeH8pgYcuPKA4Asnbe0S8i5Nv2c8x4SE6Z.W9FkWoPB7afbUa', 2, true, NULL, NULL, NULL);
INSERT INTO public.usuarios VALUES (13, 'landorus', 'lando1609721@gmail.com', '12045552', '$2y$10$Bg2GX/JWpEVqEhnERGgsIOKT9wAIhUZ0T7mmofYU1kkkmOQu5fH.e', 2, true, '798360', '2026-09-13 11:45:30.358069', NULL);
INSERT INTO public.usuarios VALUES (15, 'orlando', 'orlando5711666@gmail.com', '27889926', '$2y$10$xy0tWWeRlPRXcTiL.JbEwuywNXtfk9djNSz6ZdhtX3lET04yJBkVS', 3, true, NULL, NULL, NULL);


--
-- Data for Name: visitantes; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- Name: accesos_recursos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accesos_recursos_id_seq', 1, false);


--
-- Name: auditoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auditoria_id_seq', 165, true);


--
-- Name: autores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.autores_id_seq', 60, true);


--
-- Name: carreras_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.carreras_id_seq', 5, true);


--
-- Name: categorias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categorias_id_seq', 18, true);


--
-- Name: cursos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cursos_id_seq', 4, true);


--
-- Name: dimensiones_operativas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dimensiones_operativas_id_seq', 20, true);


--
-- Name: editoriales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.editoriales_id_seq', 9, true);


--
-- Name: etiquetas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.etiquetas_id_seq', 10, true);


--
-- Name: historico_versiones_pst_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.historico_versiones_pst_id_seq', 1, false);


--
-- Name: investigaciones_ofertadas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.investigaciones_ofertadas_id_seq', 310, true);


--
-- Name: lineas_investigacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lineas_investigacion_id_seq', 13, true);


--
-- Name: notificaciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notificaciones_id_seq', 6, true);


--
-- Name: postulaciones_estudiantes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.postulaciones_estudiantes_id_seq', 13, true);


--
-- Name: privilegios_privilegio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.privilegios_privilegio_id_seq', 6, true);


--
-- Name: propuestas_empresa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.propuestas_empresa_id_seq', 15, true);


--
-- Name: recursos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recursos_id_seq', 65, true);


--
-- Name: registro_actividad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.registro_actividad_id_seq', 1, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 4, true);


--
-- Name: tipo_recurso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_recurso_id_seq', 4, true);


--
-- Name: tipo_tutor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_tutor_id_seq', 4, true);


--
-- Name: tutores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tutores_id_seq', 9, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 15, true);


--
-- Name: visitantes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.visitantes_id_seq', 1, false);


--
-- Name: accesos_recursos accesos_recursos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesos_recursos
    ADD CONSTRAINT accesos_recursos_pkey PRIMARY KEY (id);


--
-- Name: auditoria auditoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auditoria
    ADD CONSTRAINT auditoria_pkey PRIMARY KEY (id);


--
-- Name: autores autores_cedula_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.autores
    ADD CONSTRAINT autores_cedula_key UNIQUE (cedula);


--
-- Name: autores autores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.autores
    ADD CONSTRAINT autores_pkey PRIMARY KEY (id);


--
-- Name: carreras carreras_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carreras
    ADD CONSTRAINT carreras_nombre_key UNIQUE (nombre);


--
-- Name: carreras carreras_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carreras
    ADD CONSTRAINT carreras_pkey PRIMARY KEY (id);


--
-- Name: categorias categorias_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_nombre_key UNIQUE (nombre);


--
-- Name: categorias categorias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_pkey PRIMARY KEY (id);


--
-- Name: cursos cursos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cursos
    ADD CONSTRAINT cursos_pkey PRIMARY KEY (id);


--
-- Name: detalles_investigaciones detalles_investigaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_investigaciones
    ADD CONSTRAINT detalles_investigaciones_pkey PRIMARY KEY (id_recurso);


--
-- Name: detalles_proyectos detalles_proyectos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_proyectos
    ADD CONSTRAINT detalles_proyectos_pkey PRIMARY KEY (id_recurso);


--
-- Name: detalles_articulos detalles_revistas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_articulos
    ADD CONSTRAINT detalles_revistas_pkey PRIMARY KEY (id_recurso);


--
-- Name: dimensiones_operativas dimensiones_operativas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimensiones_operativas
    ADD CONSTRAINT dimensiones_operativas_pkey PRIMARY KEY (id);


--
-- Name: editoriales editoriales_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.editoriales
    ADD CONSTRAINT editoriales_nombre_key UNIQUE (nombre);


--
-- Name: editoriales editoriales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.editoriales
    ADD CONSTRAINT editoriales_pkey PRIMARY KEY (id);


--
-- Name: etiquetas etiquetas_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.etiquetas
    ADD CONSTRAINT etiquetas_nombre_key UNIQUE (nombre);


--
-- Name: etiquetas etiquetas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.etiquetas
    ADD CONSTRAINT etiquetas_pkey PRIMARY KEY (id);


--
-- Name: historico_versiones_pst historico_versiones_pst_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.historico_versiones_pst
    ADD CONSTRAINT historico_versiones_pst_pkey PRIMARY KEY (id);


--
-- Name: investigaciones_ofertadas investigaciones_ofertadas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investigaciones_ofertadas
    ADD CONSTRAINT investigaciones_ofertadas_pkey PRIMARY KEY (id);


--
-- Name: lineas_investigacion lineas_investigacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lineas_investigacion
    ADD CONSTRAINT lineas_investigacion_pkey PRIMARY KEY (id);


--
-- Name: notificaciones notificaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notificaciones
    ADD CONSTRAINT notificaciones_pkey PRIMARY KEY (id);


--
-- Name: postulaciones_estudiantes postulaciones_estudiantes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postulaciones_estudiantes
    ADD CONSTRAINT postulaciones_estudiantes_pkey PRIMARY KEY (id);


--
-- Name: preferencias_usuario preferencias_usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preferencias_usuario
    ADD CONSTRAINT preferencias_usuario_pkey PRIMARY KEY (id_usuario);


--
-- Name: privilegios privilegios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.privilegios
    ADD CONSTRAINT privilegios_pkey PRIMARY KEY (privilegio_id);


--
-- Name: propuestas_empresa propuestas_empresa_codigo_seguimiento_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.propuestas_empresa
    ADD CONSTRAINT propuestas_empresa_codigo_seguimiento_key UNIQUE (codigo_seguimiento);


--
-- Name: propuestas_empresa propuestas_empresa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.propuestas_empresa
    ADD CONSTRAINT propuestas_empresa_pkey PRIMARY KEY (id);


--
-- Name: proyecto_tutores proyecto_tutores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proyecto_tutores
    ADD CONSTRAINT proyecto_tutores_pkey PRIMARY KEY (id_recurso, id_tutor);


--
-- Name: recurso_autores recurso_autores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_autores
    ADD CONSTRAINT recurso_autores_pkey PRIMARY KEY (id_recurso, id_autor);


--
-- Name: recurso_categorias recurso_categorias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_categorias
    ADD CONSTRAINT recurso_categorias_pkey PRIMARY KEY (id_recurso, id_categoria);


--
-- Name: recurso_clasificaciones recurso_clasificaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_clasificaciones
    ADD CONSTRAINT recurso_clasificaciones_pkey PRIMARY KEY (id_recurso, id_linea_investigacion);


--
-- Name: recurso_etiquetas recurso_etiquetas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_etiquetas
    ADD CONSTRAINT recurso_etiquetas_pkey PRIMARY KEY (id_recurso, id_etiqueta);


--
-- Name: recursos recursos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recursos
    ADD CONSTRAINT recursos_pkey PRIMARY KEY (id);


--
-- Name: registro_actividad registro_actividad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registro_actividad
    ADD CONSTRAINT registro_actividad_pkey PRIMARY KEY (id);


--
-- Name: roles roles_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_nombre_key UNIQUE (nombre);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: tipo_recurso tipo_recurso_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_recurso
    ADD CONSTRAINT tipo_recurso_nombre_key UNIQUE (nombre);


--
-- Name: tipo_recurso tipo_recurso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_recurso
    ADD CONSTRAINT tipo_recurso_pkey PRIMARY KEY (id);


--
-- Name: tipo_tutor tipo_tutor_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_tutor
    ADD CONSTRAINT tipo_tutor_nombre_key UNIQUE (nombre);


--
-- Name: tipo_tutor tipo_tutor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_tutor
    ADD CONSTRAINT tipo_tutor_pkey PRIMARY KEY (id);


--
-- Name: tutores tutores_cedula_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tutores
    ADD CONSTRAINT tutores_cedula_key UNIQUE (cedula);


--
-- Name: tutores tutores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tutores
    ADD CONSTRAINT tutores_pkey PRIMARY KEY (id);


--
-- Name: postulaciones_estudiantes unique_postulacion; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postulaciones_estudiantes
    ADD CONSTRAINT unique_postulacion UNIQUE (id_investigacion, id_estudiante);


--
-- Name: usuarios usuarios_cedula_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_cedula_key UNIQUE (cedula);


--
-- Name: usuarios usuarios_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_email_key UNIQUE (email);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: visitantes visitantes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visitantes
    ADD CONSTRAINT visitantes_pkey PRIMARY KEY (id);


--
-- Name: idx_detalles_inv_ofertada; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_detalles_inv_ofertada ON public.detalles_investigaciones USING btree (id_investigacion_ofertada);


--
-- Name: idx_recurso_clasif_dimension; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_recurso_clasif_dimension ON public.recurso_clasificaciones USING btree (id_dimension_operativa);


--
-- Name: idx_recurso_clasif_linea; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_recurso_clasif_linea ON public.recurso_clasificaciones USING btree (id_linea_investigacion);


--
-- Name: recursos tg_auditoria_recursos_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tg_auditoria_recursos_delete BEFORE DELETE ON public.recursos FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_recursos();


--
-- Name: recursos tg_auditoria_recursos_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tg_auditoria_recursos_insert AFTER INSERT ON public.recursos FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_recursos();


--
-- Name: usuarios tg_auditoria_usuarios_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tg_auditoria_usuarios_delete BEFORE DELETE ON public.usuarios FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_usuarios();


--
-- Name: usuarios tg_auditoria_usuarios_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tg_auditoria_usuarios_insert AFTER INSERT ON public.usuarios FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_usuarios();


--
-- Name: usuarios tg_auditoria_usuarios_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tg_auditoria_usuarios_update AFTER UPDATE ON public.usuarios FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_usuarios();


--
-- Name: accesos_recursos accesos_recursos_id_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesos_recursos
    ADD CONSTRAINT accesos_recursos_id_recurso_fkey FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: accesos_recursos accesos_recursos_id_registro_actividad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesos_recursos
    ADD CONSTRAINT accesos_recursos_id_registro_actividad_fkey FOREIGN KEY (id_registro_actividad) REFERENCES public.registro_actividad(id) ON DELETE CASCADE;


--
-- Name: auditoria auditoria_usuario_responsable_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auditoria
    ADD CONSTRAINT auditoria_usuario_responsable_fkey FOREIGN KEY (usuario_responsable) REFERENCES public.usuarios(id) ON DELETE SET NULL;


--
-- Name: cursos cursos_id_docente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cursos
    ADD CONSTRAINT cursos_id_docente_fkey FOREIGN KEY (id_docente) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: detalles_proyectos detalles_proyectos_id_carrera_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_proyectos
    ADD CONSTRAINT detalles_proyectos_id_carrera_fkey FOREIGN KEY (id_carrera) REFERENCES public.carreras(id) ON DELETE SET NULL;


--
-- Name: detalles_proyectos detalles_proyectos_id_investigacion_padre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_proyectos
    ADD CONSTRAINT detalles_proyectos_id_investigacion_padre_fkey FOREIGN KEY (id_investigacion_padre) REFERENCES public.recursos(id) ON DELETE SET NULL;


--
-- Name: detalles_proyectos detalles_proyectos_id_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_proyectos
    ADD CONSTRAINT detalles_proyectos_id_recurso_fkey FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: detalles_articulos detalles_revistas_id_editorial_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_articulos
    ADD CONSTRAINT detalles_revistas_id_editorial_fkey FOREIGN KEY (id_editorial) REFERENCES public.editoriales(id) ON DELETE SET NULL;


--
-- Name: detalles_articulos detalles_revistas_id_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_articulos
    ADD CONSTRAINT detalles_revistas_id_recurso_fkey FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: detalles_articulos fk_detalles_articulos_categoria; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_articulos
    ADD CONSTRAINT fk_detalles_articulos_categoria FOREIGN KEY (id_categoria) REFERENCES public.categorias(id) ON DELETE SET NULL;


--
-- Name: detalles_investigaciones fk_detalles_investigaciones_ofertada; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_investigaciones
    ADD CONSTRAINT fk_detalles_investigaciones_ofertada FOREIGN KEY (id_investigacion_ofertada) REFERENCES public.investigaciones_ofertadas(id) ON DELETE SET NULL;


--
-- Name: detalles_investigaciones fk_detalles_investigaciones_recurso; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_investigaciones
    ADD CONSTRAINT fk_detalles_investigaciones_recurso FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: dimensiones_operativas fk_dimension_linea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dimensiones_operativas
    ADD CONSTRAINT fk_dimension_linea FOREIGN KEY (id_linea) REFERENCES public.lineas_investigacion(id) ON DELETE CASCADE;


--
-- Name: recurso_clasificaciones fk_dimension_operativa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_clasificaciones
    ADD CONSTRAINT fk_dimension_operativa FOREIGN KEY (id_dimension_operativa) REFERENCES public.dimensiones_operativas(id) ON DELETE SET NULL;


--
-- Name: recurso_etiquetas fk_etiqueta_recurso; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_etiquetas
    ADD CONSTRAINT fk_etiqueta_recurso FOREIGN KEY (id_etiqueta) REFERENCES public.etiquetas(id) ON DELETE CASCADE;


--
-- Name: investigaciones_ofertadas fk_inv_dimension; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investigaciones_ofertadas
    ADD CONSTRAINT fk_inv_dimension FOREIGN KEY (id_dimension) REFERENCES public.dimensiones_operativas(id) ON DELETE SET NULL;


--
-- Name: investigaciones_ofertadas fk_inv_linea; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investigaciones_ofertadas
    ADD CONSTRAINT fk_inv_linea FOREIGN KEY (id_linea) REFERENCES public.lineas_investigacion(id) ON DELETE RESTRICT;


--
-- Name: investigaciones_ofertadas fk_inv_profesor; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investigaciones_ofertadas
    ADD CONSTRAINT fk_inv_profesor FOREIGN KEY (id_profesor) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: investigaciones_ofertadas fk_inv_propuesta; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.investigaciones_ofertadas
    ADD CONSTRAINT fk_inv_propuesta FOREIGN KEY (id_propuesta_empresa) REFERENCES public.propuestas_empresa(id) ON DELETE SET NULL;


--
-- Name: recurso_clasificaciones fk_linea_investigacion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_clasificaciones
    ADD CONSTRAINT fk_linea_investigacion FOREIGN KEY (id_linea_investigacion) REFERENCES public.lineas_investigacion(id) ON DELETE CASCADE;


--
-- Name: postulaciones_estudiantes fk_postulacion_estudiante; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postulaciones_estudiantes
    ADD CONSTRAINT fk_postulacion_estudiante FOREIGN KEY (id_estudiante) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: postulaciones_estudiantes fk_postulacion_inv; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.postulaciones_estudiantes
    ADD CONSTRAINT fk_postulacion_inv FOREIGN KEY (id_investigacion) REFERENCES public.investigaciones_ofertadas(id) ON DELETE CASCADE;


--
-- Name: recurso_clasificaciones fk_recurso; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_clasificaciones
    ADD CONSTRAINT fk_recurso FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: recurso_etiquetas fk_recurso_etiqueta; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_etiquetas
    ADD CONSTRAINT fk_recurso_etiqueta FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: historico_versiones_pst fk_version_recurso; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.historico_versiones_pst
    ADD CONSTRAINT fk_version_recurso FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: lineas_investigacion lineas_investigacion_id_carrera_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lineas_investigacion
    ADD CONSTRAINT lineas_investigacion_id_carrera_fkey FOREIGN KEY (id_carrera) REFERENCES public.carreras(id) ON DELETE CASCADE;


--
-- Name: notificaciones notificaciones_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notificaciones
    ADD CONSTRAINT notificaciones_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: preferencias_usuario preferencias_usuario_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preferencias_usuario
    ADD CONSTRAINT preferencias_usuario_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: roles privilegio_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT privilegio_fk FOREIGN KEY (privilegio_id) REFERENCES public.privilegios(privilegio_id) NOT VALID;


--
-- Name: proyecto_tutores proyecto_tutores_id_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proyecto_tutores
    ADD CONSTRAINT proyecto_tutores_id_recurso_fkey FOREIGN KEY (id_recurso) REFERENCES public.detalles_proyectos(id_recurso) ON DELETE CASCADE;


--
-- Name: proyecto_tutores proyecto_tutores_id_tutor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proyecto_tutores
    ADD CONSTRAINT proyecto_tutores_id_tutor_fkey FOREIGN KEY (id_tutor) REFERENCES public.tutores(id) ON DELETE CASCADE;


--
-- Name: proyecto_tutores proyecto_tutores_tipo_tutor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proyecto_tutores
    ADD CONSTRAINT proyecto_tutores_tipo_tutor_id_fkey FOREIGN KEY (tipo_tutor_id) REFERENCES public.tipo_tutor(id) ON DELETE SET NULL;


--
-- Name: recurso_autores recurso_autores_id_autor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_autores
    ADD CONSTRAINT recurso_autores_id_autor_fkey FOREIGN KEY (id_autor) REFERENCES public.autores(id) ON DELETE CASCADE;


--
-- Name: recurso_autores recurso_autores_id_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_autores
    ADD CONSTRAINT recurso_autores_id_recurso_fkey FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: recurso_categorias recurso_categorias_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_categorias
    ADD CONSTRAINT recurso_categorias_id_categoria_fkey FOREIGN KEY (id_categoria) REFERENCES public.categorias(id) ON DELETE CASCADE;


--
-- Name: recurso_categorias recurso_categorias_id_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_categorias
    ADD CONSTRAINT recurso_categorias_id_recurso_fkey FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: recursos recursos_id_tipo_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recursos
    ADD CONSTRAINT recursos_id_tipo_recurso_fkey FOREIGN KEY (id_tipo_recurso) REFERENCES public.tipo_recurso(id) ON DELETE RESTRICT;


--
-- Name: registro_actividad registro_actividad_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registro_actividad
    ADD CONSTRAINT registro_actividad_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id) ON DELETE SET NULL;


--
-- Name: registro_actividad registro_actividad_id_visitante_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registro_actividad
    ADD CONSTRAINT registro_actividad_id_visitante_fkey FOREIGN KEY (id_visitante) REFERENCES public.visitantes(id) ON DELETE SET NULL;


--
-- Name: usuarios usuarios_id_rol_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_id_rol_fkey FOREIGN KEY (id_rol) REFERENCES public.roles(id) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict EyIjV4b3ZwMAbxG8brlR0uVSgZ6pCq0IYZodnMEPn56JvsinAwRYjvDu1gPFgan

