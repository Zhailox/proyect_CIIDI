<?php
// core/Interfaces/ModuleContract.php

interface ModuleContract {
    /**
     * Devuelve el nombre oficial del módulo
     */
    public function getNombre(): string;

    /**
     * Devuelve un arreglo con todas las rutas que este módulo maneja,
     * incluyendo la vista que debe cargar y el título de la página.
     */
    public function getRutas(): array;

    /**
     * Devuelve la configuración del menú para este módulo que se verá reflejado en el sidebar.
     */
    public function getMenuConfig(): array;
}