<?php
// core/System/Kernel.php
require_once CORE_PATH . 'Interfaces/ModuleContract.php';

class Kernel {
    
    private $rutasGlobales = [];
    private $modulosInstalados = [];
    private $menuGlobal = []; // NUEVO: Aquí guardaremos el menú de todos los módulos

    public function __construct() {
        $this->cargarModulos();
    }

    private function cargarModulos() {
        $carpetas = array_diff(scandir(MODULES_PATH), array('.', '..'));
        
        foreach ($carpetas as $carpeta) {
            $ruta_index_modulo = MODULES_PATH . $carpeta . '/index.php';
            
            if (file_exists($ruta_index_modulo)) {
                $modulo = require_once $ruta_index_modulo;
                
                if ($modulo instanceof ModuleContract) {
                    $this->modulosInstalados[$modulo->getNombre()] = $modulo;
                    $this->rutasGlobales = array_merge($this->rutasGlobales, $modulo->getRutas());
                    
                    // NUEVO: Recolectar la configuración del menú y fusionarla
                    $config_menu_modulo = $modulo->getMenuConfig();
                    if (!empty($config_menu_modulo)) {
                        $this->menuGlobal = array_merge($this->menuGlobal, $config_menu_modulo);
                    }
                }
            }
        }
    }

    public function run() {
        $ruta = isset($_GET['ruta']) ? $_GET['ruta'] : 'inicio';
        
        $css_modulo = []; 

        // 1. Ahora SOLO buscamos en las rutas globales dinámicas
        if (array_key_exists($ruta, $this->rutasGlobales)) {
            $vista_modulo_path = $this->rutasGlobales[$ruta]['vista'];
            $titulo_pagina     = $this->rutasGlobales[$ruta]['titulo'];
            $layout_config     = $this->rutasGlobales[$ruta]['layout'] ?? ['header' => true, 'sidebar' => true, 'footer' => true];
            $css_modulo        = $this->rutasGlobales[$ruta]['css'] ?? [];
        } 
        // 2. Si no existe, lanzamos el 404
        else {
            $vista_modulo_path = CORE_VIEWS . '404.php';
            $titulo_pagina     = '404 - Página No Encontrada';
            $layout_config     = ['header' => true, 'sidebar' => true, 'footer' => true];
        }

        $menu_dinamico = $this->menuGlobal; 

        if (file_exists(CORE_VIEWS . 'master.php')) {
            include CORE_VIEWS . 'master.php';
        } else {
            die("<h1 style='color:red;'>Error Crítico: No se encuentra master.php</h1>");
        }
    }
}