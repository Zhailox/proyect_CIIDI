<footer class="main-footer">
  <div class="footer-container">
    
    <div class="footer-column">
      <h3 class="footer-title">Ubícanos</h3>
      <p class="footer-text">
        <strong>Dirección:</strong> Núcleo San Luis (Sede Rectoral)<br>
        Av. La Feria Sector San Luis Valera, Estado Trujillo - Venezuela
      </p>
      <p class="footer-text" style="margin-top: 1rem;">
        <strong>Teléfonos:</strong><br>
        Rectorado: (58) 0271-221.29.27<br>
        Vicerrectorado Académico: 0271-221.51.47
      </p>
    </div>

    <div class="footer-column">
      <h3 class="footer-title">Núcleos</h3>
      <p class="footer-text" style="font-size: 0.85rem; line-height: 1.8;">
        <strong>Boconó:</strong> Calle Colón con Av. Independencia (Antiguo Hospital "Rafael Rangel"). Tel: 0272-652.31.11<br>
        <strong>El Dividive:</strong> Autopista Panamericana, El Dividive. Tel: 0272-666.01.14<br>
        <strong>La Beatriz:</strong> Urb. La Beatriz Parte Alta, al lado del Parque Botánico. Tel: 0271-231.11.10<br>
        <strong>Trujillo:</strong> Av. Cristóbal Mendoza detrás del Mercado Municipal. Tel: 0272-236.31.61<br>
        <strong>Ext. Carache:</strong> Calle Vargas entre Av.2 y Av.3, al lado Alcaldía del Municipio Carache. Tel: 0272-999.16.05
      </p>
    </div>

    <div class="footer-column">
      <h3 class="footer-title">Sigue Nuestras Redes Sociales</h3>
      <ul class="footer-links">
        <li><a href="#">Facebook: Gestión UPTTMBI</a></li>
        <li><a href="#">Twitter: @upttmbi</a></li>
        <li><a href="#">Instagram: @upttmbi</a></li>
        <li><a href="#">YouTube: @upttmbi</a></li>
      </ul>
      
      <p class="footer-text" style="margin-top: 1.5rem; font-style: italic; font-weight: bold; color: var(--blanco);">
        "Somos Excelencia Académica para Construir Patria..."
      </p>
    </div>

  </div>

  <div class="footer-bottom">
    <p>&copy; 2026 UPTTMBI. Todos los derechos reservados.</p>
  </div>
</footer>