<aside class="sidebar">
  <h2 class="sidebar-title">Navegación Global</h2>
  <nav class="nav-menu">
    
    <a href="inicio" class="nav-item <?php echo ($ruta == 'inicio') ? 'active' : ''; ?>">
        <span class="nav-icon">🏠</span> Inicio
    </a>
    
    <?php foreach ($menu_dinamico as $item): ?>
        
        <?php if ($item['tipo'] === 'link'): // Si es un botón simple directo ?>
            
            <a href="<?php echo $item['enlace']; ?>" class="nav-item <?php echo ($ruta == $item['enlace']) ? 'active' : ''; ?>">
                <span class="nav-icon"><?php echo $item['icono']; ?></span> <?php echo $item['titulo']; ?>
            </a>
            
        <?php elseif ($item['tipo'] === 'parent'): // Si es un grupo con submenús ?>
            
            <?php 
                // Verificamos si la ruta actual está dentro del arreglo de activadores del padre
                $is_active_parent = in_array($ruta, $item['activadores']); 
            ?>
            
            <div class="nav-parent">
                <a href="<?php echo $item['enlace']; ?>" class="nav-item <?php echo $is_active_parent ? 'active' : ''; ?>">
                  <span class="nav-icon"><?php echo $item['icono']; ?></span> <?php echo $item['titulo']; ?>
                </a>
                
                <?php if ($is_active_parent && !empty($item['subitems'])): ?>
                <div class="sub-menu">
                    <?php foreach ($item['subitems'] as $sub): ?>
                        <a href="<?php echo $sub['ruta']; ?>" class="sub-nav-item <?php echo ($ruta == $sub['ruta']) ? 'active' : ''; ?>">
                            <?php echo $sub['titulo']; ?>
                        </a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
            
        <?php endif; ?>
        
    <?php endforeach; ?>

  </nav>
</aside>