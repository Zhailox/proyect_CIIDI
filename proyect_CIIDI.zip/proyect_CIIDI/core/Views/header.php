<header class="main-header">
  <div class="logo-container">
    <span class="logo-text">Sistema Integral - </span><span class="logo-highlight">UPTTMBI</span>
  </div>
  
  <div class="header-actions" style="display: flex; align-items: center; gap: 1.5rem;">
    <div class="search-container">
      <input type="text" class="search-input" placeholder="Buscador Inteligente...">
    </div>
    
    <a href="login" class="btn">
      👤 Acceder
    </a>
  </div>
</header>