<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Repositorio Inteligente - UPTT</title>
  <link rel="stylesheet" href="../../public/assets/css/style.css">
</head>
<body>

  <div class="app-container">
    
    <aside class="sidebar">
      <h2 class="sidebar-title">Navegación Global</h2>
      <nav class="nav-menu">
        <a href="#" class="nav-item active">
          <span class="nav-icon">🏠</span> Inicio
        </a>
        <a href="#" class="nav-item">
          <span class="nav-icon">🔍</span> Búsqueda Inteligente
        </a>
        <a href="#" class="nav-item">
          <span class="nav-icon">👤</span> Login
        </a>
      </nav>
    </aside>

    <main class="main-content">
      
      <header class="welcome-banner">
        <h1>Bienvenido al Repositorio Inteligente</h1>
        <p>La plataforma definitiva para la gestión, visibilidad e impacto de la producción científica de la UPTT.</p>
      </header>

      <section class="cards-grid" aria-label="Características principales">
        
        <article class="card">
          <h3>Visibilidad PST</h3>
          <p>Acceso centralizado a todos los Proyectos Socio-Tecnológicos desarrollados por la comunidad.</p>
          <button type="button" class="btn">Ver más</button>
        </article>

        <article class="card featured">
          <h3>IA de Clasificación</h3>
          <p>Nuestra red neuronal organiza investigaciones automáticamente en las líneas estratégicas.</p>
          <button type="button" class="btn">Ver más</button>
        </article>

        <article class="card">
          <h3>Vinculación Real</h3>
          <p>Conexión directa entre problemas del sector productivo y soluciones académicas.</p>
          <button type="button" class="btn">Ver más</button>
        </article>

      </section>

    </main>
  </div>

</body>
</html>