<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $titulo_pagina ?? 'Sistema UPTTMBI'; ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <?php
    if (!empty($css_modulo)) {
        foreach ($css_modulo as $archivo_css) {
            // Imprime una etiqueta link por cada archivo registrado en el módulo
            echo '<link rel="stylesheet" href="' . $archivo_css . '">' . "\n";
        }
    }
    ?>
</head>
<body>
    
    <?php if ($layout_config['header'] ?? true): ?>
        <?php include CORE_VIEWS . 'header.php'; ?>
    <?php endif; ?>

    <main class="app-container">
        
        <?php if ($layout_config['sidebar'] ?? true): ?>
            <?php include CORE_VIEWS . 'sidebar.php'; ?>
        <?php endif; ?>
        
        <div class="main-content">
            <?php 
            if (!empty($vista_modulo_path) && file_exists($vista_modulo_path)) {
                include $vista_modulo_path;
            } else {
                echo "<h2>Error</h2><p>La vista no existe.</p>";
            }
            ?>
        </div>

    </main>

    <?php if ($layout_config['footer'] ?? true): ?>
        <?php include CORE_VIEWS . 'footer.php'; ?>
    <?php endif; ?>

</body>
</html>