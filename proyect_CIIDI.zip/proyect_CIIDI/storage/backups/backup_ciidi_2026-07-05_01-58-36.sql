--
-- PostgreSQL database dump
--

\restrict ZEIyYjeXJ9s4qxpyghHWJgqBNbNxAtn8lYDN5C1raroqkgG1Lpom5XcT4d4HkGU

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: accion_acceso_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.accion_acceso_enum AS ENUM (
    'visualizacion',
    'descarga'
);


ALTER TYPE public.accion_acceso_enum OWNER TO postgres;

--
-- Name: accion_auditoria_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.accion_auditoria_enum AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE'
);


ALTER TYPE public.accion_auditoria_enum OWNER TO postgres;

--
-- Name: estado_curso_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.estado_curso_enum AS ENUM (
    'borrador',
    'publicado',
    'archivado'
);


ALTER TYPE public.estado_curso_enum OWNER TO postgres;

--
-- Name: nivel_academico_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.nivel_academico_enum AS ENUM (
    'TSU',
    'Pregrado',
    'Especializacion',
    'Maestria',
    'Doctorado'
);


ALTER TYPE public.nivel_academico_enum OWNER TO postgres;

--
-- Name: tipo_interaccion_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tipo_interaccion_enum AS ENUM (
    'like',
    'bookmark'
);


ALTER TYPE public.tipo_interaccion_enum OWNER TO postgres;

--
-- Name: tipo_interaccion_usuario_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tipo_interaccion_usuario_enum AS ENUM (
    'like',
    'guardado'
);


ALTER TYPE public.tipo_interaccion_usuario_enum OWNER TO postgres;

--
-- Name: tipo_pregunta_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.tipo_pregunta_enum AS ENUM (
    'multiple',
    'v_f',
    'corta'
);


ALTER TYPE public.tipo_pregunta_enum OWNER TO postgres;

--
-- Name: fn_auditoria_recursos(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_auditoria_recursos() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Intenta leer una variable de sesión configurada por el backend, si no hay, asigna NULL
    v_usuario_actual INT := NULLIF(current_setting('app.usuario_actual', true), '')::INT; 
BEGIN
    IF (TG_OP = 'DELETE') THEN
        INSERT INTO auditoria (tabla_afectada, id_registro, accion, usuario_responsable, datos_anteriores, datos_nuevos, fecha_hora)
        VALUES ('recursos', OLD.id, 'DELETE', v_usuario_actual, jsonb_build_object('titulo', OLD.titulo, 'id_tipo_recurso', OLD.id_tipo_recurso), NULL, CURRENT_TIMESTAMP);
        RETURN OLD;
        
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO auditoria (tabla_afectada, id_registro, accion, usuario_responsable, datos_anteriores, datos_nuevos, fecha_hora)
        VALUES ('recursos', NEW.id, 'INSERT', v_usuario_actual, NULL, jsonb_build_object('titulo', NEW.titulo, 'id_tipo_recurso', NEW.id_tipo_recurso, 'ejemplares_totales', NEW.ejemplares_totales), CURRENT_TIMESTAMP);
        RETURN NEW;
    END IF;
    
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.fn_auditoria_recursos() OWNER TO postgres;

--
-- Name: fn_auditoria_usuarios(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_auditoria_usuarios() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_usuario_actual INT := NULLIF(current_setting('app.usuario_actual', true), '')::INT;
BEGIN
    IF (TG_OP = 'DELETE') THEN
        INSERT INTO auditoria (tabla_afectada, id_registro, accion, usuario_responsable, datos_anteriores, datos_nuevos, fecha_hora)
        VALUES ('usuarios', OLD.id, 'DELETE', v_usuario_actual, jsonb_build_object('nombre', OLD.nombre_completo, 'email', OLD.email, 'id_rol', OLD.id_rol), NULL, CURRENT_TIMESTAMP);
        RETURN OLD;
        
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO auditoria (tabla_afectada, id_registro, accion, usuario_responsable, datos_anteriores, datos_nuevos, fecha_hora)
        VALUES ('usuarios', NEW.id, 'INSERT', v_usuario_actual, NULL, jsonb_build_object('nombre', NEW.nombre_completo, 'email', NEW.email, 'id_rol', NEW.id_rol), CURRENT_TIMESTAMP);
        RETURN NEW;
        
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO auditoria (tabla_afectada, id_registro, accion, usuario_responsable, datos_anteriores, datos_nuevos, fecha_hora)
        VALUES ('usuarios', OLD.id, 'UPDATE', v_usuario_actual, 
                jsonb_build_object('nombre', OLD.nombre_completo, 'id_rol', OLD.id_rol, 'activo', OLD.activo), 
                jsonb_build_object('nombre', NEW.nombre_completo, 'id_rol', NEW.id_rol, 'activo', NEW.activo), 
                CURRENT_TIMESTAMP);
        RETURN NEW;
    END IF;
    
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.fn_auditoria_usuarios() OWNER TO postgres;

--
-- Name: insertarproyectoaleatorio(timestamp without time zone); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.insertarproyectoaleatorio(IN fecha_creada timestamp without time zone)
    LANGUAGE plpgsql
    AS $$
DECLARE
    nuevo_id INT;
    nivel_academico_aleatorio nivel_academico_enum;
    carrera_aleatoria INT;
    titulo_base VARCHAR(255);
    palabras_clave_gen TEXT;
    resumen_texto TEXT;
    mes_actual INT;
    
    -- Arrays para simular el ELT de MySQL
    arr_niveles1 VARCHAR[] := ARRAY['TSU', 'Pregrado', 'Especializacion', 'Maestria'];
    arr_niveles2 VARCHAR[] := ARRAY['Especializacion', 'Maestria', 'Doctorado'];
    arr_niveles3 VARCHAR[] := ARRAY['TSU', 'Pregrado', 'Especializacion', 'Maestria', 'Doctorado'];
    
    arr_tit_acc VARCHAR[] := ARRAY['Sistema', 'Aplicación', 'Plataforma', 'Prototipo', 'Análisis', 'Diseño', 'Implementación', 'Optimización', 'Automatización', 'Evaluación', 'Desarrollo', 'Modelo'];
    arr_tit_obj VARCHAR[] := ARRAY['Gestión', 'Monitoreo', 'Control', 'Predicción', 'Seguridad', 'Reconocimiento', 'Clasificación', 'Procesamiento', 'Visualización', 'Comunicación', 'Bajo Costo', 'Alto Rendimiento'];
    arr_tit_dest VARCHAR[] := ARRAY['la Comunidad', 'UPTTMBI', 'el Sector Agroalimentario', 'Zonas Rurales', 'Instituciones Educativas', 'Pequeñas Empresas', 'el Área de Salud', 'el Transporte Público', 'la Industria 4.0', 'la Transformación Digital'];
    
    arr_carreras VARCHAR[] := ARRAY['Informática', 'Electricidad', 'Administración', 'Agroalimentación', 'Construcción Civil'];
BEGIN
    mes_actual := EXTRACT(MONTH FROM fecha_creada);

    -- Asignar nivel académico
    IF mes_actual IN (4,8) THEN
        nivel_academico_aleatorio := arr_niveles1[floor(random() * 4 + 1)::int]::nivel_academico_enum;
    ELSIF mes_actual = 12 THEN
        nivel_academico_aleatorio := arr_niveles2[floor(random() * 3 + 1)::int]::nivel_academico_enum;
    ELSE
        nivel_academico_aleatorio := arr_niveles3[floor(random() * 5 + 1)::int]::nivel_academico_enum;
    END IF;

    -- Ajustar pesos específicos
    IF random() < 0.4 THEN 
        nivel_academico_aleatorio := 'Pregrado';
    ELSIF random() < 0.25 THEN 
        nivel_academico_aleatorio := 'TSU';
    END IF;

    -- Carrera aleatoria
    carrera_aleatoria := floor(random() * 5 + 1)::int;

    -- Título dinámico
    titulo_base := arr_tit_acc[floor(random() * 12 + 1)::int] || ' de ' || 
                   arr_tit_obj[floor(random() * 12 + 1)::int] || ' para ' || 
                   arr_tit_dest[floor(random() * 10 + 1)::int];

    -- Resumen
    resumen_texto := 'Proyecto desarrollado en ' || arr_carreras[carrera_aleatoria] || '. Aborda problemáticas reales con enfoque práctico.';

    -- Insertar recurso y capturar el ID generado (RETURNING id)
    INSERT INTO recursos (titulo, id_tipo_recurso, anio_publicacion, ejemplares_totales, ejemplares_disponibles)
    VALUES (titulo_base, 1, EXTRACT(YEAR FROM fecha_creada), 1, 1)
    RETURNING id INTO nuevo_id;

    -- Insertar detalle proyecto
    INSERT INTO detalles_proyectos (id_recurso, fecha_defensa, nivel_academico, resumen, id_carrera, comunidad_beneficiada, palabras_clave, created_at) 
    VALUES (nuevo_id, (fecha_creada + (floor(random() * 90)::int || ' days')::interval)::date, nivel_academico_aleatorio, resumen_texto, carrera_aleatoria, 'Comunidad Generica', 'tecnologia, innovacion', fecha_creada);

    -- Relacionar con un autor aleatorio o el autor por defecto 1
    INSERT INTO recurso_autores (id_recurso, id_autor)
    SELECT nuevo_id, id FROM autores WHERE id BETWEEN 14 AND 29 ORDER BY random() LIMIT 1;
    
    -- Si no insertó (por no hallar autor en ese rango), fuerza el autor 1
    IF NOT FOUND THEN
        INSERT INTO recurso_autores (id_recurso, id_autor) VALUES (nuevo_id, 1);
    END IF;
END;
$$;


ALTER PROCEDURE public.insertarproyectoaleatorio(IN fecha_creada timestamp without time zone) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accesos_recursos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accesos_recursos (
    id integer NOT NULL,
    id_registro_actividad integer NOT NULL,
    id_recurso integer NOT NULL,
    accion public.accion_acceso_enum DEFAULT 'visualizacion'::public.accion_acceso_enum,
    fecha_acceso timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.accesos_recursos OWNER TO postgres;

--
-- Name: accesos_recursos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accesos_recursos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.accesos_recursos_id_seq OWNER TO postgres;

--
-- Name: accesos_recursos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accesos_recursos_id_seq OWNED BY public.accesos_recursos.id;


--
-- Name: auditoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auditoria (
    id integer NOT NULL,
    tabla_afectada character varying(50) NOT NULL,
    id_registro integer NOT NULL,
    accion public.accion_auditoria_enum NOT NULL,
    usuario_responsable integer,
    ip_origen character varying(45),
    datos_anteriores jsonb,
    datos_nuevos jsonb,
    fecha_hora timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.auditoria OWNER TO postgres;

--
-- Name: auditoria_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auditoria_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.auditoria_id_seq OWNER TO postgres;

--
-- Name: auditoria_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auditoria_id_seq OWNED BY public.auditoria.id;


--
-- Name: autores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.autores (
    id integer NOT NULL,
    nombre_completo character varying(150) NOT NULL,
    cedula character varying(20)
);


ALTER TABLE public.autores OWNER TO postgres;

--
-- Name: autores_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.autores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.autores_id_seq OWNER TO postgres;

--
-- Name: autores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.autores_id_seq OWNED BY public.autores.id;


--
-- Name: carreras; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carreras (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion text
);


ALTER TABLE public.carreras OWNER TO postgres;

--
-- Name: carreras_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.carreras_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.carreras_id_seq OWNER TO postgres;

--
-- Name: carreras_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.carreras_id_seq OWNED BY public.carreras.id;


--
-- Name: categorias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categorias (
    id integer NOT NULL,
    nombre character varying(150) NOT NULL
);


ALTER TABLE public.categorias OWNER TO postgres;

--
-- Name: categorias_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categorias_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categorias_id_seq OWNER TO postgres;

--
-- Name: categorias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categorias_id_seq OWNED BY public.categorias.id;


--
-- Name: certificados; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.certificados (
    id integer NOT NULL,
    id_usuario integer NOT NULL,
    id_curso integer NOT NULL,
    id_respuesta integer NOT NULL,
    codigo_verificacion character varying(64) NOT NULL,
    fecha_emision timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    ruta_archivo character varying(255)
);


ALTER TABLE public.certificados OWNER TO postgres;

--
-- Name: certificados_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.certificados_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.certificados_id_seq OWNER TO postgres;

--
-- Name: certificados_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.certificados_id_seq OWNED BY public.certificados.id;


--
-- Name: comentarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comentarios (
    id integer NOT NULL,
    id_usuario integer NOT NULL,
    id_recurso integer NOT NULL,
    comentario text NOT NULL,
    fecha timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.comentarios OWNER TO postgres;

--
-- Name: comentarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.comentarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.comentarios_id_seq OWNER TO postgres;

--
-- Name: comentarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.comentarios_id_seq OWNED BY public.comentarios.id;


--
-- Name: cursos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cursos (
    id integer NOT NULL,
    id_docente integer NOT NULL,
    titulo character varying(255) NOT NULL,
    descripcion text,
    imagen_portada character varying(255),
    estado public.estado_curso_enum DEFAULT 'borrador'::public.estado_curso_enum NOT NULL,
    nota_minima_aprobacion numeric(5,2) DEFAULT 70.00 NOT NULL,
    fecha_creacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.cursos OWNER TO postgres;

--
-- Name: cursos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cursos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cursos_id_seq OWNER TO postgres;

--
-- Name: cursos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cursos_id_seq OWNED BY public.cursos.id;


--
-- Name: detalles_investigaciones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detalles_investigaciones (
    id_recurso integer NOT NULL,
    id_red_informacion integer,
    resumen text,
    fecha_publicacion date,
    palabras_clave text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.detalles_investigaciones OWNER TO postgres;

--
-- Name: detalles_proyectos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detalles_proyectos (
    id_recurso integer NOT NULL,
    fecha_defensa date,
    nivel_academico public.nivel_academico_enum DEFAULT 'Pregrado'::public.nivel_academico_enum,
    resumen text,
    id_carrera integer,
    comunidad_beneficiada text,
    palabras_clave text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    id_investigacion_padre integer
);


ALTER TABLE public.detalles_proyectos OWNER TO postgres;

--
-- Name: detalles_revistas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detalles_revistas (
    id_recurso integer NOT NULL,
    id_editorial integer,
    volumen character varying(50),
    numero character varying(50),
    issn character varying(20),
    id_categoria integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.detalles_revistas OWNER TO postgres;

--
-- Name: editoriales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.editoriales (
    id integer NOT NULL,
    nombre character varying(150) NOT NULL
);


ALTER TABLE public.editoriales OWNER TO postgres;

--
-- Name: editoriales_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.editoriales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.editoriales_id_seq OWNER TO postgres;

--
-- Name: editoriales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.editoriales_id_seq OWNED BY public.editoriales.id;


--
-- Name: evaluaciones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.evaluaciones (
    id integer NOT NULL,
    id_curso integer NOT NULL,
    titulo character varying(255) NOT NULL,
    descripcion text,
    tiempo_limite_minutos integer,
    intentos_permitidos integer DEFAULT 1 NOT NULL,
    fecha_creacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.evaluaciones OWNER TO postgres;

--
-- Name: evaluaciones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.evaluaciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.evaluaciones_id_seq OWNER TO postgres;

--
-- Name: evaluaciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.evaluaciones_id_seq OWNED BY public.evaluaciones.id;


--
-- Name: inscripciones_curso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inscripciones_curso (
    id integer NOT NULL,
    id_usuario integer NOT NULL,
    id_curso integer NOT NULL,
    fecha_inscripcion timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    progreso integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.inscripciones_curso OWNER TO postgres;

--
-- Name: inscripciones_curso_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inscripciones_curso_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inscripciones_curso_id_seq OWNER TO postgres;

--
-- Name: inscripciones_curso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inscripciones_curso_id_seq OWNED BY public.inscripciones_curso.id;


--
-- Name: interacciones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.interacciones (
    id integer NOT NULL,
    id_usuario integer NOT NULL,
    id_recurso integer NOT NULL,
    tipo_interaccion public.tipo_interaccion_enum DEFAULT 'like'::public.tipo_interaccion_enum,
    fecha timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.interacciones OWNER TO postgres;

--
-- Name: interacciones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.interacciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.interacciones_id_seq OWNER TO postgres;

--
-- Name: interacciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.interacciones_id_seq OWNED BY public.interacciones.id;


--
-- Name: interacciones_usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.interacciones_usuario (
    id integer NOT NULL,
    id_usuario integer NOT NULL,
    id_recurso integer NOT NULL,
    tipo public.tipo_interaccion_usuario_enum NOT NULL,
    fecha timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.interacciones_usuario OWNER TO postgres;

--
-- Name: interacciones_usuario_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.interacciones_usuario_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.interacciones_usuario_id_seq OWNER TO postgres;

--
-- Name: interacciones_usuario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.interacciones_usuario_id_seq OWNED BY public.interacciones_usuario.id;


--
-- Name: lecciones_curso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lecciones_curso (
    id integer NOT NULL,
    id_curso integer NOT NULL,
    titulo character varying(255) NOT NULL,
    contenido text,
    orden integer DEFAULT 1 NOT NULL,
    fecha_creacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    url_video character varying(255)
);


ALTER TABLE public.lecciones_curso OWNER TO postgres;

--
-- Name: lecciones_curso_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lecciones_curso_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lecciones_curso_id_seq OWNER TO postgres;

--
-- Name: lecciones_curso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lecciones_curso_id_seq OWNED BY public.lecciones_curso.id;


--
-- Name: lineas_investigacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lineas_investigacion (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    id_carrera integer NOT NULL
);


ALTER TABLE public.lineas_investigacion OWNER TO postgres;

--
-- Name: lineas_investigacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lineas_investigacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.lineas_investigacion_id_seq OWNER TO postgres;

--
-- Name: lineas_investigacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lineas_investigacion_id_seq OWNED BY public.lineas_investigacion.id;


--
-- Name: notificaciones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notificaciones (
    id integer NOT NULL,
    id_usuario integer,
    titulo character varying(255),
    mensaje text,
    leido boolean DEFAULT false,
    fecha_hora timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    fecha timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notificaciones OWNER TO postgres;

--
-- Name: notificaciones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.notificaciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notificaciones_id_seq OWNER TO postgres;

--
-- Name: notificaciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.notificaciones_id_seq OWNED BY public.notificaciones.id;


--
-- Name: preferencias_usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.preferencias_usuario (
    id_usuario integer NOT NULL,
    tema character varying(50) DEFAULT 'light'::character varying,
    notificaciones_sistema boolean DEFAULT true
);


ALTER TABLE public.preferencias_usuario OWNER TO postgres;

--
-- Name: preguntas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.preguntas (
    id integer NOT NULL,
    id_evaluacion integer NOT NULL,
    texto_pregunta text NOT NULL,
    tipo_pregunta public.tipo_pregunta_enum DEFAULT 'multiple'::public.tipo_pregunta_enum NOT NULL,
    opciones_json jsonb,
    respuesta_correcta text NOT NULL,
    orden integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.preguntas OWNER TO postgres;

--
-- Name: preguntas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.preguntas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.preguntas_id_seq OWNER TO postgres;

--
-- Name: preguntas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.preguntas_id_seq OWNED BY public.preguntas.id;


--
-- Name: privilegios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.privilegios (
    privilegio_id integer NOT NULL,
    nivel_privilegio integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.privilegios OWNER TO postgres;

--
-- Name: privilegios_privilegio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.privilegios_privilegio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.privilegios_privilegio_id_seq OWNER TO postgres;

--
-- Name: privilegios_privilegio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.privilegios_privilegio_id_seq OWNED BY public.privilegios.privilegio_id;


--
-- Name: proyecto_tutores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.proyecto_tutores (
    id_recurso integer NOT NULL,
    id_tutor integer NOT NULL,
    tipo_tutor_id integer
);


ALTER TABLE public.proyecto_tutores OWNER TO postgres;

--
-- Name: recurso_autores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurso_autores (
    id_recurso integer NOT NULL,
    id_autor integer NOT NULL
);


ALTER TABLE public.recurso_autores OWNER TO postgres;

--
-- Name: recurso_lineas_investigacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recurso_lineas_investigacion (
    id_recurso integer NOT NULL,
    id_linea_investigacion integer NOT NULL
);


ALTER TABLE public.recurso_lineas_investigacion OWNER TO postgres;

--
-- Name: recursos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recursos (
    id integer NOT NULL,
    titulo character varying(255) NOT NULL,
    id_tipo_recurso integer NOT NULL,
    anio_publicacion integer,
    ejemplares_totales integer DEFAULT 1,
    ejemplares_disponibles integer DEFAULT 1,
    archivo_pdf character varying(255)
);


ALTER TABLE public.recursos OWNER TO postgres;

--
-- Name: recursos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recursos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recursos_id_seq OWNER TO postgres;

--
-- Name: recursos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recursos_id_seq OWNED BY public.recursos.id;


--
-- Name: redes_informacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.redes_informacion (
    id integer NOT NULL,
    nombre character varying(150) NOT NULL,
    descripcion text
);


ALTER TABLE public.redes_informacion OWNER TO postgres;

--
-- Name: redes_informacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.redes_informacion_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.redes_informacion_id_seq OWNER TO postgres;

--
-- Name: redes_informacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.redes_informacion_id_seq OWNED BY public.redes_informacion.id;


--
-- Name: registro_actividad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.registro_actividad (
    id integer NOT NULL,
    id_usuario integer,
    id_visitante integer,
    fecha_inicial timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    ultima_actividad timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    conteo_accesos integer DEFAULT 1
);


ALTER TABLE public.registro_actividad OWNER TO postgres;

--
-- Name: registro_actividad_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.registro_actividad_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.registro_actividad_id_seq OWNER TO postgres;

--
-- Name: registro_actividad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.registro_actividad_id_seq OWNED BY public.registro_actividad.id;


--
-- Name: respuestas_estudiante; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.respuestas_estudiante (
    id integer NOT NULL,
    id_evaluacion integer NOT NULL,
    id_usuario integer NOT NULL,
    respuestas_json jsonb NOT NULL,
    calificacion numeric(5,2) DEFAULT 0.00 NOT NULL,
    aprobado boolean DEFAULT false NOT NULL,
    fecha_intento timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.respuestas_estudiante OWNER TO postgres;

--
-- Name: respuestas_estudiante_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.respuestas_estudiante_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.respuestas_estudiante_id_seq OWNER TO postgres;

--
-- Name: respuestas_estudiante_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.respuestas_estudiante_id_seq OWNED BY public.respuestas_estudiante.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    privilegio_id integer DEFAULT 1 CONSTRAINT roles_privilegios_id_not_null NOT NULL
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: suscripciones_redes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suscripciones_redes (
    id_usuario integer NOT NULL,
    id_red_informacion integer NOT NULL,
    fecha timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.suscripciones_redes OWNER TO postgres;

--
-- Name: tipo_recurso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_recurso (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    descripcion text
);


ALTER TABLE public.tipo_recurso OWNER TO postgres;

--
-- Name: tipo_recurso_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_recurso_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tipo_recurso_id_seq OWNER TO postgres;

--
-- Name: tipo_recurso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_recurso_id_seq OWNED BY public.tipo_recurso.id;


--
-- Name: tipo_tutor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipo_tutor (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    descripcion text
);


ALTER TABLE public.tipo_tutor OWNER TO postgres;

--
-- Name: tipo_tutor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tipo_tutor_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tipo_tutor_id_seq OWNER TO postgres;

--
-- Name: tipo_tutor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tipo_tutor_id_seq OWNED BY public.tipo_tutor.id;


--
-- Name: tutores; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tutores (
    id integer NOT NULL,
    nombre_completo character varying(150) NOT NULL,
    cedula character varying(20)
);


ALTER TABLE public.tutores OWNER TO postgres;

--
-- Name: tutores_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tutores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tutores_id_seq OWNER TO postgres;

--
-- Name: tutores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tutores_id_seq OWNED BY public.tutores.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    nombre_completo character varying(150) NOT NULL,
    email character varying(100),
    cedula character varying(20),
    contrasena character varying(255),
    id_rol integer,
    activo boolean DEFAULT true
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuarios_id_seq OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: visitantes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.visitantes (
    id integer NOT NULL,
    ip_address character varying(45) NOT NULL,
    user_agent text,
    pagina_origen character varying(255)
);


ALTER TABLE public.visitantes OWNER TO postgres;

--
-- Name: visitantes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.visitantes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.visitantes_id_seq OWNER TO postgres;

--
-- Name: visitantes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.visitantes_id_seq OWNED BY public.visitantes.id;


--
-- Name: accesos_recursos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesos_recursos ALTER COLUMN id SET DEFAULT nextval('public.accesos_recursos_id_seq'::regclass);


--
-- Name: auditoria id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auditoria ALTER COLUMN id SET DEFAULT nextval('public.auditoria_id_seq'::regclass);


--
-- Name: autores id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.autores ALTER COLUMN id SET DEFAULT nextval('public.autores_id_seq'::regclass);


--
-- Name: carreras id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carreras ALTER COLUMN id SET DEFAULT nextval('public.carreras_id_seq'::regclass);


--
-- Name: categorias id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias ALTER COLUMN id SET DEFAULT nextval('public.categorias_id_seq'::regclass);


--
-- Name: certificados id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificados ALTER COLUMN id SET DEFAULT nextval('public.certificados_id_seq'::regclass);


--
-- Name: comentarios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comentarios ALTER COLUMN id SET DEFAULT nextval('public.comentarios_id_seq'::regclass);


--
-- Name: cursos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cursos ALTER COLUMN id SET DEFAULT nextval('public.cursos_id_seq'::regclass);


--
-- Name: editoriales id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.editoriales ALTER COLUMN id SET DEFAULT nextval('public.editoriales_id_seq'::regclass);


--
-- Name: evaluaciones id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evaluaciones ALTER COLUMN id SET DEFAULT nextval('public.evaluaciones_id_seq'::regclass);


--
-- Name: inscripciones_curso id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscripciones_curso ALTER COLUMN id SET DEFAULT nextval('public.inscripciones_curso_id_seq'::regclass);


--
-- Name: interacciones id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interacciones ALTER COLUMN id SET DEFAULT nextval('public.interacciones_id_seq'::regclass);


--
-- Name: interacciones_usuario id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interacciones_usuario ALTER COLUMN id SET DEFAULT nextval('public.interacciones_usuario_id_seq'::regclass);


--
-- Name: lecciones_curso id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lecciones_curso ALTER COLUMN id SET DEFAULT nextval('public.lecciones_curso_id_seq'::regclass);


--
-- Name: lineas_investigacion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lineas_investigacion ALTER COLUMN id SET DEFAULT nextval('public.lineas_investigacion_id_seq'::regclass);


--
-- Name: notificaciones id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notificaciones ALTER COLUMN id SET DEFAULT nextval('public.notificaciones_id_seq'::regclass);


--
-- Name: preguntas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preguntas ALTER COLUMN id SET DEFAULT nextval('public.preguntas_id_seq'::regclass);


--
-- Name: privilegios privilegio_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.privilegios ALTER COLUMN privilegio_id SET DEFAULT nextval('public.privilegios_privilegio_id_seq'::regclass);


--
-- Name: recursos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recursos ALTER COLUMN id SET DEFAULT nextval('public.recursos_id_seq'::regclass);


--
-- Name: redes_informacion id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redes_informacion ALTER COLUMN id SET DEFAULT nextval('public.redes_informacion_id_seq'::regclass);


--
-- Name: registro_actividad id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registro_actividad ALTER COLUMN id SET DEFAULT nextval('public.registro_actividad_id_seq'::regclass);


--
-- Name: respuestas_estudiante id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.respuestas_estudiante ALTER COLUMN id SET DEFAULT nextval('public.respuestas_estudiante_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: tipo_recurso id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_recurso ALTER COLUMN id SET DEFAULT nextval('public.tipo_recurso_id_seq'::regclass);


--
-- Name: tipo_tutor id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_tutor ALTER COLUMN id SET DEFAULT nextval('public.tipo_tutor_id_seq'::regclass);


--
-- Name: tutores id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tutores ALTER COLUMN id SET DEFAULT nextval('public.tutores_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Name: visitantes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visitantes ALTER COLUMN id SET DEFAULT nextval('public.visitantes_id_seq'::regclass);


--
-- Data for Name: accesos_recursos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accesos_recursos (id, id_registro_actividad, id_recurso, accion, fecha_acceso) FROM stdin;
\.


--
-- Data for Name: auditoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auditoria (id, tabla_afectada, id_registro, accion, usuario_responsable, ip_origen, datos_anteriores, datos_nuevos, fecha_hora) FROM stdin;
1	usuarios	1	INSERT	\N	\N	\N	{"email": "andru@gmail.com", "id_rol": 1, "nombre": "Adrus"}	2026-03-23 14:09:42
2	usuarios	2	INSERT	\N	\N	\N	{"email": "lando@gmail.com", "id_rol": 2, "nombre": "lando"}	2026-03-23 14:09:42
3	usuarios	3	INSERT	\N	\N	\N	{"email": "miki@gmail.com", "id_rol": 3, "nombre": "miki"}	2026-03-23 14:09:42
4	usuarios	4	INSERT	\N	\N	\N	{"email": "ale@yaju.com", "id_rol": 3, "nombre": "ale"}	2026-03-23 14:09:42
5	recursos	1	INSERT	\N	\N	\N	{"titulo": "Sistema de Reconocimiento Biométrico Facial para Comedor Universitario", "id_tipo_recurso": 1, "ejemplares_totales": 1}	2026-03-23 14:09:42
6	recursos	2	INSERT	\N	\N	\N	{"titulo": "Prototipo de Cerradura Digital con Matriz de Teclado y Arduino", "id_tipo_recurso": 1, "ejemplares_totales": 1}	2026-03-23 14:09:42
7	recursos	3	INSERT	\N	\N	\N	{"titulo": "Aplicación de Redes Neuronales Convolucionales para la Detección de Plagas en Cultivos Trujillanos", "id_tipo_recurso": 2, "ejemplares_totales": 1}	2026-03-23 14:09:42
8	usuarios	4	UPDATE	1	\N	{"activo": 1, "id_rol": 3, "nombre": "ale"}	{"activo": 1, "id_rol": 1, "nombre": "ale"}	2026-03-23 16:14:24
9	recursos	4	INSERT	\N	\N	\N	{"titulo": "Impacto del Cambio Climático en Trujillo - Parte 8", "id_tipo_recurso": 2, "ejemplares_totales": 1}	2026-03-23 16:56:13
10	recursos	5	INSERT	\N	\N	\N	{"titulo": "Simulación de Cargas Estáticas en Puentes - Parte 7", "id_tipo_recurso": 2, "ejemplares_totales": 1}	2026-03-23 16:57:08
11	recursos	6	INSERT	\N	\N	\N	{"titulo": "Big Data en Finanzas Institucionales - Parte 9", "id_tipo_recurso": 1, "ejemplares_totales": 1}	2026-03-23 16:58:11
12	recursos	7	INSERT	\N	\N	\N	{"titulo": "Optimización de CPU en Servidores Locales - Parte 7", "id_tipo_recurso": 1, "ejemplares_totales": 1}	2026-03-23 16:58:11
13	recursos	8	INSERT	\N	\N	\N	{"titulo": "Sistemas de Riego Automatizado - Parte 5", "id_tipo_recurso": 1, "ejemplares_totales": 1}	2026-03-23 16:58:11
14	usuarios	6	UPDATE	\N	\N	{"activo": true, "id_rol": 3, "nombre": "piña"}	{"activo": true, "id_rol": 3, "nombre": "piña"}	2026-06-18 18:46:17.662484
15	usuarios	6	UPDATE	\N	\N	{"activo": true, "id_rol": 3, "nombre": "piña"}	{"activo": true, "id_rol": 3, "nombre": "piña"}	2026-06-18 19:05:42.587427
16	usuarios	6	UPDATE	\N	\N	{"activo": true, "id_rol": 3, "nombre": "piña"}	{"activo": true, "id_rol": 3, "nombre": "piña"}	2026-06-18 19:54:46.993547
17	usuarios	7	INSERT	\N	\N	\N	{"email": "erwazaaaa@gmail.com", "id_rol": 3, "nombre": "Migel González"}	2026-06-18 20:58:57.768568
18	usuarios	8	INSERT	\N	\N	\N	{"email": "yisu@gmail.com", "id_rol": 3, "nombre": "Yisu Monte"}	2026-06-18 20:59:49.682537
19	usuarios	7	UPDATE	\N	\N	{"activo": true, "id_rol": 3, "nombre": "Migel González"}	{"activo": true, "id_rol": 1, "nombre": "Migel González"}	2026-06-18 21:38:28.663879
20	usuarios	9	INSERT	\N	\N	\N	{"email": "iaiaia@gmail.com", "id_rol": 3, "nombre": "Pedro Perez"}	2026-06-24 23:07:53.05286
21	usuarios	6	UPDATE	\N	\N	{"activo": true, "id_rol": 3, "nombre": "piña"}	{"activo": true, "id_rol": 3, "nombre": "Piñin"}	2026-06-24 23:57:15.201582
22	usuarios	6	UPDATE	\N	\N	{"activo": true, "id_rol": 3, "nombre": "Piñin"}	{"activo": true, "id_rol": 4, "nombre": "Piñin"}	2026-06-24 23:57:20.104368
23	usuarios	6	UPDATE	\N	\N	{"activo": true, "id_rol": 4, "nombre": "Piñin"}	{"activo": true, "id_rol": 2, "nombre": "Piñin"}	2026-06-24 23:57:31.726744
24	usuarios	6	UPDATE	\N	\N	{"activo": true, "id_rol": 2, "nombre": "Piñin"}	{"activo": true, "id_rol": 4, "nombre": "Piñin"}	2026-06-24 23:57:37.330082
25	usuarios	6	UPDATE	\N	\N	{"activo": true, "id_rol": 4, "nombre": "Piñin"}	{"activo": true, "id_rol": 4, "nombre": "Piñin"}	2026-06-25 00:01:40.353031
26	usuarios	6	UPDATE	\N	\N	{"activo": true, "id_rol": 4, "nombre": "Piñin"}	{"activo": true, "id_rol": 4, "nombre": "Piñin"}	2026-06-25 00:01:46.873155
27	usuarios	6	UPDATE	\N	\N	{"activo": true, "id_rol": 4, "nombre": "Piñin"}	{"activo": true, "id_rol": 4, "nombre": "Piñin Piña"}	2026-06-25 00:01:55.730238
28	usuarios	6	UPDATE	\N	\N	{"activo": true, "id_rol": 4, "nombre": "Piñin Piña"}	{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}	2026-06-25 00:23:15.783421
29	usuarios	10	INSERT	\N	\N	\N	{"email": "wazaaa@gmail.com", "id_rol": 3, "nombre": "Wazaaaa"}	2026-06-25 00:33:07.592137
30	usuarios	11	INSERT	\N	\N	\N	{"email": "123@gmail.com", "id_rol": 3, "nombre": "Juan"}	2026-06-25 00:33:28.49575
31	usuarios	6	UPDATE	\N	\N	{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}	{"activo": true, "id_rol": 4, "nombre": "Piñin Piña"}	2026-06-25 00:34:43.439159
32	usuarios	6	UPDATE	\N	\N	{"activo": true, "id_rol": 4, "nombre": "Piñin Piña"}	{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}	2026-06-25 00:34:45.543113
33	usuarios	10	UPDATE	\N	\N	{"activo": true, "id_rol": 3, "nombre": "Wazaaaa"}	{"activo": false, "id_rol": 3, "nombre": "Wazaaaa"}	2026-06-25 00:34:51.608311
34	usuarios	10	UPDATE	\N	\N	{"activo": false, "id_rol": 3, "nombre": "Wazaaaa"}	{"activo": true, "id_rol": 3, "nombre": "Wazaaaa"}	2026-06-25 00:35:18.586051
35	usuarios	6	UPDATE	\N	\N	{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}	{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}	2026-06-25 00:57:51.974985
36	usuarios	6	UPDATE	\N	\N	{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}	{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}	2026-06-25 00:57:57.479012
37	usuarios	6	UPDATE	\N	\N	{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}	{"activo": true, "id_rol": 4, "nombre": "Piñin Piña"}	2026-06-25 00:58:00.692516
38	usuarios	6	UPDATE	\N	\N	{"activo": true, "id_rol": 4, "nombre": "Piñin Piña"}	{"activo": true, "id_rol": 4, "nombre": "Piñin Piña"}	2026-06-25 00:58:05.014824
39	usuarios	10	UPDATE	\N	\N	{"activo": true, "id_rol": 3, "nombre": "Wazaaaa"}	{"activo": true, "id_rol": 1, "nombre": "Wazaaaa"}	2026-06-25 00:58:32.420893
40	usuarios	7	UPDATE	\N	\N	{"activo": true, "id_rol": 1, "nombre": "Migel González"}	{"activo": true, "id_rol": 1, "nombre": "Miguel González"}	2026-06-25 01:22:04.451131
41	usuarios	6	UPDATE	\N	\N	{"activo": true, "id_rol": 4, "nombre": "Piñin Piña"}	{"activo": false, "id_rol": 4, "nombre": "Piñin Piña"}	2026-06-29 11:45:47.198869
42	usuarios	10	UPDATE	\N	\N	{"activo": true, "id_rol": 1, "nombre": "Wazaaaa"}	{"activo": true, "id_rol": 3, "nombre": "Wazaaaa"}	2026-06-29 12:10:37.626132
43	usuarios	10	UPDATE	\N	\N	{"activo": true, "id_rol": 3, "nombre": "Wazaaaa"}	{"activo": true, "id_rol": 1, "nombre": "Wazaaaa"}	2026-06-29 14:18:17.58523
44	usuarios	10	UPDATE	\N	\N	{"activo": true, "id_rol": 1, "nombre": "Wazaaaa"}	{"activo": true, "id_rol": 4, "nombre": "Wazaaaa"}	2026-06-29 14:18:34.834966
45	usuarios	10	UPDATE	\N	\N	{"activo": true, "id_rol": 4, "nombre": "Wazaaaa"}	{"activo": true, "id_rol": 4, "nombre": "Wazaaaa"}	2026-06-29 14:19:05.388306
\.


--
-- Data for Name: autores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.autores (id, nombre_completo, cedula) FROM stdin;
1	Prof. Andrus	V-11223344
2	Estudiante Dev	V-27000111
3	Estudiante Electrónica	V-28000222
4	Juan Pérez	\N
5	María García	\N
6	Ing. Pedro Díaz	\N
7	Carlos López	\N
8	Ana Martínez	\N
9	Dra. Sofía Rojas	\N
13	ale	
14	Dr. Ramón Fuentes	V-10111213
15	Dra. Clara Vásquez	V-10222333
16	Ing. Luis Morelo	V-10333444
17	Prof. Yolanda Díaz	V-10444555
18	Ing. Pedro Ríos	V-10555666
19	Prof. Ana Suárez	V-10666777
20	Ángel Ferrer	V-27100001
21	Mariela Colón	V-27100002
22	Javier Navas	V-27100003
23	Luisa Paredes	V-27100004
24	Tomás Guerrero	V-27100005
25	Valentina Soto	V-27100006
26	Rodrigo Méndez	V-27100007
27	Gabriela López	V-27100008
28	Hernán Castro	V-27100009
29	Isabel Ramos	V-27100010
\.


--
-- Data for Name: carreras; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.carreras (id, nombre, descripcion) FROM stdin;
1	PNF en Informática	Ingeniería y TSU en Informática
2	PNF en Electricidad	Ingeniería y TSU en Electricidad
3	PNF en Administración	Licenciatura y TSU en Administración
4	PNF en Agroalimentación	Ingeniería y TSU Agroalimentario
5	PNF en Construcción Civil	Ingeniería y TSU en Construcción Civil
\.


--
-- Data for Name: categorias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categorias (id, nombre) FROM stdin;
1	Tecnología
2	Ciencia
3	Ingeniería
4	Sociales
5	Innovación
6	Ciencias Sociales
7	Salud y Biociencias
8	Agronomía
\.


--
-- Data for Name: certificados; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.certificados (id, id_usuario, id_curso, id_respuesta, codigo_verificacion, fecha_emision, ruta_archivo) FROM stdin;
1	3	3	13	493B61507FB31AD91F02247A8533261E	2026-04-03 04:37:17	uploads/certificados/certificado_493B61507FB31AD91F02247A8533261E.pdf
2	6	4	14	D25645ED7DF769DCF60AEE0C378462F3	2026-04-03 04:42:44	uploads/certificados/certificado_D25645ED7DF769DCF60AEE0C378462F3.pdf
3	3	4	18	31FE943124ADEA4BBFF6307FF7F96FF8	2026-04-03 05:13:54	\N
4	5	4	21	3F0D64616E7A1E118FBE9716C2D551F1	2026-04-04 16:14:16	\N
5	5	3	24	29C6F0A6CEA67C2D17290E5001A10B43	2026-04-04 16:18:25	\N
6	6	3	25	2C9CDC646BF7A3B9892E76D1755D4405	2026-04-04 16:21:40	\N
\.


--
-- Data for Name: comentarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comentarios (id, id_usuario, id_recurso, comentario, fecha) FROM stdin;
\.


--
-- Data for Name: cursos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cursos (id, id_docente, titulo, descripcion, imagen_portada, estado, nota_minima_aprobacion, fecha_creacion, fecha_actualizacion) FROM stdin;
1	4	Introducción a la Metodología de la Investigación	Curso fundamental para comprender los métodos y técnicas de investigación científica aplicados al PNF en Informática. Incluye diseño experimental, recolección de datos y análisis estadístico básico.	\N	publicado	70.00	2026-04-03 03:28:04	2026-04-03 03:28:04
2	4	Fundamentos de Inteligencia Artificial	Curso introductorio sobre los conceptos básicos de la IA, redes neuronales, aprendizaje automático y sus aplicaciones en el contexto venezolano.	\N	publicado	70.00	2026-04-03 03:28:04	2026-04-03 03:28:04
3	1	Normas APA y Redacción Científica	Aprende a redactar documentos académicos siguiendo las normas APA 7ma edición. Ideal para la elaboración de tu Proyecto Socio-Tecnológico.	\N	publicado	60.00	2026-04-03 03:28:04	2026-04-03 03:53:35
4	1	tamaños de jose	los pn que jose ha tenido segun tamaño	\N	publicado	70.00	2026-04-03 04:40:03	2026-04-03 04:40:03
\.


--
-- Data for Name: detalles_investigaciones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detalles_investigaciones (id_recurso, id_red_informacion, resumen, fecha_publicacion, palabras_clave, created_at) FROM stdin;
3	1	Estudio sobre la implementación de arquitecturas de IA para el apoyo del sector agroalimentario.	2026-02-15	Redes Neuronales, IA, Agroalimentación	2026-03-23 14:09:42
\.


--
-- Data for Name: detalles_proyectos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detalles_proyectos (id_recurso, fecha_defensa, nivel_academico, resumen, id_carrera, comunidad_beneficiada, palabras_clave, created_at, id_investigacion_padre) FROM stdin;
\.


--
-- Data for Name: detalles_revistas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detalles_revistas (id_recurso, id_editorial, volumen, numero, issn, id_categoria, created_at) FROM stdin;
\.


--
-- Data for Name: editoriales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.editoriales (id, nombre) FROM stdin;
1	IEEE
2	ACM
3	Springer
4	Elsevier
5	UPTTMBI Ediciones
6	UNESCO
7	SciELO Venezuela
\.


--
-- Data for Name: evaluaciones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.evaluaciones (id, id_curso, titulo, descripcion, tiempo_limite_minutos, intentos_permitidos, fecha_creacion) FROM stdin;
1	1	Evaluación: Fundamentos de Investigación	Evalúa tus conocimientos sobre los tipos de investigación y el método científico.	30	2	2026-04-03 03:28:04
2	2	Evaluación: Conceptos Básicos de IA	Verifica tu comprensión de los fundamentos de la Inteligencia Artificial.	20	1	2026-04-03 03:28:04
3	3	evaluacion de admin	uwu	5	10	2026-04-03 03:52:18
4	3	pene final	jayu	6	4	2026-04-03 04:24:29
5	4	lo sabido	XD	5	5	2026-04-03 04:41:45
6	4	asdasd	asdasd	1	2	2026-04-03 04:43:56
\.


--
-- Data for Name: inscripciones_curso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inscripciones_curso (id, id_usuario, id_curso, fecha_inscripcion, progreso) FROM stdin;
1	3	1	2026-04-03 03:28:05	50
2	3	2	2026-04-03 03:55:36	0
3	3	3	2026-04-03 04:21:39	100
4	6	4	2026-04-03 04:42:14	100
5	3	4	2026-04-03 05:12:01	100
6	5	4	2026-04-04 16:14:16	100
7	5	3	2026-04-04 16:18:11	100
8	6	3	2026-04-04 16:21:34	100
\.


--
-- Data for Name: interacciones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.interacciones (id, id_usuario, id_recurso, tipo_interaccion, fecha) FROM stdin;
\.


--
-- Data for Name: interacciones_usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.interacciones_usuario (id, id_usuario, id_recurso, tipo, fecha) FROM stdin;
4	3	1	guardado	2026-03-23 16:45:30
\.


--
-- Data for Name: lecciones_curso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lecciones_curso (id, id_curso, titulo, contenido, orden, fecha_creacion, url_video) FROM stdin;
1	1	¿Qué es la Investigación Científica?	<h3>Definición</h3><p>La investigación científica es un proceso sistemático, organizado y objetivo destinado a responder a una pregunta o hipótesis. Se distingue por seguir un método riguroso que permite obtener resultados válidos y confiables.</p><h3>Características</h3><ul><li><strong>Sistemática:</strong> Sigue una serie de pasos ordenados.</li><li><strong>Empírica:</strong> Se basa en la observación y experimentación.</li><li><strong>Crítica:</strong> Somete los resultados a juicio y revisión.</li></ul><p>En el contexto del PNF en Informática, la investigación nos permite desarrollar soluciones tecnológicas innovadoras para las comunidades.</p>	1	2026-04-03 03:28:04	\N
2	1	Tipos de Investigación	<h3>Clasificación según el nivel de profundidad</h3><p><strong>Exploratoria:</strong> Se realiza cuando el tema es poco conocido. Busca familiarizarnos con el fenómeno.</p><p><strong>Descriptiva:</strong> Describe las características de un fenómeno. Responde al "qué", "cuándo", "dónde".</p><p><strong>Explicativa:</strong> Busca las causas de un fenómeno. Responde al "por qué".</p><h3>Según el diseño</h3><ul><li>Investigación de campo</li><li>Investigación documental</li><li>Investigación experimental</li></ul>	2	2026-04-03 03:28:04	\N
3	1	El Método Científico	<h3>Pasos del Método Científico</h3><ol><li><strong>Observación:</strong> Identificar un problema o fenómeno.</li><li><strong>Formulación de hipótesis:</strong> Proponer una explicación tentativa.</li><li><strong>Experimentación:</strong> Diseñar y ejecutar pruebas.</li><li><strong>Análisis de resultados:</strong> Interpretar los datos obtenidos.</li><li><strong>Conclusiones:</strong> Aceptar o rechazar la hipótesis.</li></ol><p>Este método es la base de todo Proyecto Socio-Tecnológico en la UPTTMBI.</p>	3	2026-04-03 03:28:04	\N
4	2	¿Qué es la Inteligencia Artificial?	<h3>Definición</h3><p>La Inteligencia Artificial (IA) es la simulación de procesos de inteligencia humana por parte de sistemas computacionales. Estos procesos incluyen el aprendizaje, el razonamiento y la autocorrección.</p><h3>Breve Historia</h3><p>Desde Alan Turing en 1950 hasta los modelos de lenguaje actuales, la IA ha evolucionado dramáticamente. Hoy en día, la IA está presente en asistentes virtuales, diagnóstico médico, conducción autónoma y más.</p>	1	2026-04-03 03:28:04	\N
5	2	Aprendizaje Automático (Machine Learning)	<h3>Tipos de Aprendizaje</h3><ul><li><strong>Supervisado:</strong> El modelo aprende de datos etiquetados (clasificación, regresión).</li><li><strong>No supervisado:</strong> El modelo encuentra patrones en datos sin etiquetar (clustering).</li><li><strong>Por refuerzo:</strong> El modelo aprende mediante recompensas y penalizaciones.</li></ul><p>Python es el lenguaje más utilizado para implementar estos algoritmos, con librerías como scikit-learn, TensorFlow y PyTorch.</p>	2	2026-04-03 03:28:04	\N
6	3	pene	penes	1	2026-04-03 04:22:53	\N
7	4	tamaño	uy zona	1	2026-04-03 04:40:19	\N
8	4	grosor	XD	2	2026-04-03 04:40:28	\N
9	4	jiji	si	3	2026-04-03 05:15:27	https://www.youtube.com/watch?v=rVJglZclD8g&list=RDrVJglZclD8g&start_radio=1
\.


--
-- Data for Name: lineas_investigacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lineas_investigacion (id, nombre, id_carrera) FROM stdin;
\.


--
-- Data for Name: notificaciones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notificaciones (id, id_usuario, titulo, mensaje, leido, fecha_hora, fecha) FROM stdin;
1	4	Actualización Moderada de Cuenta	Su perfil fue ajustado por un administrador. Nuevo rol ID: 1. El estado de la cuenta es: completamente Activa.	t	2026-03-23 16:14:24	2026-03-23 20:40:28
2	4	Actualización Moderada de Cuenta	Su perfil fue ajustado por un administrador. Nuevo rol ID: 4. El estado de la cuenta es: completamente Activa.	t	2026-03-23 20:10:36	2026-03-23 20:40:28
3	5	Actualización Moderada de Cuenta	Su perfil fue ajustado por un administrador. Nuevo rol ID: 1. El estado de la cuenta es: completamente Activa.	t	2026-03-23 21:42:42	2026-03-23 21:42:42
4	4	Actualización Moderada de Cuenta	Su perfil fue ajustado por un administrador. Nuevo rol ID: 3. El estado de la cuenta es: Suspendida por completo.	t	2026-04-02 02:13:17	2026-04-02 02:13:17
5	4	Actualización Moderada de Cuenta	Su perfil fue ajustado por un administrador. Nuevo rol ID: 3. El estado de la cuenta es: completamente Activa.	t	2026-04-02 02:13:22	2026-04-02 02:13:22
6	5	Actualización Moderada de Cuenta	Su perfil fue ajustado por un administrador. Nuevo rol ID: 3. El estado de la cuenta es: completamente Activa.	t	2026-04-04 16:13:51	2026-04-04 16:13:51
\.


--
-- Data for Name: preferencias_usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.preferencias_usuario (id_usuario, tema, notificaciones_sistema) FROM stdin;
1	ocean	t
3	sunset	t
4	ocean	t
6	sunset	t
\.


--
-- Data for Name: preguntas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.preguntas (id, id_evaluacion, texto_pregunta, tipo_pregunta, opciones_json, respuesta_correcta, orden) FROM stdin;
1	1	¿Cuál es la característica principal de la investigación científica?	multiple	\N	b	1
2	1	¿Qué tipo de investigación busca las causas de un fenómeno?	multiple	\N	c	2
3	1	¿Cuál es el primer paso del método científico?	multiple	\N	c	3
4	1	¿Qué responde la investigación descriptiva?	multiple	\N	b	4
5	1	¿Cuál es el último paso del método científico?	multiple	\N	c	5
6	2	¿Qué es la Inteligencia Artificial?	multiple	\N	b	1
7	2	¿Qué tipo de aprendizaje utiliza datos etiquetados?	multiple	\N	c	2
8	2	¿Quién propuso el concepto base de la IA en 1950?	multiple	\N	b	3
9	2	¿Cuál de las siguientes es una librería de Python para Machine Learning?	multiple	\N	c	4
10	2	¿El clustering es un ejemplo de qué tipo de aprendizaje?	multiple	\N	b	5
11	3	piña gei	multiple	\N	a	1
12	3	orlando gei	multiple	\N	b	2
13	4	land x cheo	v_f	{"f": "Falso", "v": "Verdadero"}	v	1
14	4	cheo gei	multiple	{"a": "si", "b": "no"}	a	2
15	5	que tamaño la tiene jose	multiple	{"a": "13", "b": "14", "c": "16"}	a	1
16	5	vaina del coso	corta	\N	si existe	2
17	6	a	multiple	{"a": "a", "b": "b"}	a	1
\.


--
-- Data for Name: privilegios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.privilegios (privilegio_id, nivel_privilegio) FROM stdin;
1	0
2	1
3	2
4	3
5	4
6	5
\.


--
-- Data for Name: proyecto_tutores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.proyecto_tutores (id_recurso, id_tutor, tipo_tutor_id) FROM stdin;
\.


--
-- Data for Name: recurso_autores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recurso_autores (id_recurso, id_autor) FROM stdin;
3	1
\.


--
-- Data for Name: recurso_lineas_investigacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recurso_lineas_investigacion (id_recurso, id_linea_investigacion) FROM stdin;
\.


--
-- Data for Name: recursos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recursos (id, titulo, id_tipo_recurso, anio_publicacion, ejemplares_totales, ejemplares_disponibles, archivo_pdf) FROM stdin;
1	Sistema de Reconocimiento Biométrico Facial para Comedor Universitario	1	2026	1	1	\N
2	Prototipo de Cerradura Digital con Matriz de Teclado y Arduino	1	2025	1	1	\N
3	Aplicación de Redes Neuronales Convolucionales para la Detección de Plagas en Cultivos Trujillanos	2	2026	1	1	\N
4	Impacto del Cambio Climático en Trujillo - Parte 8	2	2023	1	1	dummy.pdf
5	Simulación de Cargas Estáticas en Puentes - Parte 7	2	2024	1	1	dummy.pdf
6	Big Data en Finanzas Institucionales - Parte 9	1	2024	1	1	dummy.pdf
7	Optimización de CPU en Servidores Locales - Parte 7	1	2026	1	1	dummy.pdf
8	Sistemas de Riego Automatizado - Parte 5	1	2023	1	1	dummy.pdf
9	Bioinformática y Análisis de ADN - Parte 5	3	2025	1	1	dummy.pdf
10	Inteligencia Artificial en Diagnóstico Médico - Parte 6	2	2025	1	1	dummy.pdf
11	Robótica Educativa para Escuelas - Parte 5	3	2023	1	1	dummy.pdf
12	Software Libre para Bibliotecas - Parte 1	3	2026	1	1	dummy.pdf
13	E-Learning para Zonas Desfavorecidas - Parte 1	3	2018	1	1	dummy.pdf
14	Telecomunicaciones de Fibra Óptica Rural - Parte 1	2	2022	1	1	dummy.pdf
15	Criptografía Cuántica Post-RSA - Parte 2	1	2024	1	1	dummy.pdf
16	Criptografía Cuántica Post-RSA - Parte 7	3	2026	1	1	dummy.pdf
17	Criptografía Cuántica Post-RSA - Parte 5	1	2024	1	1	dummy.pdf
18	Criptografía Cuántica Post-RSA - Parte 8	1	2021	1	1	dummy.pdf
19	Software Libre para Bibliotecas - Parte 6	1	2023	1	1	dummy.pdf
20	Inteligencia Artificial en Diagnóstico Médico - Parte 1	3	2020	1	1	dummy.pdf
\.


--
-- Data for Name: redes_informacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.redes_informacion (id, nombre, descripcion) FROM stdin;
1	Redes Neuronales e Inteligencia Artificial	Investigaciones en deep learning, machine learning y visión artificial.
2	Ingeniería de Software y Arquitecturas	Metodologías ágiles, patrones de diseño y sistemas de información.
3	Sistemas Embebidos y Control	Desarrollo de hardware, microcontroladores y automatización.
\.


--
-- Data for Name: registro_actividad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.registro_actividad (id, id_usuario, id_visitante, fecha_inicial, ultima_actividad, conteo_accesos) FROM stdin;
1	1	\N	2026-03-23 14:49:58	2026-03-23 14:49:58	1
\.


--
-- Data for Name: respuestas_estudiante; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.respuestas_estudiante (id, id_evaluacion, id_usuario, respuestas_json, calificacion, aprobado, fecha_intento) FROM stdin;
1	1	3	{"1": "a", "2": "d", "3": "a", "4": "b", "5": "a"}	20.00	f	2026-04-03 03:30:18
2	1	3	{"1": "b", "2": "b", "3": "b", "4": "a", "5": "a"}	20.00	f	2026-04-03 03:33:18
3	2	3	{"estado": "en_progreso"}	0.00	f	2026-04-03 03:55:40
4	3	3	{"estado": "en_progreso"}	0.00	f	2026-04-03 04:21:43
5	3	3	{"estado": "en_progreso"}	0.00	f	2026-04-03 04:24:59
6	3	3	{"estado": "en_progreso"}	0.00	f	2026-04-03 04:25:10
7	3	3	{"estado": "en_progreso"}	0.00	f	2026-04-03 04:27:09
8	4	3	{"13": "f", "14": "a"}	50.00	f	2026-04-03 04:27:19
9	3	3	{"estado": "en_progreso"}	0.00	f	2026-04-03 04:27:52
10	4	3	{"estado": "en_progreso"}	0.00	f	2026-04-03 04:28:05
11	4	3	{"estado": "en_progreso"}	0.00	f	2026-04-03 04:28:19
12	3	3	{"estado": "en_progreso"}	0.00	f	2026-04-03 04:28:33
13	4	3	{"13": "v", "14": "a"}	100.00	t	2026-04-03 04:37:10
14	5	6	{"15": "a", "16": "si existe"}	100.00	t	2026-04-03 04:42:30
15	6	6	{"17": "a"}	100.00	t	2026-04-03 04:44:18
16	6	6	{"estado": "en_progreso"}	0.00	f	2026-04-03 04:45:59
17	6	3	{"estado": "en_progreso"}	0.00	f	2026-04-03 05:12:04
18	5	3	{"15": "a", "16": "si existe"}	100.00	t	2026-04-03 05:13:34
19	6	3	{"17": "b"}	0.00	f	2026-04-04 16:09:16
20	5	5	{"15": "c", "16": "si existe"}	50.00	f	2026-04-04 16:14:17
21	5	5	{"15": "a", "16": "si existe"}	100.00	t	2026-04-04 16:15:04
22	6	5	{"17": "a"}	100.00	t	2026-04-04 16:17:40
23	3	5	{"estado": "en_progreso"}	0.00	f	2026-04-04 16:18:15
24	4	5	{"13": "v", "14": "a"}	100.00	t	2026-04-04 16:18:20
25	4	6	{"13": "v", "14": "a"}	100.00	t	2026-04-04 16:21:36
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, nombre, privilegio_id) FROM stdin;
3	Estudiante	1
1	Super Administrador	4
2	Bibliotecario	3
4	Profesor	2
\.


--
-- Data for Name: suscripciones_redes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suscripciones_redes (id_usuario, id_red_informacion, fecha) FROM stdin;
\.


--
-- Data for Name: tipo_recurso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_recurso (id, nombre, descripcion) FROM stdin;
1	PST / Trabajo de Grado	Proyectos Socio-Tecnológicos y Tesis
2	Investigación Docente	Papers y artículos de investigación del personal académico
3	Material de Apoyo / Didáctico	Recursos adicionales para estudiantes
4	Revistas / Publicaciones Periódicas	Revistas científicas y académicas
\.


--
-- Data for Name: tipo_tutor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipo_tutor (id, nombre, descripcion) FROM stdin;
1	Director	Director principal del proyecto
2	Coordinador	Asesor metodológico
3	Tutor Académico	Especialista en el área
4	Tutor Comunitario	Representante de la comunidad
\.


--
-- Data for Name: tutores; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tutores (id, nombre_completo, cedula) FROM stdin;
1	Lando	V-12345678
2	Mikeyisito	V-18765432
3	María Antonieta Pérez	V-15444333
\.


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (id, nombre_completo, email, cedula, contrasena, id_rol, activo) FROM stdin;
1	Adrus	andru@gmail.com	11111111	$2y$10$o0Uk8V6gzXNSW/EZBWvd1OoC7O6UzrU3LRbDMIqxYDou2KJGRXdUa	1	t
2	lando	lando@gmail.com	22222222	$2y$10$o0Uk8V6gzXNSW/EZBWvd1OoC7O6UzrU3LRbDMIqxYDou2KJGRXdUa	2	t
3	miki	miki@gmail.com	33333333	$2y$10$o0Uk8V6gzXNSW/EZBWvd1OoC7O6UzrU3LRbDMIqxYDou2KJGRXdUa	3	t
4	ale	ale@yaju.com	44444444	$2y$10$o0Uk8V6gzXNSW/EZBWvd1OoC7O6UzrU3LRbDMIqxYDou2KJGRXdUa	3	t
5	bibi	bibi@gmail.com	4444111	\N	3	t
8	Yisu Monte	yisu@gmail.com	30866991	$2y$10$jOukhIGIbdJCmpHdS.MqWusufmhQgHf.O9UByeqN.NFue38kT47xa	3	t
9	Pedro Perez	iaiaia@gmail.com	4123123	$2y$10$xOgs5kJnv17wwzjNtnNUguWc7pxdYv.lMZGFejPOz7fIgLNEybLgC	3	t
11	Juan	123@gmail.com	1234	$2y$10$HBPGRak0eIYzElwfC.bGuOvgFOfK.GbG40ct2e7X9CS7OgMARJRcC	3	t
7	Miguel González	erwazaaaa@gmail.com	32621284	$2y$10$tqm17pwan91BnMUfmCAB/O01faShLfeK3jo0jYVwpQcBpGr5iLiE.	1	t
6	Piñin Piña	pina@hotmail.com	1	$2y$10$wqwwyjK8T7ccki5IeOK4ueZRlW8K3g2xC42ZyOG01kDru0CNhba/a	4	f
10	Wazaaaa	wazaaa@gmail.com	123	$2y$10$G7tnCsgxNo7nFV93A4H7Ie86N2RYtbppgkB6iEPg.STWF4wn2qn7O	4	t
\.


--
-- Data for Name: visitantes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.visitantes (id, ip_address, user_agent, pagina_origen) FROM stdin;
\.


--
-- Name: accesos_recursos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accesos_recursos_id_seq', 1, false);


--
-- Name: auditoria_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auditoria_id_seq', 45, true);


--
-- Name: autores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.autores_id_seq', 29, true);


--
-- Name: carreras_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.carreras_id_seq', 5, true);


--
-- Name: categorias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categorias_id_seq', 8, true);


--
-- Name: certificados_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.certificados_id_seq', 6, true);


--
-- Name: comentarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.comentarios_id_seq', 1, false);


--
-- Name: cursos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cursos_id_seq', 4, true);


--
-- Name: editoriales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.editoriales_id_seq', 7, true);


--
-- Name: evaluaciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.evaluaciones_id_seq', 6, true);


--
-- Name: inscripciones_curso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inscripciones_curso_id_seq', 8, true);


--
-- Name: interacciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.interacciones_id_seq', 1, false);


--
-- Name: interacciones_usuario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.interacciones_usuario_id_seq', 4, true);


--
-- Name: lecciones_curso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lecciones_curso_id_seq', 9, true);


--
-- Name: lineas_investigacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lineas_investigacion_id_seq', 1, false);


--
-- Name: notificaciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notificaciones_id_seq', 6, true);


--
-- Name: preguntas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.preguntas_id_seq', 17, true);


--
-- Name: privilegios_privilegio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.privilegios_privilegio_id_seq', 6, true);


--
-- Name: recursos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recursos_id_seq', 20, true);


--
-- Name: redes_informacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.redes_informacion_id_seq', 3, true);


--
-- Name: registro_actividad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.registro_actividad_id_seq', 1, true);


--
-- Name: respuestas_estudiante_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.respuestas_estudiante_id_seq', 25, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 4, true);


--
-- Name: tipo_recurso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_recurso_id_seq', 4, true);


--
-- Name: tipo_tutor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipo_tutor_id_seq', 4, true);


--
-- Name: tutores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tutores_id_seq', 3, true);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 11, true);


--
-- Name: visitantes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.visitantes_id_seq', 1, false);


--
-- Name: accesos_recursos accesos_recursos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesos_recursos
    ADD CONSTRAINT accesos_recursos_pkey PRIMARY KEY (id);


--
-- Name: auditoria auditoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auditoria
    ADD CONSTRAINT auditoria_pkey PRIMARY KEY (id);


--
-- Name: autores autores_cedula_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.autores
    ADD CONSTRAINT autores_cedula_key UNIQUE (cedula);


--
-- Name: autores autores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.autores
    ADD CONSTRAINT autores_pkey PRIMARY KEY (id);


--
-- Name: carreras carreras_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carreras
    ADD CONSTRAINT carreras_nombre_key UNIQUE (nombre);


--
-- Name: carreras carreras_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carreras
    ADD CONSTRAINT carreras_pkey PRIMARY KEY (id);


--
-- Name: categorias categorias_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_nombre_key UNIQUE (nombre);


--
-- Name: categorias categorias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categorias
    ADD CONSTRAINT categorias_pkey PRIMARY KEY (id);


--
-- Name: certificados certificados_codigo_verificacion_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificados
    ADD CONSTRAINT certificados_codigo_verificacion_key UNIQUE (codigo_verificacion);


--
-- Name: certificados certificados_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificados
    ADD CONSTRAINT certificados_pkey PRIMARY KEY (id);


--
-- Name: comentarios comentarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comentarios
    ADD CONSTRAINT comentarios_pkey PRIMARY KEY (id);


--
-- Name: cursos cursos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cursos
    ADD CONSTRAINT cursos_pkey PRIMARY KEY (id);


--
-- Name: detalles_investigaciones detalles_investigaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_investigaciones
    ADD CONSTRAINT detalles_investigaciones_pkey PRIMARY KEY (id_recurso);


--
-- Name: detalles_proyectos detalles_proyectos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_proyectos
    ADD CONSTRAINT detalles_proyectos_pkey PRIMARY KEY (id_recurso);


--
-- Name: detalles_revistas detalles_revistas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_revistas
    ADD CONSTRAINT detalles_revistas_pkey PRIMARY KEY (id_recurso);


--
-- Name: editoriales editoriales_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.editoriales
    ADD CONSTRAINT editoriales_nombre_key UNIQUE (nombre);


--
-- Name: editoriales editoriales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.editoriales
    ADD CONSTRAINT editoriales_pkey PRIMARY KEY (id);


--
-- Name: evaluaciones evaluaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evaluaciones
    ADD CONSTRAINT evaluaciones_pkey PRIMARY KEY (id);


--
-- Name: inscripciones_curso inscripciones_curso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscripciones_curso
    ADD CONSTRAINT inscripciones_curso_pkey PRIMARY KEY (id);


--
-- Name: interacciones interacciones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interacciones
    ADD CONSTRAINT interacciones_pkey PRIMARY KEY (id);


--
-- Name: interacciones_usuario interacciones_usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interacciones_usuario
    ADD CONSTRAINT interacciones_usuario_pkey PRIMARY KEY (id);


--
-- Name: lecciones_curso lecciones_curso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lecciones_curso
    ADD CONSTRAINT lecciones_curso_pkey PRIMARY KEY (id);


--
-- Name: lineas_investigacion lineas_investigacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lineas_investigacion
    ADD CONSTRAINT lineas_investigacion_pkey PRIMARY KEY (id);


--
-- Name: notificaciones notificaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notificaciones
    ADD CONSTRAINT notificaciones_pkey PRIMARY KEY (id);


--
-- Name: preferencias_usuario preferencias_usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preferencias_usuario
    ADD CONSTRAINT preferencias_usuario_pkey PRIMARY KEY (id_usuario);


--
-- Name: preguntas preguntas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preguntas
    ADD CONSTRAINT preguntas_pkey PRIMARY KEY (id);


--
-- Name: privilegios privilegios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.privilegios
    ADD CONSTRAINT privilegios_pkey PRIMARY KEY (privilegio_id);


--
-- Name: proyecto_tutores proyecto_tutores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proyecto_tutores
    ADD CONSTRAINT proyecto_tutores_pkey PRIMARY KEY (id_recurso, id_tutor);


--
-- Name: recurso_autores recurso_autores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_autores
    ADD CONSTRAINT recurso_autores_pkey PRIMARY KEY (id_recurso, id_autor);


--
-- Name: recurso_lineas_investigacion recurso_lineas_investigacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_lineas_investigacion
    ADD CONSTRAINT recurso_lineas_investigacion_pkey PRIMARY KEY (id_recurso, id_linea_investigacion);


--
-- Name: recursos recursos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recursos
    ADD CONSTRAINT recursos_pkey PRIMARY KEY (id);


--
-- Name: redes_informacion redes_informacion_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redes_informacion
    ADD CONSTRAINT redes_informacion_nombre_key UNIQUE (nombre);


--
-- Name: redes_informacion redes_informacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.redes_informacion
    ADD CONSTRAINT redes_informacion_pkey PRIMARY KEY (id);


--
-- Name: registro_actividad registro_actividad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registro_actividad
    ADD CONSTRAINT registro_actividad_pkey PRIMARY KEY (id);


--
-- Name: respuestas_estudiante respuestas_estudiante_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.respuestas_estudiante
    ADD CONSTRAINT respuestas_estudiante_pkey PRIMARY KEY (id);


--
-- Name: roles roles_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_nombre_key UNIQUE (nombre);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: suscripciones_redes suscripciones_redes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suscripciones_redes
    ADD CONSTRAINT suscripciones_redes_pkey PRIMARY KEY (id_usuario, id_red_informacion);


--
-- Name: tipo_recurso tipo_recurso_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_recurso
    ADD CONSTRAINT tipo_recurso_nombre_key UNIQUE (nombre);


--
-- Name: tipo_recurso tipo_recurso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_recurso
    ADD CONSTRAINT tipo_recurso_pkey PRIMARY KEY (id);


--
-- Name: tipo_tutor tipo_tutor_nombre_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_tutor
    ADD CONSTRAINT tipo_tutor_nombre_key UNIQUE (nombre);


--
-- Name: tipo_tutor tipo_tutor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipo_tutor
    ADD CONSTRAINT tipo_tutor_pkey PRIMARY KEY (id);


--
-- Name: tutores tutores_cedula_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tutores
    ADD CONSTRAINT tutores_cedula_key UNIQUE (cedula);


--
-- Name: tutores tutores_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tutores
    ADD CONSTRAINT tutores_pkey PRIMARY KEY (id);


--
-- Name: inscripciones_curso uk_inscripcion; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscripciones_curso
    ADD CONSTRAINT uk_inscripcion UNIQUE (id_usuario, id_curso);


--
-- Name: interacciones unique_interaccion; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interacciones
    ADD CONSTRAINT unique_interaccion UNIQUE (id_usuario, id_recurso, tipo_interaccion);


--
-- Name: interacciones_usuario unique_interaccion_usuario; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interacciones_usuario
    ADD CONSTRAINT unique_interaccion_usuario UNIQUE (id_usuario, id_recurso, tipo);


--
-- Name: usuarios usuarios_cedula_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_cedula_key UNIQUE (cedula);


--
-- Name: usuarios usuarios_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_email_key UNIQUE (email);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id);


--
-- Name: visitantes visitantes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.visitantes
    ADD CONSTRAINT visitantes_pkey PRIMARY KEY (id);


--
-- Name: recursos tg_auditoria_recursos_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tg_auditoria_recursos_delete BEFORE DELETE ON public.recursos FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_recursos();


--
-- Name: recursos tg_auditoria_recursos_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tg_auditoria_recursos_insert AFTER INSERT ON public.recursos FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_recursos();


--
-- Name: usuarios tg_auditoria_usuarios_delete; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tg_auditoria_usuarios_delete BEFORE DELETE ON public.usuarios FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_usuarios();


--
-- Name: usuarios tg_auditoria_usuarios_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tg_auditoria_usuarios_insert AFTER INSERT ON public.usuarios FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_usuarios();


--
-- Name: usuarios tg_auditoria_usuarios_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER tg_auditoria_usuarios_update AFTER UPDATE ON public.usuarios FOR EACH ROW EXECUTE FUNCTION public.fn_auditoria_usuarios();


--
-- Name: accesos_recursos accesos_recursos_id_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesos_recursos
    ADD CONSTRAINT accesos_recursos_id_recurso_fkey FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: accesos_recursos accesos_recursos_id_registro_actividad_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accesos_recursos
    ADD CONSTRAINT accesos_recursos_id_registro_actividad_fkey FOREIGN KEY (id_registro_actividad) REFERENCES public.registro_actividad(id) ON DELETE CASCADE;


--
-- Name: auditoria auditoria_usuario_responsable_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auditoria
    ADD CONSTRAINT auditoria_usuario_responsable_fkey FOREIGN KEY (usuario_responsable) REFERENCES public.usuarios(id) ON DELETE SET NULL;


--
-- Name: certificados certificados_id_curso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificados
    ADD CONSTRAINT certificados_id_curso_fkey FOREIGN KEY (id_curso) REFERENCES public.cursos(id) ON DELETE CASCADE;


--
-- Name: certificados certificados_id_respuesta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificados
    ADD CONSTRAINT certificados_id_respuesta_fkey FOREIGN KEY (id_respuesta) REFERENCES public.respuestas_estudiante(id) ON DELETE CASCADE;


--
-- Name: certificados certificados_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.certificados
    ADD CONSTRAINT certificados_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: comentarios comentarios_id_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comentarios
    ADD CONSTRAINT comentarios_id_recurso_fkey FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: comentarios comentarios_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comentarios
    ADD CONSTRAINT comentarios_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: cursos cursos_id_docente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cursos
    ADD CONSTRAINT cursos_id_docente_fkey FOREIGN KEY (id_docente) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: detalles_investigaciones detalles_investigaciones_id_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_investigaciones
    ADD CONSTRAINT detalles_investigaciones_id_recurso_fkey FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: detalles_investigaciones detalles_investigaciones_id_red_informacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_investigaciones
    ADD CONSTRAINT detalles_investigaciones_id_red_informacion_fkey FOREIGN KEY (id_red_informacion) REFERENCES public.redes_informacion(id) ON DELETE SET NULL;


--
-- Name: detalles_proyectos detalles_proyectos_id_carrera_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_proyectos
    ADD CONSTRAINT detalles_proyectos_id_carrera_fkey FOREIGN KEY (id_carrera) REFERENCES public.carreras(id) ON DELETE SET NULL;


--
-- Name: detalles_proyectos detalles_proyectos_id_investigacion_padre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_proyectos
    ADD CONSTRAINT detalles_proyectos_id_investigacion_padre_fkey FOREIGN KEY (id_investigacion_padre) REFERENCES public.recursos(id) ON DELETE SET NULL;


--
-- Name: detalles_proyectos detalles_proyectos_id_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_proyectos
    ADD CONSTRAINT detalles_proyectos_id_recurso_fkey FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: detalles_revistas detalles_revistas_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_revistas
    ADD CONSTRAINT detalles_revistas_id_categoria_fkey FOREIGN KEY (id_categoria) REFERENCES public.categorias(id) ON DELETE SET NULL;


--
-- Name: detalles_revistas detalles_revistas_id_editorial_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_revistas
    ADD CONSTRAINT detalles_revistas_id_editorial_fkey FOREIGN KEY (id_editorial) REFERENCES public.editoriales(id) ON DELETE SET NULL;


--
-- Name: detalles_revistas detalles_revistas_id_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalles_revistas
    ADD CONSTRAINT detalles_revistas_id_recurso_fkey FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: evaluaciones evaluaciones_id_curso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.evaluaciones
    ADD CONSTRAINT evaluaciones_id_curso_fkey FOREIGN KEY (id_curso) REFERENCES public.cursos(id) ON DELETE CASCADE;


--
-- Name: inscripciones_curso inscripciones_curso_id_curso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscripciones_curso
    ADD CONSTRAINT inscripciones_curso_id_curso_fkey FOREIGN KEY (id_curso) REFERENCES public.cursos(id) ON DELETE CASCADE;


--
-- Name: inscripciones_curso inscripciones_curso_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscripciones_curso
    ADD CONSTRAINT inscripciones_curso_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: interacciones interacciones_id_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interacciones
    ADD CONSTRAINT interacciones_id_recurso_fkey FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: interacciones interacciones_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interacciones
    ADD CONSTRAINT interacciones_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: interacciones_usuario interacciones_usuario_id_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interacciones_usuario
    ADD CONSTRAINT interacciones_usuario_id_recurso_fkey FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: interacciones_usuario interacciones_usuario_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.interacciones_usuario
    ADD CONSTRAINT interacciones_usuario_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: lecciones_curso lecciones_curso_id_curso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lecciones_curso
    ADD CONSTRAINT lecciones_curso_id_curso_fkey FOREIGN KEY (id_curso) REFERENCES public.cursos(id) ON DELETE CASCADE;


--
-- Name: lineas_investigacion lineas_investigacion_id_carrera_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lineas_investigacion
    ADD CONSTRAINT lineas_investigacion_id_carrera_fkey FOREIGN KEY (id_carrera) REFERENCES public.carreras(id) ON DELETE CASCADE;


--
-- Name: notificaciones notificaciones_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notificaciones
    ADD CONSTRAINT notificaciones_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: preferencias_usuario preferencias_usuario_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preferencias_usuario
    ADD CONSTRAINT preferencias_usuario_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: preguntas preguntas_id_evaluacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.preguntas
    ADD CONSTRAINT preguntas_id_evaluacion_fkey FOREIGN KEY (id_evaluacion) REFERENCES public.evaluaciones(id) ON DELETE CASCADE;


--
-- Name: roles privilegio_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT privilegio_fk FOREIGN KEY (privilegio_id) REFERENCES public.privilegios(privilegio_id) NOT VALID;


--
-- Name: proyecto_tutores proyecto_tutores_id_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proyecto_tutores
    ADD CONSTRAINT proyecto_tutores_id_recurso_fkey FOREIGN KEY (id_recurso) REFERENCES public.detalles_proyectos(id_recurso) ON DELETE CASCADE;


--
-- Name: proyecto_tutores proyecto_tutores_id_tutor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proyecto_tutores
    ADD CONSTRAINT proyecto_tutores_id_tutor_fkey FOREIGN KEY (id_tutor) REFERENCES public.tutores(id) ON DELETE CASCADE;


--
-- Name: proyecto_tutores proyecto_tutores_tipo_tutor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.proyecto_tutores
    ADD CONSTRAINT proyecto_tutores_tipo_tutor_id_fkey FOREIGN KEY (tipo_tutor_id) REFERENCES public.tipo_tutor(id) ON DELETE SET NULL;


--
-- Name: recurso_autores recurso_autores_id_autor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_autores
    ADD CONSTRAINT recurso_autores_id_autor_fkey FOREIGN KEY (id_autor) REFERENCES public.autores(id) ON DELETE CASCADE;


--
-- Name: recurso_autores recurso_autores_id_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_autores
    ADD CONSTRAINT recurso_autores_id_recurso_fkey FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: recurso_lineas_investigacion recurso_lineas_investigacion_id_linea_investigacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_lineas_investigacion
    ADD CONSTRAINT recurso_lineas_investigacion_id_linea_investigacion_fkey FOREIGN KEY (id_linea_investigacion) REFERENCES public.lineas_investigacion(id) ON DELETE CASCADE;


--
-- Name: recurso_lineas_investigacion recurso_lineas_investigacion_id_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recurso_lineas_investigacion
    ADD CONSTRAINT recurso_lineas_investigacion_id_recurso_fkey FOREIGN KEY (id_recurso) REFERENCES public.recursos(id) ON DELETE CASCADE;


--
-- Name: recursos recursos_id_tipo_recurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recursos
    ADD CONSTRAINT recursos_id_tipo_recurso_fkey FOREIGN KEY (id_tipo_recurso) REFERENCES public.tipo_recurso(id) ON DELETE RESTRICT;


--
-- Name: registro_actividad registro_actividad_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registro_actividad
    ADD CONSTRAINT registro_actividad_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id) ON DELETE SET NULL;


--
-- Name: registro_actividad registro_actividad_id_visitante_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.registro_actividad
    ADD CONSTRAINT registro_actividad_id_visitante_fkey FOREIGN KEY (id_visitante) REFERENCES public.visitantes(id) ON DELETE SET NULL;


--
-- Name: respuestas_estudiante respuestas_estudiante_id_evaluacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.respuestas_estudiante
    ADD CONSTRAINT respuestas_estudiante_id_evaluacion_fkey FOREIGN KEY (id_evaluacion) REFERENCES public.evaluaciones(id) ON DELETE CASCADE;


--
-- Name: respuestas_estudiante respuestas_estudiante_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.respuestas_estudiante
    ADD CONSTRAINT respuestas_estudiante_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: suscripciones_redes suscripciones_redes_id_red_informacion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suscripciones_redes
    ADD CONSTRAINT suscripciones_redes_id_red_informacion_fkey FOREIGN KEY (id_red_informacion) REFERENCES public.redes_informacion(id) ON DELETE CASCADE;


--
-- Name: suscripciones_redes suscripciones_redes_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suscripciones_redes
    ADD CONSTRAINT suscripciones_redes_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuarios(id) ON DELETE CASCADE;


--
-- Name: usuarios usuarios_id_rol_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_id_rol_fkey FOREIGN KEY (id_rol) REFERENCES public.roles(id) ON DELETE RESTRICT;


--
-- PostgreSQL database dump complete
--

\unrestrict ZEIyYjeXJ9s4qxpyghHWJgqBNbNxAtn8lYDN5C1raroqkgG1Lpom5XcT4d4HkGU

