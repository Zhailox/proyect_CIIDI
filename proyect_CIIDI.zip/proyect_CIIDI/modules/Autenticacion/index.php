<?php
// modules/Autenticacion/index.php

// Nos aseguramos de traer el contrato
require_once CORE_PATH . 'Interfaces/ModuleContract.php';

// Nombre de clase único para este módulo
class AutenticacionModule implements ModuleContract {
    
    public function getNombre(): string {
        return 'Módulo de Acceso y Seguridad';
    }

public function getRutas(): array {
        return [
            'login' => [
                'vista'  => __DIR__ . '/views/login.php', 
                'titulo' => 'Iniciar Sesión - Control de Acceso',
                // NUEVO: Desactivamos los componentes para esta pantalla en específico
                'layout' => [
                    'header'  => true,
                    'sidebar' => false,
                    'footer'  => false
                ],
                'css'    => [
                    'assets/css/login.css'
                    ]
            ],
            'perfil' => [
                'vista'  => __DIR__ . '/views/mi_dashboard.php', 
                'titulo' => 'Mi Perfil - Panel de Control'
                // No incluimos 'layout' aquí porque queremos que use el valor por defecto (true)
            ],
            'recuperar-cuenta' => [
                'vista'  => __DIR__ . '/views/recuperar_cuenta.php', 
                'titulo' => 'Recuperación de Credenciales',
                // Si la universidad quisiera que recuperar cuenta solo tenga footer, se puede configurar libremente:
                'layout' => [
                    'header'  => true,
                    'sidebar' => true,
                    'footer'  => true
                ]
            ]
        ];
    }

    public function getMenuConfig(): array {
        return [
            [
                'tipo'        => 'parent',
                'titulo'      => 'Perfil',
                'icono'       => '👤',
                'enlace'      => 'perfil',
                // Estas rutas mantendrán encendido el contenedor padre en el sidebar
                'activadores' => ['perfil', 'recuperar-cuenta'], 
                'subitems'    => [
                    // ['ruta' => 'login', 'titulo' => '🔑 Iniciar Sesión'],
                    ['ruta' => 'perfil', 'titulo' => '⚙️ Mi Perfil'],
                    ['ruta' => 'recuperar-cuenta', 'titulo' => '🔄 Recuperar Clave']
                ]
            ]
        ];
    }
}

// Retornamos la instancia para que el Microkernel la procese
return new AutenticacionModule();