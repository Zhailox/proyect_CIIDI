<?php
// modules/Autenticacion/controllers/LoginController.php
require_once __DIR__ . '/../models/UsuarioModel.php';
require_once CORE_PATH . 'Security/Auth.php';

class LoginController {
    
    private $usuarioModel;

    public function __construct() {
        $this->usuarioModel = new UsuarioModel();
    }

    // Prepara los datos (si hubiera) y permite que el Kernel cargue la vista
    // ... parte superior del controlador intacta ...

    public function mostrarFormulario() {
        if (Auth::check()) {
            header("Location: perfil");
            exit; 
        }
        
        $error = $_SESSION['error_login'] ?? null;
        $exito = $_SESSION['exito_registro'] ?? null; // NUEVA LÍNEA
        
        unset($_SESSION['error_login'], $_SESSION['exito_registro']);
        
        return ['error' => $error, 'exito' => $exito]; // NUEVA LÍNEA
    }
    // Método para la pantalla de recuperar contraseña
    public function mostrarRecuperar() {
        // Si ya está logueado, no tiene sentido que recupere clave
        if (Auth::check()) {
            header("Location: perfil");
            exit;
        }
        return [];
    }
    
    
    public function procesar() {
        // 1. Forzar a PHP a mostrar errores (rompe el silencio de PostgreSQL)
        
        ini_set('display_errors', 1);
        error_reporting(E_ALL);

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return [
                'es_error' => true,
                'mensaje'  => 'Petición inválida. Por favor, intente de nuevo.',
                'destino'  => 'login'
            ];
        }

        $cedula = trim($_POST['cedula'] ?? '');
        $password = trim($_POST['password'] ?? '');

        if (empty($cedula) || empty($password)) {
            return [
                'es_error' => true,
                'mensaje'  => 'Debe ingresar su cédula y contraseña para continuar.',
                'destino'  => 'login'
            ];
        }

        // 2. Probar la Base de Datos
        
        try {
            $usuario = $this->usuarioModel->intentarAutenticacion($cedula);
        } catch (Exception $e) {
            die("<div style='background:#fee2e2; padding:20px; color:#991b1b; font-family:sans-serif;'>
                    <h2>Error Fatal de SQL</h2>
                    <p>La consulta a PostgreSQL falló. Revisa tu UsuarioModel. El error exacto es:</p>
                    <code style='background: #fff; padding: 10px; display:block;'>{$e->getMessage()}</code>
                 </div>");
        }

        // 3. Probar si el usuario existe
        if (!$usuario) {
            die("<div style='background:#fef3c7; padding:20px; color:#92400e; font-family:sans-serif;'>
                    <h2>Aviso: Usuario No Encontrado</h2>
                    <p>No se encontró ninguna cuenta activa con la cédula <b>{$cedula}</b>.</p>
                 </div>");
        }

        // 4. Probar la encriptación de la contraseña
        if (!password_verify($password, $usuario['contrasena'])) {
            die("<div style='background:#fef3c7; padding:20px; color:#92400e; font-family:sans-serif;'>
                    <h2>Aviso: Contraseña Incorrecta</h2>
                    <p>La cédula <b>{$cedula}</b> existe, pero la contraseña no coincide con el Hash de la base de datos.</p>
                 </div>");
        }

        // 5. Si todo está perfecto
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        if ($usuario && password_verify($password, $usuario['contrasena'])) {
            session_regenerate_id(true);
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['nombre_usuario'] = $usuario['nombre_completo'];
            $_SESSION['rol_nombre'] = $usuario['nombre_rol'];
            $_SESSION['nivel_privilegio'] = (int) $usuario['nivel_privilegio'];

            $this->usuarioModel->registrarAcceso($usuario['id']);

            // ÉXITO: Mandamos los datos para la pantalla de bienvenida
            return [
                'es_error'       => false,
                'nombre_usuario' => $usuario['nombre_completo'],
                'rol_nombre'     => $usuario['nombre_rol'],
                'destino'        => 'perfil'
            ];
            
        } else {
            // ERROR: Mandamos los datos para la pantalla de fallo
            return [
                'es_error' => true,
                'mensaje'  => 'Credenciales inválidas o cuenta no registrada.',
                'destino'  => 'login'
            ];
        }
    }

    public function cerrarSesion() {
        // 1. Aseguramos que PHP sepa qué sesión estamos intentando destruir
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        
        // 2. Vaciamos las variables de la memoria RAM
        $_SESSION = [];
        
        // 3. Destruimos el archivo físico de la sesión en el servidor
        session_destroy();
        
        // 4. Redirigimos al usuario a la pantalla de login (ruta relativa segura)
        header("Location: login");
        exit; // Vital para detener cualquier otro renderizado
    }
    // Carga la vista del formulario de registro
    public function mostrarRegistro() {
        if (Auth::check()) {
            header("Location: perfil");
            exit;
        }
        $error = $_SESSION['error_registro'] ?? null;
        unset($_SESSION['error_registro']);
        
        return ['error' => $error];
    }

    // Lógica pesada de creación de cuenta
    public function procesarRegistro() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') return false;

        $cedula = trim($_POST['cedula'] ?? '');
        $nombre = trim($_POST['nombre'] ?? '');
        $email = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
        $password = trim($_POST['password'] ?? '');
        $password_confirm = trim($_POST['password_confirm'] ?? '');

        // 1. Validar campos vacíos
        if (empty($cedula) || empty($nombre) || empty($email) || empty($password)) {
            $_SESSION['error_registro'] = 'Todos los campos son obligatorios.';
            header("Location: registro");
            exit;
        }

        // 2. Validar que las contraseñas coincidan
        if ($password !== $password_confirm) {
            $_SESSION['error_registro'] = 'Las contraseñas no coinciden.';
            header("Location: registro");
            exit;
        }

        // 3. Validar duplicados en la BD
        if ($this->usuarioModel->existeUsuario($cedula, $email)) {
            $_SESSION['error_registro'] = 'La cédula o el correo ya están registrados en el sistema.';
            header("Location: registro");
            exit;
        }

        // 4. Encriptar contraseña y guardar
        $hashSeguro = password_hash($password, PASSWORD_BCRYPT);
        $creado = $this->usuarioModel->registrarUsuario($cedula, $nombre, $email, $hashSeguro);

        if ($creado) {
            // Mandamos mensaje de éxito a la pantalla de login
            $_SESSION['exito_registro'] = 'Cuenta creada exitosamente. Ya puede iniciar sesión.';
            header("Location: login");
            exit;
        } else {
            $_SESSION['error_registro'] = 'Ocurrió un error interno al crear la cuenta.';
            header("Location: registro");
            exit;
        }
    }
}