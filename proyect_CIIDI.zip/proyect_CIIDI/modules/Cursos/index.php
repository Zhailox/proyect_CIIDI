<?php
// modules/Cursos/index.php

// Asegurarnos de que la interfaz esté disponible
require_once CORE_PATH . 'Interfaces/ModuleContract.php';

class CursosModule implements ModuleContract {
    
    public function getNombre(): string {
        return 'Módulo de Formación y Cursos';
    }

    public function getRutas(): array {
        return [
            'cursos' => [
                'vista'  => __DIR__ . '/views/showcase_cursos.php',
                'titulo' => 'Catálogo de Cursos - Oferta Formativa'
            ],
            // Agregamos la ruta de mis-cursos para que el submenú tenga a dónde ir
            'mis-cursos' => [
                'vista'  => __DIR__ . '/views/mis_cursos.php', // Podrás crear esta vista luego
                'titulo' => 'Mis Inscripciones - Formación'
            ]
        ];
    }

    // AQUÍ ESTÁ LA SOLUCIÓN: Cumplimos con el contrato entregando el plano del menú
    public function getMenuConfig(): array {
        return [
            [
                'tipo'        => 'parent',
                'titulo'      => 'Cursos',
                'icono'       => '🎓',
                'enlace'      => 'cursos', 
                'activadores' => ['cursos', 'mis-cursos'], // Rutas que iluminan esta sección
                'subitems'    => [
                    ['ruta' => 'cursos', 'titulo' => '🎒 Oferta Formativa'],
                    ['ruta' => 'mis-cursos', 'titulo' => '✔️ Mis Inscripciones']
                ]
            ]
        ];
    }
}

// Retornamos la instancia para que el Kernel la guarde
return new CursosModule();