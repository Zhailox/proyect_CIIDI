<div class="welcome-banner">
    <h1>Aprende con Nosotros</h1>
    <p>Explora nuestro catálogo de formación continua. Fortalece tus habilidades técnicas y metodológicas con programas diseñados para las exigencias del sector productivo y académico.</p>
</div>

<div class="catalogo-section">
    <h2>Cursos Destacados</h2>
    
    <?php 
    // Incluimos la cuadrícula de cursos. 
    // Usamos __DIR__ para asegurar que busque en la misma carpeta donde está este archivo.
    include __DIR__ . '/grid_cursos.php'; 
    ?>
</div>