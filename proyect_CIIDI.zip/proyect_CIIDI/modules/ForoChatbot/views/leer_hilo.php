<div class="thread-detail-container">
    
    <div class="breadcrumb">
        <a href="foro-general">⬅ Volver al Foro General</a> / Lectura de Hilo
    </div>

    <div class="original-post">
        <div class="thread-meta" style="margin-bottom: 0.8rem;">
            Posteado por <span class="thread-author" style="font-size: 0.95rem;">DevTrujillo</span> • 08 de Junio, 2026 • 28 Votos
        </div>
        <h1 class="thread-title">Error al generar PDF con la librería FPDF usando puro PHP</h1>
        
        <div class="thread-tags" style="margin-bottom: 1.5rem;">
            <span class="tag">PHP</span>
            <span class="tag">Bugs</span>
        </div>

        <div class="post-body">
            <p>Buenas tardes a toda la comunidad.</p>
            <br>
            <p>Estoy intentando generar los reportes de inventario de mi PST usando FPDF. El código conecta bien a la base de datos relacional, pero al momento de renderizar la tabla y llamar a <code>$pdf->Output();</code>, el navegador me lanza un error que dice: <strong>"FPDF error: Some data has already been output, can't send PDF file"</strong>.</p>
            <br>
            <p>Ya revisé que no haya espacios en blanco antes de la etiqueta <code>&lt;?php</code>. ¿A alguien más le ha pasado trabajando con esta arquitectura de microkernel sin frameworks?</p>
        </div>

        <div style="display: flex; gap: 1rem;">
            <button class="btn" style="background-color: transparent; border: 1px solid var(--color-secundario); color: var(--color-secundario);">▲ Votar Arriba</button>
            <button class="btn" style="background-color: transparent; border: 1px solid var(--text-muted); color: var(--text-muted);">Responder</button>
        </div>
    </div>

    <div class="comments-section">
        <h4>Respuestas (2)</h4>

        <div class="comment-card">
            <div class="comment-avatar">A</div>
            <div class="comment-content">
                <div class="comment-header">
                    <span class="comment-author">AnaP_Trayecto4</span>
                    <span class="comment-date">Hace 2 horas</span>
                </div>
                <div class="comment-text">
                    ¡Hola! Ese error suele pasar si en algún archivo anterior (como tu index.php o el kernel) tienes un <code>echo</code> o incluso un salto de línea fuera de las etiquetas de PHP. Revisa el archivo del controlador donde llamas al modelo, a veces se escapa un espacio al final del archivo.
                </div>
            </div>
        </div>

        <div class="comment-card">
            <div class="comment-avatar">J</div>
            <div class="comment-content">
                <div class="comment-header">
                    <span class="comment-author">Ing_JosueG (Tutor) <span style="background: var(--color-secundario); color: #fff; padding: 0.1rem 0.4rem; border-radius: 4px; font-size: 0.7rem; margin-left: 5px;">Docente</span></span>
                    <span class="comment-date">Hace 30 minutos</span>
                </div>
                <div class="comment-text">
                    Concuerdo con Ana. Adicionalmente, te recomiendo colocar <code>ob_start();</code> al inicio de tu controlador para limpiar el búfer de salida antes de generar el PDF. En la documentación del repositorio central dejamos un ejemplo de esto.
                </div>
            </div>
        </div>

        <div class="reply-box">
            <h5 style="margin-bottom: 1rem; color: var(--color-principal);">Agregar una respuesta</h5>
            <form action="#" onsubmit="event.preventDefault();">
                <textarea class="modal-textarea" style="background-color: #ffffff; margin-bottom: 1rem;" placeholder="Escribe tu aporte o solución..." required></textarea>
                <button type="submit" class="btn">Publicar Respuesta</button>
            </form>
        </div>

    </div>

</div>