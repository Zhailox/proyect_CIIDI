<div class="foro-layout">
    
    <input type="radio" name="drawer-group" id="drawer-none" class="drawer-radio" checked>
    <input type="radio" name="drawer-group" id="drawer-bot" class="drawer-radio">
    <input type="radio" name="drawer-group" id="drawer-tools" class="drawer-radio">

    <div class="foro-main">
        <div class="foro-header">
            <div class="foro-header-info">
                <a href="mis-chats" style="text-decoration: none; color: var(--color-secundario); font-size: 0.85rem; font-weight: 600; display: inline-block; margin-bottom: 0.5rem;">
                    ⬅ Volver a Mis Grupos
                </a>
                <h2>Proyecto: Sistema de Control de Pagos</h2>
                <p>Ecosistema de Tutoría Académica</p>
                <details class="participants-details">
                    <summary>Ver Participantes (2)</summary>
                    <div class="participants-dropdown">
                        <div class="participant-item">
                            <div class="participant-avatar">👨‍🎓</div>
                            <div class="participant-info">
                                <strong>Tú (Estudiante)</strong>
                                <span>Desarrollador / Investigador</span>
                            </div>
                        </div>
                        <div class="participant-item">
                            <div class="participant-avatar">👨‍🏫</div>
                            <div class="participant-info">
                                <strong>Ing. Josué García</strong>
                                <span>Tutor Académico</span>
                            </div>
                        </div>
                    </div>
                </details>
            </div>
        </div>

        <div class="chat-messages">
            <div class="mensaje tutor">
                <span class="msg-meta">Ing. Josué García (Tutor)</span>
                Buenas tardes. Avanzaremos con la estructura propuesta.
            </div>
        </div>

        <form class="input-area" action="#" method="POST" enctype="multipart/form-data" onsubmit="event.preventDefault();">
            <label class="btn-attach" title="Adjuntar documento"><img class="svg-icon blanco" src="../modules/ForoChatbot/assets/link.svg"><input type="file" hidden></label>
            <input type="text" class="input-box" placeholder="Escribe un mensaje al grupo..." required>
            <button type="submit" class="btn">Enviar</button>
        </form>
    </div>

    <div class="foro-drawers">
        <?php include __DIR__ . '/ui_bot.php'; ?>
    </div>

    <div class="foro-toolbar">
        <label for="drawer-bot" class="toolbar-btn" title="Copiloto Chavo (IA)">Chavo</label>
        <label for="drawer-tools" class="toolbar-btn" title="Herramientas del Profesor">Tools</label>
        
        <label for="drawer-none" class="toolbar-btn close-toolbar-btn" title="Ocultar Paneles">X</label>
    </div>
</div>