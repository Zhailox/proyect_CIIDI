<div class="welcome-banner" style="margin-bottom: 2.5rem;">
    <h1>Foros y Tutorías de Proyectos</h1>
    <p>Espacio de colaboración entre estudiantes y profesores tutores. Discute avances, comparte documentos y apóyate en "Chavo", el asistente de IA local, para resumir acuerdos y extraer requerimientos.</p>
</div>

<div class="cards-grid">
    <div class="card featured">
        <h3>Proyecto: Sistema de Control de Pagos</h3>
        <p>Grupo: Ing. Software Trayecto 4. Tutor: Ing. Josué García. Última actividad: Hace 2 horas.</p>
        <a href="sala-chat" class="btn">Entrar a la Sala</a>
    </div>

    <div class="card">
        <h3>Dudas Metodológicas IAP</h3>
        <p>Foro abierto general para discutir la aplicación de la metodología IAP y la redacción del Documento Rector.</p>
        <button class="btn">Explorar Foro</button>
    </div>
</div>