<div class="inbox-wrapper">
    
    <div class="inbox-toolbar">
        <div class="inbox-title-group">
            <h2>Mis Tutorías y Proyectos</h2>
            <p>Panel de control centralizado de comunicaciones.</p>
        </div>
        <div class="inbox-search-wrapper">
            <span class="inbox-search-icon">🔍</span>
            <input type="text" class="inbox-search-premium" placeholder="Buscar por proyecto, estudiante o tutor...">
        </div>
    </div>

    <div class="inbox-filters">
        <button class="filter-pill active">Todos</button>
        <button class="filter-pill">No leídos</button>
        <button class="filter-pill">Tutorías (IUNE)</button>
        <button class="filter-pill">Investigación</button>
    </div>

    <div class="chat-cards-list">
        
        <a href="sala-chat" class="chat-card unread">
            <div class="card-avatar" style="background: linear-gradient(135deg, #4f46e5, #3b82f6);">
                I
                <div class="online-dot"></div>
            </div>
            <div class="card-content">
                <div class="card-top">
                    <span class="card-title">Sistema de Pago - IUNE Valera</span>
                    <span class="card-pin" title="Chat Fijado">📌</span>
                </div>
                <div class="card-preview">
                    <div class="typing-text">
                        Estudiante escribiendo <span></span><span></span><span></span>
                    </div>
                </div>
            </div>
            <div class="card-meta">
                <span class="card-time">10:42 AM</span>
                <span class="badge-pill">2 Nuevos</span>
            </div>
        </a>

        <a href="sala-chat" class="chat-card">
            <div class="card-avatar" style="background: linear-gradient(135deg, var(--color-secundario), var(--color-principal));">
                🤖
            </div>
            <div class="card-content">
                <div class="card-top">
                    <span class="card-title">Copiloto Chavo (Personal)</span>
                </div>
                <div class="card-preview">
                    Chavo: He guardado el resumen de tu última sesión en PDF. ¿Deseas revisarlo?
                </div>
            </div>
            <div class="card-meta">
                <span class="card-time">Ayer</span>
            </div>
        </a>

        <a href="sala-chat" class="chat-card">
            <div class="card-avatar" style="background: linear-gradient(135deg, #10b981, #059669);">
                T4
            </div>
            <div class="card-content">
                <div class="card-top">
                    <span class="card-title">Tutoría General - Trayecto 4</span>
                </div>
                <div class="card-preview">
                    Ing. Josué García: Recuerden que el documento de alcance se entrega este viernes sin falta en formato PDF.
                </div>
            </div>
            <div class="card-meta">
                <span class="card-time">Lunes</span>
            </div>
        </a>

        <a href="sala-chat" class="chat-card" style="opacity: 0.7;">
            <div class="card-avatar" style="background: linear-gradient(135deg, #94a3b8, #64748b);">
                A
            </div>
            <div class="card-content">
                <div class="card-top">
                    <span class="card-title">Algoritmo ACO - Simulación</span>
                    <span class="card-pin" title="Silenciado">🔇</span>
                </div>
                <div class="card-preview">
                    Tú: Perfecto, cerramos el módulo de hormigas con Pygame.
                </div>
            </div>
            <div class="card-meta">
                <span class="card-time">12/05/26</span>
            </div>
        </a>

    </div>
</div>