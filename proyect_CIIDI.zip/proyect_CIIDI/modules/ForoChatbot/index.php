<?php
// modules/ForoChatbot/index.php

// Requerimos la interfaz base del sistema
require_once CORE_PATH . 'Interfaces/ModuleContract.php';

// Clase única para el módulo de IA Conversacional
class ForoChatbotModule implements ModuleContract {
    
    public function getNombre(): string {
        return 'Módulo de IA Conversacional y Foros (Chavo)';
    }

    public function getRutas(): array {
        return [
            'chavo' => [
                'vista'  => __DIR__ . '/views/showcase_foros.php', 
                'titulo' => 'Hilos de Discusión - Foro UPTTMBI',
                'css'    => ['../modules/ForoChatbot/assets/forochatbot.css']
            ],
            'foro-general' => [
                'vista'  => __DIR__ . '/views/lista_foros.php', 
                'titulo' => 'Comunidad UPTTMBI - Foro Público',
                'css'    => ['../modules/ForoChatbot/assets/forochatbot.css']
            ],
            // NUEVA RUTA: Para leer un hilo específico
            'leer-hilo' => [
                'vista'  => __DIR__ . '/views/leer_hilo.php', 
                'titulo' => 'Viendo Hilo - Foro Público',
                'css'    => ['../modules/ForoChatbot/assets/forochatbot.css']
            ],
            'mis-chats' => [
                'vista'  => __DIR__ . '/views/lista_chats.php', 
                'titulo' => 'Mis Grupos de Proyecto',
                'css'    => ['../modules/ForoChatbot/assets/forochatbot.css']
            ],
            'sala-chat' => [
                'vista'  => __DIR__ . '/views/sala_chat.php', 
                'titulo' => 'Chavo - IA Conversacional Local',
                'css'    => ['../modules/ForoChatbot/assets/forochatbot.css']
            ]
        ];
    }

    public function getMenuConfig(): array {
        return [
            [
                'tipo'        => 'parent',
                'titulo'      => 'Chavo',
                'icono'       => '💬',
                'enlace'      => 'chavo',
                // Rutas que mantienen iluminado este bloque en el menú
                'activadores' => ['chavo', 'sala-chat', 'mis-chats', 'foro-general'],
                'subitems'    => [
                    ['ruta' => 'chavo', 'titulo' => '🗣️ Hilos de Discusión'],
                    ['ruta' => 'mis-chats', 'titulo' => '💬 Mis Proyectos'],
                    ['ruta' => 'foro-general', 'titulo' => '🌐 Foro Público']
                ]
            ]
        ];
    }
}

// Retornamos la instancia para que el Kernel la registre
return new ForoChatbotModule();