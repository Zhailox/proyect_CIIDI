<?php
// modules/ForoChatbot/index.php

// Requerimos la interfaz base del sistema
require_once CORE_PATH . 'Interfaces/ModuleContract.php';

// Clase única para el módulo de IA Conversacional
class ForoChatbotModule implements ModuleContract {
    
    public function getNombre(): string {
        return 'Módulo de IA Conversacional y Foros (Chavo)';
    }

    public function getRutas(): array {
        return [
            // Ruta para ver la explicación de la herramienta y los foros más activos
            'chavo' => [
                'vista'  => __DIR__ . '/views/showcase_foros.php', 
                'titulo' => 'Hilos de Discusión - Foro UPTTMBI'
            ],
            // Ruta para interactuar directamente con la IA o entrar a una sala específica
            'sala-chat' => [
                'vista'  => __DIR__ . '/views/sala_chat.php', 
                'titulo' => 'Chavo - IA Conversacional Local'
            ]
        ];
    }

    public function getMenuConfig(): array {
        return [
            [
                'tipo'        => 'parent',
                'titulo'      => 'Chavo',
                'icono'       => '💬',
                'enlace'      => 'chavo',
                // Rutas que mantienen iluminado este bloque en el menú
                'activadores' => ['chavo', 'sala-chat'], 
                'subitems'    => [
                    ['ruta' => 'chavo', 'titulo' => '🗣️ Hilos de Discusión'],
                    ['ruta' => 'sala-chat', 'titulo' => '🤖 Chatbot LLM Local']
                ]
            ]
        ];
    }
}

// Retornamos la instancia para que el Kernel la registre
return new ForoChatbotModule();