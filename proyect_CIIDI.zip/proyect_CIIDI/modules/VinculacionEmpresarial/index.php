<?php
// modules/VinculacionEmpresarial/index.php

// Requerimos la interfaz base del sistema
require_once CORE_PATH . 'Interfaces/ModuleContract.php';

// Clase única para el módulo del puente con el sector productivo
class VinculacionEmpresarialModule implements ModuleContract {
    
    public function getNombre(): string {
        return 'Módulo de Vinculación Empresarial y Sector Productivo';
    }

    public function getRutas(): array {
        return [
            // Ruta pública para informar a las empresas sobre qué hacemos y casos de éxito
            'vinculo-empresarial' => [
                'vista'  => __DIR__ . '/views/landing_informativa.php', 
                'titulo' => 'Alianzas y Casos de Éxito - Sector Productivo'
            ],
            // Ruta para que las empresas llenen el formulario con sus problemáticas
            'aplicar-problematica' => [
                'vista'  => __DIR__ . '/views/form_aplicar_problema.php', 
                'titulo' => 'Registrar Problemática - Vínculo Empresarial'
            ],
            // Ruta interna para que estudiantes/profesores vean los problemas a resolver en sus PST
            'banco-propuestas' => [
                'vista'  => __DIR__ . '/views/banco_propuestas.php', 
                'titulo' => 'Banco de Propuestas - Requerimientos de Proyectos'
            ]
        ];
    }

    public function getMenuConfig(): array {
        return [
            [
                'tipo'        => 'parent',
                'titulo'      => 'Vínculo Empresarial',
                'icono'       => '🏢',
                'enlace'      => 'vinculo-empresarial',
                // Estas rutas mantienen el menú padre desplegado e iluminado
                'activadores' => ['vinculo-empresarial', 'aplicar-problematica', 'banco-propuestas'], 
                'subitems'    => [
                    ['ruta' => 'vinculo-empresarial', 'titulo' => '🤝 Alianzas y Casos'],
                    ['ruta' => 'aplicar-problematica', 'titulo' => '📝 Registrar Problema'],
                    ['ruta' => 'banco-propuestas', 'titulo' => '📊 Banco de Propuestas']
                ]
            ]
        ];
    }
}

// Retornamos la instancia para el Kernel
return new VinculacionEmpresarialModule();