<div class="art-catalog-wrapper">

    <!-- BÚSQUEDA Y FILTROS -->
    <aside class="art-filters-sidebar">
        <h3>Búsqueda de Artículos</h3>
        
        <form action="articulos" method="GET">
            <div class="art-filter-group">
                <label for="search_art">Palabras Clave o Autor</label>
                <input type="text" id="search_art" name="q" class="art-search-input" placeholder="Ej: Redes Neuronales, Pérez...">
            </div>

            <div class="art-filter-group">
                <label>Área de Conocimiento</label>
                <label class="art-checkbox-label"><input type="checkbox" name="area[]" value="software"> Ingeniería de Software</label>
                <label class="art-checkbox-label"><input type="checkbox" name="area[]" value="redes"> Infraestructura y Redes</label>
                <label class="art-checkbox-label"><input type="checkbox" name="area[]" value="ia"> Inteligencia Artificial</label>
                <label class="art-checkbox-label"><input type="checkbox" name="area[]" value="agro"> Agroinformática</label>
            </div>

            <div class="art-filter-group">
                <label for="year_filter">Año de Publicación</label>
                <select id="year_filter" name="year" class="art-select-input">
                    <option value="">Todos los años</option>
                    <option value="2026">2026</option>
                    <option value="2025">2025</option>
                    <option value="2024">2024</option>
                </select>
            </div>
            
            <button type="submit" class="btn" style="width: 100%; margin-top: 1rem;">Aplicar Filtros</button>
        </form>
    </aside>

    <main class="art-catalog-content">

        <!-- EL MÁS RECIENTE (Objetividad cronológica en lugar de "Importancia") -->
        <?php if (!empty($articulos)): $ultimo = $articulos[0]; ?>
        <article class="art-featured-post">
            <div class="art-featured-img" style="background-image: url('../public/uploads/articulos/<?= htmlspecialchars($ultimo['imagen_portada'] ?? 'default.jpg') ?>');"></div>
            <div class="art-featured-body">
                
                <div class="art-post-meta">
                    <div class="art-tags">
                        <span class="art-tag" style="background: var(--color-secundario); color: white;">ÚLTIMA PUBLICACIÓN</span>
                        <span class="art-tag"><?= htmlspecialchars($ultimo['categoria'] ?? 'Investigación') ?></span>
                    </div>
                    <span class="art-metric">Vol. <?= htmlspecialchars($ultimo['volumen']) ?></span>
                </div>

                <a href="leer-articulo?id=<?= $ultimo['id'] ?>" class="art-post-title" style="font-size: 1.8rem;">
                    <?= htmlspecialchars($ultimo['titulo']) ?>
                </a>
                
                <p class="art-abstract">
                    <!-- Aquí iría el resumen real extraído de la BD -->
                    Resumen del documento científico. Accede para visualizar los autores, el enlace al repositorio oficial y la documentación complementaria.
                </p>
                <p class="art-authors" style="margin-bottom: 0;">Publicado: <?= htmlspecialchars($ultimo['anio_publicacion']) ?></p>
            </div>
        </article>
        <?php endif; ?>

        <!-- GRID DEL CATÁLOGO RESTANTE -->
        <div class="art-masonry-grid">
            <?php 
            // Saltamos el primero porque ya lo pusimos arriba
            $restoArticulos = array_slice($articulos, 1);
            if (empty($restoArticulos)): 
            ?>
                <p style="color: var(--gris); grid-column: 1/-1;">No hay más artículos registrados en el sistema.</p>
            <?php else: ?>
                <?php foreach ($restoArticulos as $art): ?>
                <article class="art-post-card">
                    <div class="art-post-img" style="background-image: url('../public/uploads/articulos/<?= htmlspecialchars($art['imagen_portada'] ?? 'default.jpg') ?>');"></div>
                    <div class="art-post-body">
                        <div class="art-post-meta">
                            <span class="art-tag"><?= htmlspecialchars($art['categoria'] ?? 'Artículo') ?></span>
                            <span class="art-metric">Vol. <?= htmlspecialchars($art['volumen']) ?></span>
                        </div>
                        <a href="leer-articulo?id=<?= $art['id'] ?>" class="art-post-title"><?= htmlspecialchars($art['titulo']) ?></a>
                        <p class="art-authors" style="margin-top: auto; padding-top: 1rem;">Publicado: <?= htmlspecialchars($art['anio_publicacion']) ?></p>
                    </div>
                </article>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

    </main>
</div>