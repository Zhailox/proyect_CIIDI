<?php
require_once CORE_PATH . 'Security/Auth.php';
require_once __DIR__ . '/../models/ArticuloModel.php';

class ArticulosController {
    
    private $articuloModel;

    public function __construct() {
        $this->articuloModel = new ArticuloModel();
    }

    public function index() {
        // Obtenemos los artículos desde el modelo
        $articulos = $this->articuloModel->obtenerUltimosArticulos();

        return [
            'articulos' => $articulos
        ];
    }

    public function leer() {
        // Lógica futura para leer un artículo específico
        $id = $_GET['id'] ?? 0;
        return [
            'id_articulo' => $id
        ];
    }
    public function gestor() {
        // Candado: Solo Bibliotecario (2) o SuperAdmin (3) pueden entrar aquí
        Auth::requierePrivilegioMinimo(2);

        // Reutilizamos el modelo para traer la lista de artículos
        $articulos = $this->articuloModel->obtenerUltimosArticulos();

        return [
            'articulos' => $articulos
        ];
    }
    public function nuevo() {
        // Candado: Solo administradores o bibliotecarios
        Auth::requierePrivilegioMinimo(2);

        $qb = new QueryBuilder();
        
        // Obtenemos los catálogos para llenar los <select> del formulario
        $categorias = $qb->tabla('categorias')->orderBy('nombre', 'ASC')->get();
        $editoriales = $qb->tabla('editoriales')->orderBy('nombre', 'ASC')->get();
        $etiquetas = $qb->tabla('etiquetas')->orderBy('nombre', 'ASC')->get();
        $autores = $qb->tabla('autores')->orderBy('nombre_completo', 'ASC')->get();

        return [
            'categorias' => $categorias,
            'editoriales' => $editoriales,
            'etiquetas' => $etiquetas,
            'autores' => $autores
        ];
    }
    public function procesar() {
        Auth::requierePrivilegioMinimo(2);

        // Bloqueo de seguridad si intentan acceder por URL directa
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: gestor-articulos');
            exit;
        }

        // 1. Recibir datos básicos
        $titulo = trim($_POST['titulo'] ?? '');
        $id_categoria = !empty($_POST['id_categoria']) ? (int)$_POST['id_categoria'] : null;
        $id_editorial = !empty($_POST['id_editorial']) ? (int)$_POST['id_editorial'] : null;
        $archivo_pdf = trim($_POST['archivo_pdf'] ?? '');
        $anio_publicacion = !empty($_POST['anio_publicacion']) ? (int)$_POST['anio_publicacion'] : (int)date('Y');
        $volumen = trim($_POST['volumen'] ?? '');
        $numero = trim($_POST['numero'] ?? '');
        $issn = trim($_POST['issn'] ?? '');
        
        $autores = $_POST['autores'] ?? [];
        $autores_nuevos = $_POST['autores_nuevos'] ?? [];
        $etiquetas = $_POST['etiquetas'] ?? [];

        // 2. Manejar la imagen de portada
        $nombreImagen = 'default_article.jpg';
        if (isset($_FILES['imagen_portada']) && $_FILES['imagen_portada']['error'] === UPLOAD_ERR_OK) {
            
            $ext = strtolower(pathinfo($_FILES['imagen_portada']['name'], PATHINFO_EXTENSION));
            $extensiones_validas = ['jpg', 'jpeg', 'png', 'webp'];
            
            if (in_array($ext, $extensiones_validas)) {
                $nombreImagen = 'art_' . time() . '_' . uniqid() . '.' . $ext;
                
                // Creamos la carpeta si no existe
                $destino = __DIR__ . '/../../../public/uploads/articulos/';
                if (!is_dir($destino)) { 
                    mkdir($destino, 0777, true); 
                }
                
                move_uploaded_file($_FILES['imagen_portada']['tmp_name'], $destino . $nombreImagen);
            }
        }

        if (session_status() === PHP_SESSION_NONE) session_start();

        // 3. Mandar al modelo para insertar
        try {
            $this->articuloModel->registrarArticulo(
                $titulo, $id_categoria, $id_editorial, $archivo_pdf, $anio_publicacion,
                $volumen, $numero, $issn, $nombreImagen, $autores, $autores_nuevos, $etiquetas
            );

            $_SESSION['mensaje_exito'] = "El artículo fue publicado correctamente en la vitrina.";
            header('Location: gestor-articulos');
            exit;

        } catch (Exception $e) {
            // Si hubo un error (ej. cédula de autor repetida)
            $_SESSION['mensaje_error'] = "Error de base de datos: " . $e->getMessage();
            header('Location: nuevo-articulo');
            exit;
        }
    }
}