<?php
require_once CORE_PATH . 'Database/QueryBuilder.php';

class ArticuloModel {
    
    public function obtenerUltimosArticulos() {
        $qb = new QueryBuilder();

        return $qb->tabla('recursos r')
            ->select('r.id, r.titulo, r.anio_publicacion, d.volumen, d.numero, d.imagen_portada, c.nombre as categoria')
            ->join('detalles_articulos d', 'r.id = d.id_recurso')
            ->join('categorias c', 'd.id_categoria = c.id', 'LEFT')
            ->where('r.id_tipo_recurso', '=', 3) //No sé si sea lo mejor pero aquí va el id de tipo_recurso
            ->orderBy('r.id', 'DESC')
            ->limit(20)
            ->get();
    }
    public function registrarArticulo($titulo, $id_categoria, $id_editorial, $archivo_pdf, $anio_publicacion, $volumen, $numero, $issn, $nombreImagen, $autores, $autores_nuevos, $etiquetas) {
        $db = Connection::getInstance();
        
        try {
            // Iniciamos la transacción segura
            $db->beginTransaction();

            $qb = new QueryBuilder();

            // 1. Insertar el Recurso Padre (Usamos el QueryBuilder porque devuelve el ID generado)
            // Nota: Asumo el id_tipo_recurso = 3 basado en tu modelo anterior
            $id_recurso = $qb->tabla('recursos')->insert([
                'titulo' => $titulo,
                'id_tipo_recurso' => 3, 
                'anio_publicacion' => $anio_publicacion,
                'archivo_pdf' => $archivo_pdf
            ]);

            if (!$id_recurso) throw new Exception("Error al crear el recurso padre.");

            // 2. Insertar Detalles
            // Usamos PDO directo aquí porque la tabla detalles_articulos no tiene una columna serial llamada "id", 
            // su llave primaria es id_recurso. Si usamos el QueryBuilder, intentará devolver un "id" y PostgreSQL dará error.
            $stmtDetalle = $db->prepare("INSERT INTO detalles_articulos (id_recurso, id_editorial, volumen, numero, issn, id_categoria, imagen_portada) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmtDetalle->execute([
                $id_recurso, 
                $id_editorial ?: null, 
                $volumen ?: null, 
                $numero ?: null, 
                $issn ?: null, 
                $id_categoria ?: null, 
                $nombreImagen
            ]);

            // 3. Procesar Autores
            $autores_finales = [];
            
            // Los que ya existían (Ignoramos los pseudo-ids que generó el JS temporalmente)
            if (!empty($autores)) {
                foreach ($autores as $id_autor) {
                    if (is_numeric($id_autor)) {
                        $autores_finales[] = (int)$id_autor;
                    }
                }
            }
            
            // Creamos los autores nuevos ingresados al vuelo
            if (!empty($autores_nuevos)) {
                foreach ($autores_nuevos as $json_autor) {
                    $datos = json_decode($json_autor, true);
                    if ($datos) {
                        $nuevo_id = $qb->tabla('autores')->insert([
                            'nombre_completo' => $datos['nombre'],
                            'cedula' => !empty($datos['cedula']) ? $datos['cedula'] : null
                        ]);
                        if ($nuevo_id) $autores_finales[] = $nuevo_id;
                    }
                }
            }

            // 4. Insertar Relación Recurso-Autores (Tabla Pivote)
            if (!empty($autores_finales)) {
                $stmtAutor = $db->prepare("INSERT INTO recurso_autores (id_recurso, id_autor) VALUES (?, ?)");
                foreach (array_unique($autores_finales) as $id_a) {
                    $stmtAutor->execute([$id_recurso, $id_a]);
                }
            }

            // 5. Insertar Etiquetas (Tabla Pivote)
            if (!empty($etiquetas)) {
                $stmtTag = $db->prepare("INSERT INTO recurso_etiquetas (id_recurso, id_etiqueta) VALUES (?, ?)");
                foreach ($etiquetas as $id_tag) {
                    $stmtTag->execute([$id_recurso, (int)$id_tag]);
                }
            }

            // Si todo salió bien, guardamos los cambios físicamente
            $db->commit();
            return true;

        } catch (Exception $e) {
            // Si algo explota, deshacemos todo
            $db->rollBack();
            throw $e; 
        }
    }
}