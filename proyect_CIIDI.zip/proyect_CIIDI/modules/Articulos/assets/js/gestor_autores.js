// modules/Articulos/assets/js/gestor_autores.js

document.addEventListener('DOMContentLoaded', function() {
    const buscador = document.getElementById('buscador-autores');
    const resultadosBox = document.getElementById('resultados-autores');
    const seleccionadosBox = document.getElementById('autores-seleccionados');
    const hiddenInputsBox = document.getElementById('autores-hidden-inputs');
    const errorMsg = document.getElementById('error-autores');
    
    // Leemos los datos que PHP inyectó en la ventana global
    const listaAutores = window.DATA_AUTORES || []; 
    let autoresSeleccionados = new Set();
    
    buscador.addEventListener('input', function() {
        const query = this.value.toLowerCase().trim();
        resultadosBox.innerHTML = '';
        
        if (query.length < 2) {
            resultadosBox.style.display = 'none';
            return;
        }

        let filtrados = listaAutores.filter(a => 
            a.nombre_completo.toLowerCase().includes(query) || 
            (a.cedula && a.cedula.toLowerCase().includes(query))
        );

        if (filtrados.length > 0) {
            filtrados.forEach(autor => {
                if(autoresSeleccionados.has(autor.id)) return; 

                let item = document.createElement('div');
                item.className = 'autocomplete-item';
                item.innerHTML = `<strong>${autor.nombre_completo}</strong> <span class="text-muted" style="font-size:0.8rem;">(${autor.cedula || 'Sin cédula'})</span>`;
                
                item.onclick = function() {
                    agregarAutor(autor.id, autor.nombre_completo);
                    buscador.value = '';
                    resultadosBox.style.display = 'none';
                };
                resultadosBox.appendChild(item);
            });
        } else {
            resultadosBox.innerHTML = `<div class="autocomplete-item text-secondary">
                <i class="ph-bold ph-plus"></i> Registrar "${query}" como nuevo autor
            </div>`;
            resultadosBox.firstChild.onclick = function() {
                crearAutorRapido(query);
            };
        }
        
        resultadosBox.style.display = 'block';
    });

    document.addEventListener('click', function(e) {
        if (!buscador.contains(e.target) && !resultadosBox.contains(e.target)) {
            resultadosBox.style.display = 'none';
        }
    });

    function agregarAutor(id, nombre) {
        autoresSeleccionados.add(id);
        errorMsg.style.display = 'none'; 
        renderChips();
    }

    function renderChips() {
        seleccionadosBox.innerHTML = '';
        hiddenInputsBox.innerHTML = '';

        autoresSeleccionados.forEach(id => {
            const autorInfo = listaAutores.find(a => a.id === id) || { nombre_completo: 'Nuevo Autor' };
            
            let chip = document.createElement('div');
            chip.className = 'chip-autor';
            chip.innerHTML = `${autorInfo.nombre_completo} <span class="chip-close" onclick="removerAutor('${id}')">&times;</span>`;
            seleccionadosBox.appendChild(chip);

            let hiddenInput = document.createElement('input');
            hiddenInput.type = 'hidden';
            hiddenInput.name = 'autores[]';
            hiddenInput.value = id;
            hiddenInputsBox.appendChild(hiddenInput);
        });
    }

    window.removerAutor = function(id) {
        // Aseguramos que el tipo coincida al eliminar (Set usa igualdad estricta)
        autoresSeleccionados.delete(id); 
        autoresSeleccionados.delete(parseInt(id));
        renderChips();
    };

    function crearAutorRapido(nombre) {
        let cedula = prompt(`Ingrese la cédula para registrar a "${nombre}":\nEj: V-12345678`);
        if (cedula !== null) {
            alert("El registro rápido requiere conexión AJAX. Por ahora, se creará al enviar el formulario.");
            
            const pseudoId = 'nuevo_' + Date.now();
            listaAutores.push({id: pseudoId, nombre_completo: nombre, cedula: cedula});
            
            let hiddenNuevo = document.createElement('input');
            hiddenNuevo.type = 'hidden';
            hiddenNuevo.name = 'autores_nuevos[]';
            hiddenNuevo.value = JSON.stringify({nombre: nombre, cedula: cedula});
            hiddenInputsBox.appendChild(hiddenNuevo);

            agregarAutor(pseudoId, nombre);
            buscador.value = '';
            resultadosBox.style.display = 'none';
        }
    }
});

function validarAutores() {
    const hiddenInputsBox = document.getElementById('autores-hidden-inputs');
    if (hiddenInputsBox.children.length === 0) {
        document.getElementById('error-autores').style.display = 'block';
        return false; 
    }
    return true; 
}