<?php
// Solicitamos los datos reales al backend (Kernel)
$tarjetasHome = $this->getTarjetasInicio();
?>

<div class="main-content">
    
    <section class="hero-carousel">
        <div class="carousel-slides">
            <div class="slide"></div>
            <div class="slide"></div>
            <div class="slide"></div>
        </div>
        
        <div class="hero-overlay"></div>
        
        <div class="hero-content">
            <h1>Repositorio Inteligente UPTT</h1>
            <p>La plataforma definitiva para la gestión de investigaciones, visibilidad académica y evaluación del impacto sociotecnológico en el estado Trujillo.</p>
        </div>
    </section>

    <div class="cards-grid">
        
        <?php foreach ($tarjetasHome as $tarjeta): ?>
            <article class="card home-card <?= isset($tarjeta['destacado']) && $tarjeta['destacado'] ? 'featured' : '' ?>">
                
                <div class="home-card-icon" style="font-size: 2rem; color: var(--color-terciario); margin-bottom: 1rem;">
                    <i class="<?= htmlspecialchars($tarjeta['icono']) ?>"></i>
                </div>
                
                <h3><?= htmlspecialchars($tarjeta['titulo']) ?></h3>
                
                <p><?= htmlspecialchars($tarjeta['descripcion']) ?></p>
                
                <a href="<?= htmlspecialchars($tarjeta['enlace']) ?>" class="btn" style="margin-top: auto; align-self: flex-start;">
                    <?= htmlspecialchars($tarjeta['texto_boton']) ?>
                </a>
                
            </article>
        <?php endforeach; ?>

    </div>

</div>