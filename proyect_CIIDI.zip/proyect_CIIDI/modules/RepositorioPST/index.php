<?php
// modules/RepositorioPST/index.php
require_once CORE_PATH . 'Interfaces/ModuleContract.php';

class RepositorioModule implements ModuleContract {
    
    public function getNombre(): string {
        return 'Repositorio PST';
    }
    public function getRutas(): array {
        return [
            'inicio' => [
                'vista'  => __DIR__ . '/views/home_bienvenida.php',
                'titulo' => 'Inicio - Sistema Integral UPTTMBI'
            ],
            'repositorio' => [
                'vista'  => __DIR__ . '/views/home_bienvenida.php',
                'titulo' => 'Explorar Repositorio'
            ],
            'agregar_documento' => [
                'vista'  => __DIR__ . '/views/admin_subida_pst.php',
                'titulo' => 'Cargar Documento'
            ]
        ];
    }

    // NUEVO: El plano visual del menú para este módulo
    public function getMenuConfig(): array {
        return [
            // Podemos enviar múltiples botones, pero aquí enviamos un grupo desplegable
            [
                'tipo'        => 'parent', // 'parent' si tiene submenú, 'link' si es directo
                'titulo'      => 'Repositorio',
                'icono'       => '📂',
                'enlace'      => 'repositorio', // A dónde lleva el clic principal
                'activadores' => ['repositorio', 'agregar_documento'], // Rutas que iluminan el padre
                'subitems'    => [
                    ['ruta' => 'repositorio', 'titulo' => '🔍 Explorar Proyectos'],
                    ['ruta' => 'agregar_documento', 'titulo' => '➕ Cargar Documento']
                ]
            ]
        ];
    }
}

return new RepositorioModule();