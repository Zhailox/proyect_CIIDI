
    <div class="container">

        <div class="header-banner">
            <h1>Anuncios y Noticias I+D</h1>
            <p>Mantente al día con las últimas convocatorias, eventos y novedades de nuestro departamento de investigación.</p>
        </div>
        
        <div class="grid grid-2">
            <div class="card" style="border-top: 4px solid var(--color-terciario);">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;">
                    <h3>Apertura de Convocatoria Q2 2026</h3>
                    <span class="badge new">NUEVO</span>
                </div>
                <p>Se abre el proceso de recepción de anteproyectos para el financiamiento de I+D en el área de Software Libre. Los equipos deben estar conformados por al menos un profesor y dos estudiantes.</p>
                <div style="margin-top: 1.5rem;">
                    <a href="#" class="btn-primary" style="background-color: transparent; color: var(--color-principal); border: 2px solid var(--color-terciario); padding: 0.4rem 1.2rem; box-shadow: none;">Leer completo &rarr;</a>
                </div>
            </div>
            <div class="card" style="border-top: 4px solid var(--gris);">
                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem;">
                    <h3>Resultados del Hackathon UPTT</h3>
                    <span class="badge old">HACE 1 SEMANA</span>
                </div>
                <p>Conoce a los equipos ganadores del evento anual de desarrollo rápido. Sus proyectos pasarán a la fase de incubación en nuestro laboratorio principal.</p>
                <div style="margin-top: 1.5rem;">
                    <a href="#" class="btn-primary" style="background-color: transparent; color: var(--color-principal); border: 2px solid var(--gris); padding: 0.4rem 1.2rem; box-shadow: none;">Leer completo &rarr;</a>
                </div>
            </div>
        </div>
        
    </div>
