<?php
// modules/Investigaciones/index.php

// Nos aseguramos de requerir el contrato del sistema
require_once CORE_PATH . 'Interfaces/ModuleContract.php';

// Nombre de clase totalmente único para este módulo de Investigación y Desarrollo
class InvestigacionesModule implements ModuleContract {
    
    public function getNombre(): string {
        return 'Módulo de Investigaciones e I+D';
    }

    public function getRutas(): array {
        return [
            // Ruta principal: Cartelera general de proyectos y el "Top 10"
            'investigaciones' => [
                'vista'  => __DIR__ . '/views/showcase_investigaciones.php', 
                'titulo' => 'Cartelera I+D - Investigaciones Universitarias'
            ],
            // Ruta para la administración de las postulaciones a proyectos de investigación
            'postulaciones-investigacion' => [
                'vista'  => __DIR__ . '/views/panel_postulaciones.php', 
                'titulo' => 'Panel de Postulaciones - Gestión I+D'
            ]
        ];
    }

    public function getMenuConfig(): array {
        return [
            [
                'tipo'        => 'parent',
                'titulo'      => 'Investigaciones',
                'icono'       => '🔬',
                'enlace'      => 'investigaciones',
                // Rutas clave del módulo que mantendrán expandido e iluminado este menú padre
                'activadores' => ['investigaciones', 'postulaciones-investigacion'], 
                'subitems'    => [
                    ['ruta' => 'investigaciones', 'titulo' => '📋 Cartelera I+D'],
                    ['ruta' => 'postulaciones-investigacion', 'titulo' => '📥 Panel Postulaciones']
                ]
            ]
        ];
    }
}

// Retornamos la instancia configurada directamente al Kernel orquestador
return new InvestigacionesModule();