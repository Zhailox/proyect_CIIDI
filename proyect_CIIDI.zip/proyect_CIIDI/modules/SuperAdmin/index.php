<?php
// modules/SuperAdmin/index.php

// Requerimos la interfaz base
require_once CORE_PATH . 'Interfaces/ModuleContract.php';

// Clase única para el módulo del Dios del Sistema
class SuperAdminModule implements ModuleContract {
    
    public function getNombre(): string {
        return 'Módulo de Super Administración (Sudoadmin)';
    }

    public function getRutas(): array {
        return [
            // Ruta principal: El dashboard administrativo
            'sudoadmin' => [
                'vista'  => __DIR__ . '/views/dashboard_admin.php', 
                'titulo' => 'Panel de Control - Sudoadmin'
            ],
            // Ruta para gestionar los módulos encendidos/apagados
            'gestor-modulos' => [
                'vista'  => __DIR__ . '/views/gestor_modulos.php', 
                'titulo' => 'Gestor de Módulos - Configuración'
            ],
            // Ruta para ver los logs de errores y accesos
            'visor-logs' => [
                'vista'  => __DIR__ . '/views/visor_logs.php', 
                'titulo' => 'Visor de Logs - Auditoría del Sistema'
            ]
        ];
    }

    public function getMenuConfig(): array {
        return [
            [
                'tipo'        => 'parent',
                'titulo'      => 'Sudoadmin',
                'icono'       => '🛠️',
                'enlace'      => 'sudoadmin',
                // Rutas que mantienen iluminado el panel administrativo
                'activadores' => ['sudoadmin', 'gestor-modulos', 'visor-logs'], 
                'subitems'    => [
                    ['ruta' => 'sudoadmin', 'titulo' => '💻 Panel de Control'],
                    ['ruta' => 'gestor-modulos', 'titulo' => '🔌 Gestor de Módulos'],
                    ['ruta' => 'visor-logs', 'titulo' => '🪵 Visor de Logs']
                ]
            ]
        ];
    }
}

// Retornamos la instancia para el Kernel
return new SuperAdminModule();